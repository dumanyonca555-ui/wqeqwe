---
type: "always_apply"
---

# GDD Part 2 - Teknik Kurallar ve Spesifikasyonlar

Montserrat fontu kullanılmalı!

## 🎨 UI TEMA VE RENKLER

### Zorunlu Renk Paleti:
```css
:root {
  --color1: #240f48;  /* Koyu mor - Primary dark */
  --color2: #841567;  /* Bordo - Accent color */
  --color3: #7b9fff;  /* Mavi - Highlight/links */
  --color4: #ebc7ff;  /* Açık mor - Soft elements */
  --color5: #fff7ff;  /* Beyaza yakın - Text/backgrounds */
}
```

### Gradient Önerileri:
- **Primary Gradient**: `linear-gradient(135deg, #240f48 0%, #841567 50%, #7b9fff 100%)`
- **Soft Overlay**: `linear-gradient(180deg, rgba(36,15,72,0.12), rgba(235,199,255,0.06))`
- **Glass Background**: `rgba(255,255,255,0.06)`
- **Accent Gradient**: `var(--accent-grad): linear-gradient(135deg,var(--c1),var(--c2) 60%, var(--c3))`

### UI Tasarım Kuralları:
- **Glassmorphism** tasarım dili zorunlu
- **Mobil öncelikli** responsive tasarım
- **Progressive enhancement** yaklaşımı
- **Touch gestures** desteği
- **Dark theme** as default

---

## ⚡ AJAX KULLANIM KURALLARI

### Zorunlu AJAX İşlemleri:
1. **Mesaj gönderme/çekme** - AJAX ile
2. **Typing indicator** - Real-time AJAX
3. **Özel chat odası açma** - AJAX modal
4. **Affinity güncellemeleri** - Background AJAX
5. **Kaynak harcamaları** - Anında AJAX validation

### AJAX Implementation:
```javascript
// Zorunlu fetch kullanımı, XHR değil
async function sendMessage(chatId, text) {
   const res = await fetch(`/api/chats/${chatId}/messages`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-CSRF-Token': window.CSRF_TOKEN
    },
    body: JSON.stringify({ body: text })
  });
  // Error handling zorunlu
  const json = await res.json();
  if(json.success) {
    appendMessageToUI(json.message);
  } else {
    showError(json.error.message);
  }
}
```

### Gerçek Zaman Yaklaşımları:
- **MVP**: AJAX polling (2-5 saniye)
- **Preferred**: Long-polling
- **Advanced**: WebSocket (Ratchet PHP)
- **Rate limiting**: Redis ile zorunlu

---

## 🖱️ CURSOR-ADAPTIVE UI KURALLARI

### Zorunlu Cursor Effects:
```css
/* Cursor-follow parallax container */
.cursor-parallax {
  position: relative; 
  overflow: hidden;
}

.parallax-layer {
  position: absolute; 
  pointer-events: none; 
  will-change: transform;
  transition: transform .08s linear;
}
```

### JavaScript Implementation:
```javascript
// Zorunlu pointermove listener
document.addEventListener('pointermove', (e) => {
  const layers = document.querySelectorAll('.parallax-layer');
  layers.forEach((layer, index) => {
    const speed = (index + 1) * 0.02;
    const x = (e.clientX - window.innerWidth / 2) * speed;
    const y = (e.clientY - window.innerHeight / 2) * speed;
    layer.style.transform = `translate(${x}px, ${y}px)`;
  });
});
```

### Mobil Fallback:
- **Gyroscope/deviceorientation** kullanımı
- **Touch gestures** ile benzer etkiler
- **Performance optimization** zorunlu

---

## 🎭 ANİMASYON KURALLARI

### Zorunlu Animations:
```css
/* Mesaj gönderme animasyonu */
@keyframes popIn {
  from { 
    transform: scale(.98); 
    opacity: 0; 
  }
  to { 
    transform: scale(1); 
    opacity: 1; 
  }
}

.chat-bubble {
  animation: popIn .18s ease;
}

/* Button hover effects */
.btn-accent:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 26px rgba(132,21,103,0.22);
}
```

### Microinteractions:
- **Typing indicator**: 3 nokta animasyonu
- **Message send**: Slide+fade .18s
- **Button hover**: translateY(-2px)
- **Loading states**: Shimmer effects
- **Transition**: Blur + gradient wipe

### Performance Kuralları:
- **Transform-based** animasyonlar only
- **will-change** property kullanımı
- **requestAnimationFrame** for smooth animations
- **Hardware acceleration** preferred

---

## 🏗️ TEKNİK STACK KURALLARI

### Backend Requirements:
- **PHP 8.x** zorunlu (OOP, Composer)
- **MySQL/MariaDB** database
- **Redis** cache ve session store
- **RESTful API** endpoints
- **JWT veya server-side session** auth

### Frontend Requirements:
- **HTML5/CSS3/Vanilla JS** temel
- **SASS** preprocessing önerilen
- **ES6+** JavaScript features
- **No heavy frameworks** (React/Vue yasak)
- **Alpine.js** optional, minimal framework allowed

### Server Requirements:
- **LAMP/LEMP** stack
- **Supervisor** for queue workers
- **Cron jobs** for timed events
- **CDN** for static assets

---

## 🛡️ GÜVENLİK KURALLARI

### Zorunlu Security Measures:
```php
// CSRF koruması zorunlu
if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    throw new SecurityException('CSRF token mismatch');
}

// Prepared statements zorunlu
$stmt = $db->prepare("INSERT INTO messages (chat_id, sender_id, body) VALUES (?, ?, ?)");
$stmt->execute([$chatId, $userId, $body]);

// Rate limiting zorunlu
$redis->incr("rate_limit:user:$userId");
$redis->expire("rate_limit:user:$userId", 60);
```

### Input Validation:
- **SQL injection** koruması (PDO/prepared statements)
- **XSS** koruması (output encoding)
- **File upload** sanitization
- **Rate limiting** (Redis-based)
- **Content length** limits

---

## 💾 VERİTABANI KURALLARI

### Zorunlu Tablolar:
```sql
-- Core tables zorunlu
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    profile_data JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE characters (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    bio TEXT,
    avatar_path VARCHAR(255),
    default_chat_hours JSON -- Typing delays ve availability
);

CREATE TABLE chats (
    id INT PRIMARY KEY AUTO_INCREMENT,
    type ENUM('group', 'private', 'system') NOT NULL,
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE messages (
    id INT PRIMARY KEY AUTO_INCREMENT,
    chat_id INT NOT NULL,
    sender_type ENUM('player', 'character', 'system') NOT NULL,
    sender_id INT,
    body TEXT NOT NULL,
    attachments JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    read_by JSON,
    FOREIGN KEY (chat_id) REFERENCES chats(id)
);

CREATE TABLE affinities (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    character_id INT NOT NULL,
    affinity_score INT DEFAULT 0 CHECK (affinity_score >= 0 AND affinity_score <= 100),
    route_state JSON,
    UNIQUE KEY unique_user_character (user_id, character_id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (character_id) REFERENCES characters(id)
);

CREATE TABLE resources (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    neural_fragments INT DEFAULT 0,
    memory_shards INT DEFAULT 0,
    data_points INT DEFAULT 0,
    UNIQUE KEY unique_user_resources (user_id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE timed_events (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    character_id INT,
    event_type VARCHAR(50) NOT NULL,
    scheduled_datetime DATETIME NOT NULL,
    payload JSON,
    processed TINYINT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (character_id) REFERENCES characters(id)
);
```

### Index Requirements:
```sql
-- Performance için zorunlu indexler
CREATE INDEX idx_messages_chat_created ON messages(chat_id, created_at);
CREATE INDEX idx_affinities_user_character ON affinities(user_id, character_id);
CREATE INDEX idx_timed_events_scheduled ON timed_events(scheduled_datetime, processed);
CREATE INDEX idx_users_last_active ON users(last_active);
```

---

## 🎮 OYUN MEKANİKLERİ KURALLARI

### Affinity System:
- **0-100 arası** integer değerler
- **Atomic updates** (database transactions)
- **Validation** her değişimde
- **Route unlocks** belirli threshold'larda

### Resource Management:
```php
// Atomic resource spending zorunlu
$db->beginTransaction();
try {
    $stmt = $db->prepare("UPDATE resources SET neural_fragments = neural_fragments - ? WHERE user_id = ? AND neural_fragments >= ?");
    $result = $stmt->execute([$cost, $userId, $cost]);
    
    if ($stmt->rowCount() === 0) {
        throw new InsufficientResourcesException();
    }
    
    // Unlock content
    $this->unlockPrivateChat($userId, $characterId);
    $db->commit();
} catch (Exception $e) {
    $db->rollback();
    throw $e;
}
```

### Timed Events:
- **Cron job/Queue worker** zorunlu
- **PHP CLI + Supervisor** setup
- **Redis queue** for scalability
- **Graceful failure handling**

---

## 📱 RESPONSIVE KURALLARI

### Breakpoints:
```css
/* Mobil-first zorunlu */
/* Base: 320px+ */
@media (min-width: 768px) { /* Tablet */ }
@media (min-width: 1024px) { /* Desktop */ }
@media (min-width: 1440px) { /* Large desktop */ }
```

### Touch Optimizations:
- **44px minimum** touch targets
- **Touch feedback** animasyonları
- **Swipe gestures** for navigation
- **Pull-to-refresh** where appropriate

---

## 🔄 API ENDPOINT KURALLARI

### Standardized Response Format:
```json
{
  "success": true,
  "data": {},
  "error": null,
  "metadata": {
    "timestamp": "2024-01-15T10:30:00Z",
    "version": "1.0"
  }
}
```

### Required Endpoints:
```
POST /api/auth/login
POST /api/auth/logout
GET  /api/chats
GET  /api/chats/{id}/messages
POST /api/chats/{id}/messages
POST /api/chats/{id}/typing
POST /api/chats/private/open
GET  /api/characters/{id}/profile
POST /api/user/resources/spend
POST /api/affinity/update
GET  /api/events/upcoming
POST /api/events/participate
```

### Error Handling:
```php
// Standardized error responses zorunlu
try {
    // API logic
} catch (ValidationException $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'VALIDATION_ERROR',
            'message' => $e->getMessage(),
            'field' => $e->getField()
        ]
    ]);
}
```

---

## ⚡ PERFORMANS KURALLARI

### Caching Strategy:
- **Redis** for sessions, rate limiting
- **CDN** for static assets (CG, avatars)
- **Database query optimization**
- **Lazy loading** for chat history

### Asset Optimization:
- **WebP** images preferred
- **MP3/OGG** compressed audio
- **Minified** CSS/JS
- **Gzip compression** enabled

---

## 🎨 UI BİLEŞEN KURALLARI

### Chat Bubbles:
```css
.chat-bubble.sender {
  background: linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.00));
  border: 1px solid rgba(255,255,255,0.04);
  color: var(--color5);
  border-radius: 16px 16px 4px 16px;
}

.chat-bubble.receiver {
  background: var(--accent-grad);
  color: var(--color5);
  border-radius: 16px 16px 16px 4px;
}
```

### Button Styling:
```css
.btn-accent {
  background: var(--accent-grad);
  color: var(--color5);
  border-radius: 12px;
  box-shadow: 0 6px 20px rgba(132,21,103,0.18);
  transition: transform .12s ease, box-shadow .12s ease;
  padding: 12px 24px;
  border: none;
  font-weight: 500;
}
```

---

## 🚫 YASAKLAR VE KISITLAMALAR

### Yasak Teknolojiler:
- ❌ **jQuery** (vanilla JS zorunlu)
- ❌ **Bootstrap** (custom CSS zorunlu)
- ❌ **Heavy frameworks** (React, Vue, Angular)
- ❌ **localStorage/sessionStorage** without fallback
- ❌ **Inline styles** (CSS classes zorunlu)

### Yasak Practices:
- ❌ **SQL queries in frontend**
- ❌ **Hardcoded API keys**
- ❌ **Synchronous AJAX calls**
- ❌ **No error handling**
- ❌ **Direct DOM manipulation** without event delegation

---

## ✅ MANDATORY FEATURES

### Must-Have Features:
- ✅ **AJAX-driven messaging**
- ✅ **Cursor-adaptive UI**
- ✅ **Glassmorphism design**
- ✅ **Mobile-first responsive**
- ✅ **Progressive enhancement**
- ✅ **Color palette adherence**
- ✅ **Microinteractions**
- ✅ **Security best practices**
- ✅ **Performance optimization**
- ✅ **Accessibility considerations**

Bu kurallar zorunlu spesifikasyonlardır. Tüm geliştirme bu kurallara uygun olarak yapılmalıdır!