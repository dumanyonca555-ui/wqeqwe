<?php
require_once '../backend/config/config.php';
require_once '../backend/config/database.php';
require_once '../backend/includes/functions.php';

// Check if user is logged in
if (!is_logged_in()) {
    redirect('/index.php');
}

$user = get_current_user_data();

// Sample audio settings (in a real app, these would be stored in database)
$audioSettings = [
    'master_volume' => 80,
    'music_volume' => 70,
    'sfx_volume' => 85,
    'voice_volume' => 90,
    'music_enabled' => true,
    'sfx_enabled' => true,
    'voice_enabled' => true,
    'auto_play_music' => true,
    'loop_music' => true,
    'fade_transitions' => true,
    'spatial_audio' => false,
    'high_quality_audio' => true
];
?>

<div class="content-container">
    <!-- Audio Settings Header -->
    <div class="page-header">
        <div class="header-content">
            <div class="header-icon">🎵</div>
            <div class="header-info">
                <h1 class="page-title">Ses ve Müzik Ayarları</h1>
                <p class="page-description">Oyun seslerini ve müzik deneyimini özelleştir</p>
            </div>
        </div>
        <div class="header-actions">
            <button class="btn secondary" onclick="resetToDefaults()">
                <span class="btn-icon">🔄</span>
                <span class="btn-text">Varsayılana Sıfırla</span>
            </button>
            <button class="btn primary" onclick="saveSettings()">
                <span class="btn-icon">💾</span>
                <span class="btn-text">Kaydet</span>
            </button>
        </div>
    </div>

    <!-- Volume Controls -->
    <div class="settings-section">
        <h2 class="section-title">🔊 Ses Seviyeleri</h2>
        
        <div class="settings-grid">
            <div class="setting-item">
                <div class="setting-header">
                    <label class="setting-label">Ana Ses Seviyesi</label>
                    <span class="setting-value" id="master-value"><?php echo $audioSettings['master_volume']; ?>%</span>
                </div>
                <div class="setting-control">
                    <input type="range" 
                           id="master-volume" 
                           class="volume-slider" 
                           min="0" 
                           max="100" 
                           value="<?php echo $audioSettings['master_volume']; ?>"
                           onchange="updateVolume('master', this.value)">
                    <div class="volume-indicators">
                        <span class="volume-min">🔇</span>
                        <span class="volume-max">🔊</span>
                    </div>
                </div>
                <p class="setting-description">Tüm oyun seslerinin genel seviyesini kontrol eder</p>
            </div>

            <div class="setting-item">
                <div class="setting-header">
                    <label class="setting-label">Background Müzik</label>
                    <span class="setting-value" id="music-value"><?php echo $audioSettings['music_volume']; ?>%</span>
                </div>
                <div class="setting-control">
                    <input type="range" 
                           id="music-volume" 
                           class="volume-slider" 
                           min="0" 
                           max="100" 
                           value="<?php echo $audioSettings['music_volume']; ?>"
                           onchange="updateVolume('music', this.value)">
                    <div class="volume-indicators">
                        <span class="volume-min">🎵</span>
                        <span class="volume-max">🎶</span>
                    </div>
                </div>
                <p class="setting-description">Arka plan müziğinin ses seviyesi</p>
            </div>

            <div class="setting-item">
                <div class="setting-header">
                    <label class="setting-label">Ses Efektleri</label>
                    <span class="setting-value" id="sfx-value"><?php echo $audioSettings['sfx_volume']; ?>%</span>
                </div>
                <div class="setting-control">
                    <input type="range" 
                           id="sfx-volume" 
                           class="volume-slider" 
                           min="0" 
                           max="100" 
                           value="<?php echo $audioSettings['sfx_volume']; ?>"
                           onchange="updateVolume('sfx', this.value)">
                    <div class="volume-indicators">
                        <span class="volume-min">🔇</span>
                        <span class="volume-max">💥</span>
                    </div>
                </div>
                <p class="setting-description">Tıklama, hover ve bildirim seslerinin seviyesi</p>
            </div>

            <div class="setting-item">
                <div class="setting-header">
                    <label class="setting-label">Karakter Sesleri</label>
                    <span class="setting-value" id="voice-value"><?php echo $audioSettings['voice_volume']; ?>%</span>
                </div>
                <div class="setting-control">
                    <input type="range" 
                           id="voice-volume" 
                           class="volume-slider" 
                           min="0" 
                           max="100" 
                           value="<?php echo $audioSettings['voice_volume']; ?>"
                           onchange="updateVolume('voice', this.value)">
                    <div class="volume-indicators">
                        <span class="volume-min">🤐</span>
                        <span class="volume-max">🗣️</span>
                    </div>
                </div>
                <p class="setting-description">Karakter diyalogları ve ses kayıtlarının seviyesi</p>
            </div>
        </div>
    </div>

    <!-- Audio Options -->
    <div class="settings-section">
        <h2 class="section-title">⚙️ Ses Seçenekleri</h2>
        
        <div class="settings-grid">
            <div class="setting-item toggle-setting">
                <div class="setting-header">
                    <label class="setting-label">Background Müzik</label>
                    <div class="toggle-switch">
                        <input type="checkbox" 
                               id="music-enabled" 
                               <?php echo $audioSettings['music_enabled'] ? 'checked' : ''; ?>
                               onchange="toggleSetting('music_enabled', this.checked)">
                        <label for="music-enabled" class="toggle-label"></label>
                    </div>
                </div>
                <p class="setting-description">Arka plan müziğini tamamen aç/kapat</p>
            </div>

            <div class="setting-item toggle-setting">
                <div class="setting-header">
                    <label class="setting-label">Ses Efektleri</label>
                    <div class="toggle-switch">
                        <input type="checkbox" 
                               id="sfx-enabled" 
                               <?php echo $audioSettings['sfx_enabled'] ? 'checked' : ''; ?>
                               onchange="toggleSetting('sfx_enabled', this.checked)">
                        <label for="sfx-enabled" class="toggle-label"></label>
                    </div>
                </div>
                <p class="setting-description">Tüm ses efektlerini aç/kapat</p>
            </div>

            <div class="setting-item toggle-setting">
                <div class="setting-header">
                    <label class="setting-label">Karakter Sesleri</label>
                    <div class="toggle-switch">
                        <input type="checkbox" 
                               id="voice-enabled" 
                               <?php echo $audioSettings['voice_enabled'] ? 'checked' : ''; ?>
                               onchange="toggleSetting('voice_enabled', this.checked)">
                        <label for="voice-enabled" class="toggle-label"></label>
                    </div>
                </div>
                <p class="setting-description">Karakter diyaloglarını aç/kapat</p>
            </div>

            <div class="setting-item toggle-setting">
                <div class="setting-header">
                    <label class="setting-label">Otomatik Müzik Başlatma</label>
                    <div class="toggle-switch">
                        <input type="checkbox" 
                               id="auto-play-music" 
                               <?php echo $audioSettings['auto_play_music'] ? 'checked' : ''; ?>
                               onchange="toggleSetting('auto_play_music', this.checked)">
                        <label for="auto-play-music" class="toggle-label"></label>
                    </div>
                </div>
                <p class="setting-description">Oyun açıldığında müziği otomatik başlat</p>
            </div>

            <div class="setting-item toggle-setting">
                <div class="setting-header">
                    <label class="setting-label">Müzik Döngüsü</label>
                    <div class="toggle-switch">
                        <input type="checkbox" 
                               id="loop-music" 
                               <?php echo $audioSettings['loop_music'] ? 'checked' : ''; ?>
                               onchange="toggleSetting('loop_music', this.checked)">
                        <label for="loop-music" class="toggle-label"></label>
                    </div>
                </div>
                <p class="setting-description">Müziği sürekli tekrarla</p>
            </div>

            <div class="setting-item toggle-setting">
                <div class="setting-header">
                    <label class="setting-label">Yumuşak Geçişler</label>
                    <div class="toggle-switch">
                        <input type="checkbox" 
                               id="fade-transitions" 
                               <?php echo $audioSettings['fade_transitions'] ? 'checked' : ''; ?>
                               onchange="toggleSetting('fade_transitions', this.checked)">
                        <label for="fade-transitions" class="toggle-label"></label>
                    </div>
                </div>
                <p class="setting-description">Müzik değişimlerinde yumuşak geçiş efekti</p>
            </div>
        </div>
    </div>

    <!-- Advanced Settings -->
    <div class="settings-section">
        <h2 class="section-title">🔧 Gelişmiş Ayarlar</h2>
        
        <div class="settings-grid">
            <div class="setting-item toggle-setting">
                <div class="setting-header">
                    <label class="setting-label">Yüksek Kalite Ses</label>
                    <div class="toggle-switch">
                        <input type="checkbox" 
                               id="high-quality-audio" 
                               <?php echo $audioSettings['high_quality_audio'] ? 'checked' : ''; ?>
                               onchange="toggleSetting('high_quality_audio', this.checked)">
                        <label for="high-quality-audio" class="toggle-label"></label>
                    </div>
                </div>
                <p class="setting-description">Daha yüksek kaliteli ses dosyaları kullan (daha fazla veri)</p>
            </div>

            <div class="setting-item toggle-setting">
                <div class="setting-header">
                    <label class="setting-label">3D Ses Efekti</label>
                    <div class="toggle-switch">
                        <input type="checkbox" 
                               id="spatial-audio" 
                               <?php echo $audioSettings['spatial_audio'] ? 'checked' : ''; ?>
                               onchange="toggleSetting('spatial_audio', this.checked)">
                        <label for="spatial-audio" class="toggle-label"></label>
                    </div>
                </div>
                <p class="setting-description">Uzamsal ses efektleri (kulaklık önerilir)</p>
            </div>
        </div>
    </div>

    <!-- Audio Test -->
    <div class="settings-section">
        <h2 class="section-title">🎧 Ses Testi</h2>
        
        <div class="audio-test-panel">
            <div class="test-controls">
                <button class="test-btn" onclick="testAudio('music')">
                    <span class="btn-icon">🎵</span>
                    <span class="btn-text">Müzik Testi</span>
                </button>
                <button class="test-btn" onclick="testAudio('sfx')">
                    <span class="btn-icon">🔊</span>
                    <span class="btn-text">Efekt Testi</span>
                </button>
                <button class="test-btn" onclick="testAudio('voice')">
                    <span class="btn-icon">🗣️</span>
                    <span class="btn-text">Ses Testi</span>
                </button>
                <button class="test-btn" onclick="testAudio('all')">
                    <span class="btn-icon">🎼</span>
                    <span class="btn-text">Tümünü Test Et</span>
                </button>
            </div>
            <p class="test-description">Ses ayarlarınızı test etmek için yukarıdaki butonları kullanın</p>
        </div>
    </div>
</div>

<script>
let audioSettings = <?php echo json_encode($audioSettings); ?>;

function updateVolume(type, value) {
    const valueSpan = document.getElementById(type + '-value');
    valueSpan.textContent = value + '%';
    
    audioSettings[type + '_volume'] = parseInt(value);
    
    // Apply to audio manager if available
    if (window.audioManager) {
        switch(type) {
            case 'music':
                window.audioManager.setMusicVolume(value / 100);
                break;
            case 'sfx':
                window.audioManager.setSfxVolume(value / 100);
                break;
        }
    }
    
    // Play test sound for immediate feedback
    if (type === 'sfx' && window.audioManager) {
        window.audioManager.playSound('click');
    }
}

function toggleSetting(setting, enabled) {
    audioSettings[setting] = enabled;
    
    // Apply setting immediately
    if (window.audioManager) {
        switch(setting) {
            case 'music_enabled':
                if (enabled) {
                    window.audioManager.resumeMusic();
                } else {
                    window.audioManager.pauseMusic();
                }
                break;
            case 'auto_play_music':
                // This would be applied on next page load
                break;
        }
    }
    
    showNotification(`${setting.replace('_', ' ')} ${enabled ? 'açıldı' : 'kapatıldı'}`);
}

function testAudio(type) {
    if (!window.audioManager) {
        showNotification('Ses sistemi yüklenemedi!');
        return;
    }
    
    switch(type) {
        case 'music':
            window.audioManager.playMusic();
            showNotification('Müzik testi başlatıldı 🎵');
            break;
        case 'sfx':
            window.audioManager.playSound('click');
            setTimeout(() => window.audioManager.playSound('hover'), 500);
            setTimeout(() => window.audioManager.playSound('notification'), 1000);
            showNotification('Ses efektleri test ediliyor 🔊');
            break;
        case 'voice':
            showNotification('Karakter sesi testi: "Merhaba, ben Leo!" 🗣️');
            // In a real implementation, this would play a character voice sample
            break;
        case 'all':
            testAudio('music');
            setTimeout(() => testAudio('sfx'), 1000);
            setTimeout(() => testAudio('voice'), 2000);
            showNotification('Tüm ses sistemleri test ediliyor 🎼');
            break;
    }
}

function saveSettings() {
    // In a real implementation, this would save to database
    showNotification('Ses ayarları kaydedildi! ✅');
    
    if (window.audioManager) {
        window.audioManager.playSound('notification');
    }
}

function resetToDefaults() {
    const defaultSettings = {
        master_volume: 80,
        music_volume: 70,
        sfx_volume: 85,
        voice_volume: 90,
        music_enabled: true,
        sfx_enabled: true,
        voice_enabled: true,
        auto_play_music: true,
        loop_music: true,
        fade_transitions: true,
        spatial_audio: false,
        high_quality_audio: true
    };
    
    // Update UI
    Object.keys(defaultSettings).forEach(key => {
        if (key.includes('volume')) {
            const slider = document.getElementById(key.replace('_', '-'));
            const valueSpan = document.getElementById(key.replace('_volume', '-value'));
            if (slider && valueSpan) {
                slider.value = defaultSettings[key];
                valueSpan.textContent = defaultSettings[key] + '%';
            }
        } else {
            const checkbox = document.getElementById(key.replace('_', '-'));
            if (checkbox) {
                checkbox.checked = defaultSettings[key];
            }
        }
    });
    
    audioSettings = defaultSettings;
    showNotification('Ayarlar varsayılan değerlere sıfırlandı! 🔄');
    
    if (window.audioManager) {
        window.audioManager.playSound('notification');
    }
}

// Initialize audio settings on page load
document.addEventListener('DOMContentLoaded', function() {
    // Apply current settings to audio manager
    if (window.audioManager) {
        window.audioManager.setMusicVolume(audioSettings.music_volume / 100);
        window.audioManager.setSfxVolume(audioSettings.sfx_volume / 100);
    }
});
</script>
