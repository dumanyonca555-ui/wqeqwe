<?php
require_once '../backend/config/config.php';
require_once '../backend/config/database.php';
require_once '../backend/includes/functions.php';

// Check if user is logged in
if (!is_logged_in()) {
    redirect('/index.php');
}

$user = get_current_user_data();

// Sample audio collection data
$audioItems = [
    [
        'id' => 1,
        'title' => 'Leo - "Merhaba, ben Leo"',
        'description' => 'Leo\'nun tanışma diyalogu',
        'file' => 'assets/audio/voices/leo-hello.mp3',
        'category' => 'character',
        'character' => 'Leo',
        'duration' => '00:15',
        'unlocked' => true
    ],
    [
        'id' => 2,
        'title' => 'Chloe - "Sisteme giriş yapıyorum"',
        'description' => 'Chloe\'nin hacker diyalogu',
        'file' => 'assets/audio/voices/chloe-hacking.mp3',
        'category' => 'character',
        'character' => 'Chloe',
        'duration' => '00:12',
        'unlocked' => true
    ],
    [
        'id' => 3,
        'title' => 'Felix - "Seninle olmak istiyorum"',
        'description' => 'Felix\'in romantik diyalogu',
        'file' => 'assets/audio/voices/felix-romantic.mp3',
        'category' => 'character',
        'character' => 'Felix',
        'duration' => '00:18',
        'unlocked' => false
    ],
    [
        'id' => 4,
        'title' => 'Elara - "Sana öğretecek çok şey var"',
        'description' => 'Elara\'nın mentor diyalogu',
        'file' => 'assets/audio/voices/elara-mentor.mp3',
        'category' => 'character',
        'character' => 'Elara',
        'duration' => '00:20',
        'unlocked' => true
    ],
    [
        'id' => 5,
        'title' => 'Neural Network Ana Teması',
        'description' => 'Oyunun ana background müziği',
        'file' => 'assets/audio/music/main-theme.mp3',
        'category' => 'music',
        'character' => null,
        'duration' => '03:45',
        'unlocked' => true
    ],
    [
        'id' => 6,
        'title' => 'Kozmik Festival Müziği',
        'description' => 'Festival sahnesinin özel müziği',
        'file' => 'assets/audio/music/festival-theme.mp3',
        'category' => 'music',
        'character' => null,
        'duration' => '02:30',
        'unlocked' => true
    ],
    [
        'id' => 7,
        'title' => 'Bildirim Sesi',
        'description' => 'Oyun içi bildirim efekti',
        'file' => 'assets/audio/sfx/notification_general.wav',
        'category' => 'sfx',
        'character' => null,
        'duration' => '00:03',
        'unlocked' => true
    ]
];

$categories = [
    'all' => 'Tümü',
    'character' => 'Karakter Sesleri',
    'music' => 'Oyun Müziği',
    'sfx' => 'Ses Efektleri'
];
?>

<div class="content-container">
    <!-- Audio Collection Header -->
    <div class="page-header">
        <div class="header-content">
            <div class="header-icon">🎵</div>
            <div class="header-info">
                <h1 class="page-title">Ses Koleksiyonu</h1>
                <p class="page-description">Karakter sesleri, müzikler ve ses efektleri</p>
            </div>
        </div>
        <div class="header-stats">
            <div class="stat-item">
                <span class="stat-value"><?php echo count(array_filter($audioItems, fn($item) => $item['unlocked'])); ?></span>
                <span class="stat-label">Açılmış</span>
            </div>
            <div class="stat-item">
                <span class="stat-value"><?php echo count($audioItems); ?></span>
                <span class="stat-label">Toplam</span>
            </div>
        </div>
    </div>

    <!-- Category Filter -->
    <div class="filter-tabs">
        <?php foreach ($categories as $key => $name): ?>
        <button class="filter-tab <?php echo $key === 'all' ? 'active' : ''; ?>" 
                onclick="filterAudio('<?php echo $key; ?>')" 
                data-category="<?php echo $key; ?>">
            <?php echo $name; ?>
        </button>
        <?php endforeach; ?>
    </div>

    <!-- Audio Player -->
    <div class="audio-player">
        <div class="player-info">
            <div class="player-icon">🎵</div>
            <div class="player-details">
                <div class="player-title">Ses seçin</div>
                <div class="player-description">Dinlemek için bir ses dosyası seçin</div>
            </div>
        </div>
        <div class="player-controls">
            <button id="play-btn" class="player-btn" onclick="togglePlay()" disabled>
                <span class="play-icon">▶️</span>
            </button>
            <div class="progress-container">
                <div class="progress-bar">
                    <div class="progress-fill"></div>
                </div>
                <div class="time-display">
                    <span class="current-time">00:00</span>
                    <span class="total-time">00:00</span>
                </div>
            </div>
            <div class="volume-container">
                <span class="volume-icon">🔊</span>
                <input type="range" class="volume-slider" min="0" max="100" value="70" onchange="setVolume(this.value)">
            </div>
        </div>
        <audio id="audio-player" preload="none"></audio>
    </div>

    <!-- Audio List -->
    <div class="audio-list">
        <?php foreach ($audioItems as $item): ?>
        <div class="audio-item <?php echo $item['unlocked'] ? 'unlocked' : 'locked'; ?>" 
             data-category="<?php echo $item['category']; ?>"
             onclick="<?php echo $item['unlocked'] ? "playAudio({$item['id']})" : "showNotification('Bu ses henüz açılmamış!')"; ?>">
            
            <div class="audio-icon">
                <?php if ($item['unlocked']): ?>
                    <?php if ($item['category'] === 'character'): ?>
                        👤
                    <?php elseif ($item['category'] === 'music'): ?>
                        🎵
                    <?php else: ?>
                        🔊
                    <?php endif; ?>
                <?php else: ?>
                    🔒
                <?php endif; ?>
            </div>
            
            <div class="audio-info">
                <h3 class="audio-title"><?php echo htmlspecialchars($item['title']); ?></h3>
                <p class="audio-description"><?php echo htmlspecialchars($item['description']); ?></p>
                <div class="audio-meta">
                    <span class="audio-category"><?php echo $categories[$item['category']]; ?></span>
                    <?php if ($item['character']): ?>
                        <span class="audio-character"><?php echo $item['character']; ?></span>
                    <?php endif; ?>
                    <span class="audio-duration"><?php echo $item['duration']; ?></span>
                </div>
            </div>
            
            <div class="audio-actions">
                <?php if ($item['unlocked']): ?>
                    <button class="action-btn" onclick="event.stopPropagation(); downloadAudio(<?php echo $item['id']; ?>)" title="İndir">
                        📥
                    </button>
                    <button class="action-btn" onclick="event.stopPropagation(); favoriteAudio(<?php echo $item['id']; ?>)" title="Favorilere Ekle">
                        ⭐
                    </button>
                <?php else: ?>
                    <div class="unlock-hint">Hikayeyi ilerlet</div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<script>
let currentAudio = null;
let currentAudioData = null;
const audioData = <?php echo json_encode($audioItems); ?>;

// Filter functionality
function filterAudio(category) {
    const items = document.querySelectorAll('.audio-item');
    const tabs = document.querySelectorAll('.filter-tab');
    
    // Update active tab
    tabs.forEach(tab => {
        tab.classList.toggle('active', tab.dataset.category === category);
    });
    
    // Filter items
    items.forEach(item => {
        const itemCategory = item.dataset.category;
        const shouldShow = category === 'all' || itemCategory === category;
        item.style.display = shouldShow ? 'flex' : 'none';
    });
    
    // Play click sound
    if (window.audioManager) {
        window.audioManager.playSound('click');
    }
}

// Audio player functionality
function playAudio(itemId) {
    const item = audioData.find(i => i.id === itemId);
    if (!item || !item.unlocked) return;
    
    const audioPlayer = document.getElementById('audio-player');
    const playBtn = document.getElementById('play-btn');
    
    // Update player info
    document.querySelector('.player-title').textContent = item.title;
    document.querySelector('.player-description').textContent = item.description;
    document.querySelector('.total-time').textContent = item.duration;
    
    // Load new audio
    if (currentAudio !== item.file) {
        audioPlayer.src = item.file;
        currentAudio = item.file;
        currentAudioData = item;
    }
    
    // Enable controls
    playBtn.disabled = false;
    
    // Play audio
    audioPlayer.play();
    playBtn.querySelector('.play-icon').textContent = '⏸️';
    
    // Highlight current item
    document.querySelectorAll('.audio-item').forEach(el => el.classList.remove('playing'));
    event.currentTarget.classList.add('playing');
    
    // Play notification sound
    if (window.audioManager) {
        window.audioManager.playSound('notification');
    }
}

function togglePlay() {
    const audioPlayer = document.getElementById('audio-player');
    const playBtn = document.getElementById('play-btn');
    const playIcon = playBtn.querySelector('.play-icon');
    
    if (audioPlayer.paused) {
        audioPlayer.play();
        playIcon.textContent = '⏸️';
    } else {
        audioPlayer.pause();
        playIcon.textContent = '▶️';
    }
}

function setVolume(value) {
    const audioPlayer = document.getElementById('audio-player');
    audioPlayer.volume = value / 100;
}

function downloadAudio(itemId) {
    const item = audioData.find(i => i.id === itemId);
    if (!item) return;
    
    const link = document.createElement('a');
    link.href = item.file;
    link.download = item.title + '.mp3';
    link.click();
    
    showNotification('Ses dosyası indiriliyor...');
}

function favoriteAudio(itemId) {
    // In a real implementation, this would save to database
    showNotification('Favorilere eklendi!');
}

// Audio player event listeners
document.getElementById('audio-player').addEventListener('timeupdate', function() {
    const progressFill = document.querySelector('.progress-fill');
    const currentTimeSpan = document.querySelector('.current-time');
    
    const currentTime = this.currentTime;
    const duration = this.duration;
    
    if (duration) {
        const progress = (currentTime / duration) * 100;
        progressFill.style.width = progress + '%';
        
        const minutes = Math.floor(currentTime / 60);
        const seconds = Math.floor(currentTime % 60);
        currentTimeSpan.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
});

document.getElementById('audio-player').addEventListener('ended', function() {
    document.getElementById('play-btn').querySelector('.play-icon').textContent = '▶️';
    document.querySelector('.progress-fill').style.width = '0%';
    document.querySelector('.current-time').textContent = '00:00';
});
</script>
