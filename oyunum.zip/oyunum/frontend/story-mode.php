<?php
// Debug: Check if files exist
if (!file_exists('../backend/config/config.php')) {
    die("Config file not found");
}

if (!file_exists('../backend/config/database.php')) {
    die("Database file not found");
}

if (!file_exists('../backend/includes/functions.php')) {
    die("Functions file not found");
}

require_once '../backend/config/config.php';
require_once '../backend/config/database.php';
require_once '../backend/includes/functions.php';

// Debug session
error_log("Session data in story-mode.php: " . print_r($_SESSION, true));

// Check if user is logged in
if (!is_logged_in()) {
    error_log("User not logged in, redirecting to index.php");
    header("Location: index.php");
    exit();
}

$user = get_current_user_data();

// Fetch all story chapters
$stmt = $pdo->prepare("SELECT * FROM story_chapters ORDER BY chapter_number ASC");
$stmt->execute();
$chapters = $stmt->fetchAll();

// Function to check if a chapter is unlocked
function isChapterUnlocked($chapter, $user_id, $pdo) {
    // If chapter is marked as unlocked in database, it's available
    if ($chapter['is_unlocked']) {
        return true;
    }
    
    // For locked chapters, check if previous chapter is completed
    if ($chapter['chapter_number'] == 1) {
        return $chapter['is_unlocked']; // Chapter 1 follows database setting
    }
    
    // Check if previous chapter is completed
    $prev_chapter_num = $chapter['chapter_number'] - 1;
    $stmt = $pdo->prepare("SELECT completed_at FROM user_story_progress WHERE user_id = ? AND chapter_id = (SELECT id FROM story_chapters WHERE chapter_number = ?)");
    $stmt->execute([$user_id, $prev_chapter_num]);
    $result = $stmt->fetch();
    
    return !empty($result);
}

// Function to calculate unlock time (based on database unlock_time)
function getUnlockTime($chapter) {
    return $chapter['unlock_time'];
}

// Function to calculate time remaining until unlock
function getTimeRemaining($chapter) {
    // For chapters that are already unlocked, return 0
    if ($chapter['is_unlocked']) {
        return 0;
    }
    
    // Calculate unlock time based on chapter number and base time
    $baseTime = strtotime("15:30:00");
    $interval = 3 * 3600; // 3 hours in seconds
    $unlockTimestamp = $baseTime + (($chapter['chapter_number'] - 1) * $interval);
    $currentTime = time();
    
    if ($currentTime >= $unlockTimestamp) {
        return 0;
    }
    
    return $unlockTimestamp - $currentTime;
}

// Check user progress for each chapter
$userProgress = [];
$stmt = $pdo->prepare("SELECT chapter_id, completed_at FROM user_story_progress WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
while ($row = $stmt->fetch()) {
    $userProgress[$row['chapter_id']] = $row['completed_at'];
}

// Calculate overall progress
$totalChapters = count($chapters);
$completedChapters = count($userProgress);
$progressPercentage = $totalChapters > 0 ? ($completedChapters / $totalChapters) * 100 : 0;
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hikaye Modu - Neural Chat</title>
    <link rel="stylesheet" href="assets/css/theme.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/mobile.css">
    <link rel="stylesheet" href="assets/css/main-menu.css">
    <style>
        /* Story Mode Page Styles */
        .story-mode-page {
            min-height: 100vh;
            background: linear-gradient(135deg, #240f48 0%, #841567 100%);
            padding: 20px;
            font-family: 'Montserrat', sans-serif;
        }

        .story-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
            color: #fff7ff;
        }

        .back-button {
            background: rgba(255, 247, 255, 0.1);
            border: none;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            color: #fff7ff;
            font-size: 18px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.3s ease;
            min-width: 44px;
            min-height: 44px;
        }

        .back-button:hover {
            background: rgba(255, 247, 255, 0.2);
        }

        .settings-button {
            background: rgba(255, 247, 255, 0.1);
            border: none;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            color: #fff7ff;
            font-size: 18px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.3s ease;
            min-width: 44px;
            min-height: 44px;
        }

        .settings-button:hover {
            background: rgba(255, 247, 255, 0.2);
        }

        .header-title {
            flex: 1;
            text-align: center;
            font-size: 20px;
            font-weight: bold;
        }

        .progress-section {
            background: rgba(255, 247, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 25px;
            border: 1px solid rgba(123, 159, 255, 0.3);
        }

        .progress-header {
            color: #fff7ff;
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .overall-progress-bar {
            width: 100%;
            height: 12px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 6px;
            overflow: hidden;
            margin: 10px 0;
        }

        .overall-progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #7b9fff, #ebc7ff);
            border-radius: 6px;
            transition: width 0.5s ease;
        }

        .progress-text {
            color: #ebc7ff;
            font-size: 14px;
            text-align: center;
        }

        .chapter-card {
            background: rgba(255, 247, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 15px;
            border: 1px solid rgba(123, 159, 255, 0.3);
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .chapter-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }

        .chapter-card.completed {
            border-color: #7b9fff;
            background: rgba(123, 159, 255, 0.15);
        }

        .chapter-card.available {
            border-color: #ebc7ff;
            background: rgba(235, 199, 255, 0.15);
            animation: pulse 2s infinite;
        }

        .chapter-card.locked {
            opacity: 0.7;
            border-color: rgba(255, 255, 255, 0.2);
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.02); }
        }

        .chapter-header {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }

        .chapter-status-icon {
            font-size: 24px;
            margin-right: 10px;
        }

        .chapter-title {
            font-size: 18px;
            font-weight: bold;
            color: #fff7ff;
            margin-bottom: 8px;
        }

        .chapter-time {
            color: #ebc7ff;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .chapter-rating {
            color: #ebc7ff;
            font-size: 14px;
            margin: 10px 0;
        }

        .chapter-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 15px;
        }

        .chapter-btn {
            padding: 8px 16px;
            border: none;
            border-radius: 20px;
            font-weight: bold;
            cursor: pointer;
            transition: transform 0.2s ease;
            min-height: 36px;
            font-family: 'Montserrat', sans-serif;
        }

        .play-btn {
            background: linear-gradient(45deg, #7b9fff, #ebc7ff);
            color: white;
            font-size: 16px;
            animation: glow 2s infinite;
        }

        @keyframes glow {
            0%, 100% { box-shadow: 0 0 10px rgba(123, 159, 255, 0.3); }
            50% { box-shadow: 0 0 20px rgba(123, 159, 255, 0.6); }
        }

        .replay-btn {
            background: rgba(132, 21, 103, 0.8);
            color: white;
        }

        .notify-btn {
            background: rgba(255, 247, 255, 0.1);
            color: #fff7ff;
            border: 1px solid rgba(123, 159, 255, 0.3);
        }

        .countdown-timer {
            font-family: 'Courier New', monospace;
            font-size: 14px;
            color: #7b9fff;
            text-align: center;
            margin: 10px 0;
        }

        .chapter-bonus {
            color: #7b9fff;
            font-size: 14px;
            margin: 10px 0;
            font-weight: 500;
        }

        .stats-footer {
            background: rgba(255, 247, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 20px;
            margin-top: 25px;
            border: 1px solid rgba(123, 159, 255, 0.3);
            color: #fff7ff;
        }

        .stats-title {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 15px;
            text-align: center;
        }

        .stat-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            font-size: 14px;
        }

        .stat-label {
            color: #ebc7ff;
        }

        .stat-value {
            font-weight: bold;
        }

        /* Responsive adjustments */
        @media (max-width: 480px) {
            .story-mode-page {
                padding: 15px;
            }
            
            .chapter-title {
                font-size: 16px;
            }
            
            .chapter-actions {
                flex-direction: column;
            }
            
            .chapter-btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="story-mode-page">
        <!-- Header -->
        <div class="story-header">
            <button class="back-button" onclick="history.back()">←</button>
            <div class="header-title">📖 Hikaye Modu</div>
            <button class="settings-button">⚙️</button>
        </div>
        
        <!-- Progress Section -->
        <div class="progress-section">
            <div class="progress-header">🏆 İlerleme: <?php echo $completedChapters; ?>/<?php echo $totalChapters; ?> Bölüm Tamamlandı</div>
            <div class="overall-progress-bar">
                <div class="overall-progress-fill" id="progress-fill"></div>
            </div>
            <div class="progress-text"><?php echo round($progressPercentage); ?>% Tamamlandı</div>
        </div>
        
        <!-- Chapter List -->
        <div class="chapter-list">
            <?php foreach ($chapters as $chapter): ?>
                <?php 
                $isUnlocked = isChapterUnlocked($chapter, $_SESSION['user_id'], $pdo);
                $isCompleted = isset($userProgress[$chapter['id']]);
                $timeRemaining = getTimeRemaining($chapter);
                ?>
                <div class="chapter-card <?php echo $isCompleted ? 'completed' : ($isUnlocked ? 'available' : 'locked'); ?>">
                    <div class="chapter-header">
                        <div class="chapter-status-icon">
                            <?php if ($isCompleted): ?>
                                ✅
                            <?php elseif ($isUnlocked): ?>
                                ⏰
                            <?php else: ?>
                                🔒
                            <?php endif; ?>
                        </div>
                        <div class="chapter-title">Chapter <?php echo $chapter['chapter_number']; ?>: <?php echo htmlspecialchars($chapter['title']); ?></div>
                    </div>
                    
                    <div class="chapter-time">
                        <?php if ($isCompleted): ?>
                            🕒 <?php echo date('H:i', strtotime($userProgress[$chapter['id']])); ?> - Tamamlandı
                        <?php elseif ($isUnlocked): ?>
                            🕒 <?php echo getUnlockTime($chapter); ?> - Şimdi Oynayabilir
                        <?php else: ?>
                            ⏳ <?php 
                            $hours = floor($timeRemaining / 3600);
                            $minutes = floor(($timeRemaining % 3600) / 60);
                            echo $hours . " saat " . $minutes . " dakika kaldı";
                            ?>
                        <?php endif; ?>
                    </div>
                    
                    <?php if ($isCompleted): ?>
                        <div class="chapter-rating">⭐⭐⭐ Mükemmel Seçimler</div>
                    <?php elseif ($isUnlocked): ?>
                        <div class="chapter-bonus">💎 +5 Neural Fragment Bonus</div>
                    <?php else: ?>
                        <div class="chapter-time">🕐 Unlock: <?php echo getUnlockTime($chapter); ?></div>
                    <?php endif; ?>
                    
                    <?php if (!$isUnlocked && $timeRemaining > 0): ?>
                        <div class="countdown-timer" id="countdown-<?php echo $chapter['id']; ?>">
                            <?php 
                            $hours = floor($timeRemaining / 3600);
                            $minutes = floor(($timeRemaining % 3600) / 60);
                            $seconds = floor($timeRemaining % 60);
                            echo $hours . "s " . $minutes . "dk " . $seconds . "sn kaldı";
                            ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="chapter-actions">
                        <?php if ($isCompleted): ?>
                            <button class="chapter-btn replay-btn" onclick="playChapter(<?php echo $chapter['id']; ?>)">👁️</button>
                            <button class="chapter-btn replay-btn" onclick="playChapter(<?php echo $chapter['id']; ?>)">Tekrar Oyna</button>
                        <?php elseif ($isUnlocked): ?>
                            <button class="chapter-btn play-btn" onclick="playChapter(<?php echo $chapter['id']; ?>)">▶️ OYNA</button>
                        <?php else: ?>
                            <button class="chapter-btn notify-btn" onclick="setNotification(<?php echo $chapter['id']; ?>)">⏰ Bildirim Ayarla</button>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Stats Footer -->
        <div class="stats-footer">
            <div class="stats-title">📊 İstatistikler</div>
            <div class="stat-item">
                <span class="stat-label">💬 Toplam Mesaj:</span>
                <span class="stat-value">156</span>
            </div>
            <div class="stat-item">
                <span class="stat-label">⭐ Ortalama Skor:</span>
                <span class="stat-value">2.8/3</span>
            </div>
            <div class="stat-item">
                <span class="stat-label">💙 En Sevilen:</span>
                <span class="stat-value">Leo (+15)</span>
            </div>
        </div>
        
        <script>
            // Set the progress bar width on page load
            document.addEventListener('DOMContentLoaded', function() {
                const progressFill = document.getElementById('progress-fill');
                if (progressFill) {
                    progressFill.style.width = '<?php echo $progressPercentage; ?>%';
                }
            });
            
            // Global error handler
            window.onerror = function(message, source, lineno, colno, error) {
                console.error('Global error:', message, 'at', source, ':', lineno, ':', colno);
                console.error('Error object:', error);
                return false;
            };
            
            // Update countdown timers
            function updateCountdowns() {
                <?php foreach ($chapters as $chapter): ?>
                    <?php if (!isChapterUnlocked($chapter, $_SESSION['user_id'], $pdo) && getTimeRemaining($chapter) > 0): ?>
                        {
                            const countdownElement = document.getElementById('countdown-<?php echo $chapter['id']; ?>');
                            if (countdownElement) {
                                const timeRemaining = <?php echo getTimeRemaining($chapter); ?> - Math.floor((new Date() - new Date(<?php echo time() * 1000; ?>)) / 1000);
                                if (timeRemaining > 0) {
                                    const hours = Math.floor(timeRemaining / 3600);
                                    const minutes = Math.floor((timeRemaining % 3600) / 60);
                                    const seconds = Math.floor(timeRemaining % 60);
                                    countdownElement.textContent = hours + "s " + minutes + "dk " + seconds + "sn kaldı";
                                } else {
                                    countdownElement.textContent = "ŞİMDİ OYNAYABİLİR!";
                                    // Refresh the page to update the UI
                                    setTimeout(() => {
                                        location.reload();
                                    }, 2000);
                                }
                            }
                        }
                    <?php endif; ?>
                <?php endforeach; ?>
            }
            
            // Update countdowns every second
            setInterval(updateCountdowns, 1000);
            
            // Play chapter function
            function playChapter(chapterId) {
                console.log("Play chapter function called with ID:", chapterId);
                // Debug: Show an alert to verify the function is called
                alert("Redirecting to chapter " + chapterId);
                // Use the correct path
                window.location.href = 'chapter-play.php?chapter=' + chapterId;
            }
            
            // Set notification function
            function setNotification(chapterId) {
                alert('Bildirim ayarlandı! Bölüm açıldığında bilgilendirileceksiniz.');
            }
        </script>
    </div>
</body>
</html>