<?php
require_once '../backend/config/config.php';
require_once '../backend/config/database.php';
require_once '../backend/includes/functions.php';

echo "<h1>User Test</h1>";

if (is_logged_in()) {
    echo "<p>User is logged in</p>";
    echo "<p>User ID: " . $_SESSION['user_id'] . "</p>";
    
    $user = get_current_user_data();
    if ($user) {
        echo "<p>User data:</p>";
        echo "<pre>";
        print_r($user);
        echo "</pre>";
    } else {
        echo "<p>Could not fetch user data</p>";
    }
} else {
    echo "<p>User is not logged in</p>";
    echo "<p>Session data:</p>";
    echo "<pre>";
    print_r($_SESSION);
    echo "</pre>";
}
?>