// ===== CURSOR PARALLAX SYSTEM =====

class ParallaxCursor {
    constructor() {
        this.mouseX = 0;
        this.mouseY = 0;
        this.windowWidth = window.innerWidth;
        this.windowHeight = window.innerHeight;
        this.layers = [];
        this.isEnabled = true;
        this.rafId = null;
        
        this.init();
    }

    init() {
        console.log('🎯 Parallax Cursor System Initializing...');
        
        this.setupLayers();
        this.setupEventListeners();
        this.startAnimation();
        
        console.log('✅ Parallax Cursor System Ready!');
    }

    setupLayers() {
        // Get all parallax layers
        this.layers = Array.from(document.querySelectorAll('.parallax-layer')).map(layer => {
            const speed = parseFloat(layer.dataset.speed) || 0.02;
            return {
                element: layer,
                speed: speed,
                currentX: 0,
                currentY: 0,
                targetX: 0,
                targetY: 0
            };
        });
        
        console.log(`🎯 Found ${this.layers.length} parallax layers`);
    }

    setupEventListeners() {
        // Mouse move tracking
        document.addEventListener('mousemove', (e) => {
            if (!this.isEnabled) return;
            
            this.mouseX = e.clientX;
            this.mouseY = e.clientY;
            
            this.updateTargetPositions();
        });

        // Touch move for mobile
        document.addEventListener('touchmove', (e) => {
            if (!this.isEnabled || !e.touches[0]) return;
            
            this.mouseX = e.touches[0].clientX;
            this.mouseY = e.touches[0].clientY;
            
            this.updateTargetPositions();
        });

        // Window resize
        window.addEventListener('resize', () => {
            this.windowWidth = window.innerWidth;
            this.windowHeight = window.innerHeight;
            this.updateTargetPositions();
        });

        // Device orientation for mobile parallax
        if (window.DeviceOrientationEvent) {
            window.addEventListener('deviceorientation', (e) => {
                if (!this.isEnabled) return;
                
                // Use device orientation for mobile parallax
                const gamma = e.gamma || 0; // Left-right tilt (-90 to 90)
                const beta = e.beta || 0;   // Front-back tilt (-180 to 180)
                
                // Convert orientation to mouse-like coordinates
                this.mouseX = this.windowWidth / 2 + (gamma / 90) * (this.windowWidth / 4);
                this.mouseY = this.windowHeight / 2 + (beta / 180) * (this.windowHeight / 4);
                
                this.updateTargetPositions();
            });
        }

        // Pause parallax when page is not visible
        document.addEventListener('visibilitychange', () => {
            this.isEnabled = !document.hidden;
            
            if (!this.isEnabled && this.rafId) {
                cancelAnimationFrame(this.rafId);
                this.rafId = null;
            } else if (this.isEnabled && !this.rafId) {
                this.startAnimation();
            }
        });
    }

    updateTargetPositions() {
        const centerX = this.windowWidth / 2;
        const centerY = this.windowHeight / 2;
        
        // Calculate offset from center
        const offsetX = (this.mouseX - centerX) / centerX;
        const offsetY = (this.mouseY - centerY) / centerY;
        
        // Update target positions for each layer
        this.layers.forEach(layer => {
            layer.targetX = offsetX * layer.speed * 50; // Scale factor for movement
            layer.targetY = offsetY * layer.speed * 50;
        });
    }

    startAnimation() {
        if (!this.isEnabled) return;
        
        this.animate();
    }

    animate() {
        if (!this.isEnabled) return;
        
        let needsUpdate = false;
        
        // Smooth interpolation for each layer
        this.layers.forEach(layer => {
            const ease = 0.08; // Smoothing factor
            
            // Interpolate current position towards target
            const deltaX = layer.targetX - layer.currentX;
            const deltaY = layer.targetY - layer.currentY;
            
            if (Math.abs(deltaX) > 0.01 || Math.abs(deltaY) > 0.01) {
                layer.currentX += deltaX * ease;
                layer.currentY += deltaY * ease;
                needsUpdate = true;
                
                // Apply transform
                layer.element.style.transform = 
                    `translate(${layer.currentX}px, ${layer.currentY}px)`;
            }
        });
        
        // Continue animation if needed
        if (needsUpdate || this.isEnabled) {
            this.rafId = requestAnimationFrame(() => this.animate());
        }
    }

    // Public methods for controlling parallax
    enable() {
        this.isEnabled = true;
        if (!this.rafId) {
            this.startAnimation();
        }
    }

    disable() {
        this.isEnabled = false;
        if (this.rafId) {
            cancelAnimationFrame(this.rafId);
            this.rafId = null;
        }
        
        // Reset all layers to center
        this.layers.forEach(layer => {
            layer.currentX = 0;
            layer.currentY = 0;
            layer.targetX = 0;
            layer.targetY = 0;
            layer.element.style.transform = 'translate(0px, 0px)';
        });
    }

    setIntensity(intensity) {
        // Adjust speed of all layers
        this.layers.forEach(layer => {
            const baseSpeed = parseFloat(layer.element.dataset.speed) || 0.02;
            layer.speed = baseSpeed * intensity;
        });
    }

    addLayer(element, speed = 0.02) {
        const layer = {
            element: element,
            speed: speed,
            currentX: 0,
            currentY: 0,
            targetX: 0,
            targetY: 0
        };
        
        this.layers.push(layer);
        element.dataset.speed = speed;
        
        console.log('🎯 Added new parallax layer');
    }

    removeLayer(element) {
        const index = this.layers.findIndex(layer => layer.element === element);
        if (index !== -1) {
            this.layers.splice(index, 1);
            element.style.transform = '';
            console.log('🎯 Removed parallax layer');
        }
    }
}

// Enhanced cursor effects for interactive elements
class CursorEffects {
    constructor() {
        this.cursor = null;
        this.isTouch = 'ontouchstart' in window;
        
        if (!this.isTouch) {
            this.init();
        }
    }

    init() {
        this.createCustomCursor();
        this.setupEventListeners();
    }

    createCustomCursor() {
        // Create custom cursor element
        this.cursor = document.createElement('div');
        this.cursor.className = 'custom-cursor';
        this.cursor.innerHTML = `
            <div class="cursor-dot"></div>
            <div class="cursor-ring"></div>
        `;
        
        document.body.appendChild(this.cursor);
        
        // Add cursor styles
        const style = document.createElement('style');
        style.textContent = `
            .custom-cursor {
                position: fixed;
                top: 0;
                left: 0;
                pointer-events: none;
                z-index: 9999;
                mix-blend-mode: difference;
            }
            
            .cursor-dot {
                width: 6px;
                height: 6px;
                background: var(--c3);
                border-radius: 50%;
                transform: translate(-50%, -50%);
                transition: all 0.1s ease;
            }
            
            .cursor-ring {
                position: absolute;
                top: 0;
                left: 0;
                width: 24px;
                height: 24px;
                border: 1px solid var(--c3);
                border-radius: 50%;
                transform: translate(-50%, -50%);
                transition: all 0.15s ease;
                opacity: 0.5;
            }
            
            .custom-cursor.hover .cursor-dot {
                transform: translate(-50%, -50%) scale(1.5);
                background: var(--c2);
            }
            
            .custom-cursor.hover .cursor-ring {
                transform: translate(-50%, -50%) scale(1.5);
                border-color: var(--c2);
                opacity: 1;
            }
            
            .custom-cursor.click .cursor-dot {
                transform: translate(-50%, -50%) scale(0.8);
            }
            
            .custom-cursor.click .cursor-ring {
                transform: translate(-50%, -50%) scale(0.8);
            }
            
            body {
                cursor: none;
            }
            
            a, button, [role="button"], .clickable {
                cursor: none;
            }
        `;
        
        document.head.appendChild(style);
    }

    setupEventListeners() {
        if (!this.cursor) return;
        
        // Mouse move
        document.addEventListener('mousemove', (e) => {
            this.cursor.style.left = e.clientX + 'px';
            this.cursor.style.top = e.clientY + 'px';
        });

        // Hover effects
        document.addEventListener('mouseover', (e) => {
            if (this.isInteractiveElement(e.target)) {
                this.cursor.classList.add('hover');
            }
        });

        document.addEventListener('mouseout', (e) => {
            if (this.isInteractiveElement(e.target)) {
                this.cursor.classList.remove('hover');
            }
        });

        // Click effects
        document.addEventListener('mousedown', () => {
            this.cursor.classList.add('click');
        });

        document.addEventListener('mouseup', () => {
            this.cursor.classList.remove('click');
        });

        // Hide cursor when leaving window
        document.addEventListener('mouseleave', () => {
            this.cursor.style.opacity = '0';
        });

        document.addEventListener('mouseenter', () => {
            this.cursor.style.opacity = '1';
        });
    }

    isInteractiveElement(element) {
        const interactiveSelectors = [
            'a', 'button', 'input', 'textarea', 'select',
            '[role="button"]', '[tabindex]', '.clickable',
            '.nav-tab', '.chat-item', '.character-card',
            '.message-bubble', '.resource-item'
        ];
        
        return interactiveSelectors.some(selector => 
            element.matches && element.matches(selector)
        );
    }
}

// Initialize parallax and cursor systems
let parallaxCursor;
let cursorEffects;

document.addEventListener('DOMContentLoaded', () => {
    // Initialize parallax cursor
    parallaxCursor = new ParallaxCursor();
    window.parallaxCursor = parallaxCursor;
    
    // Initialize cursor effects (desktop only)
    cursorEffects = new CursorEffects();
    window.cursorEffects = cursorEffects;
    
    // Performance optimization: reduce parallax on low-end devices
    if (navigator.hardwareConcurrency && navigator.hardwareConcurrency < 4) {
        parallaxCursor.setIntensity(0.5);
        console.log('🎯 Reduced parallax intensity for low-end device');
    }
    
    // Disable parallax on mobile to save battery
    if (window.innerWidth < 768) {
        parallaxCursor.disable();
        console.log('🎯 Parallax disabled on mobile device');
    }
});
