// Menu Manager Class
class MenuManager {
    constructor() {
        this.currentSubmenu = null;
        this.debug = new URLSearchParams(window.location.search).get('debug') === 'true';
        this.init();
    }

    init() {
        if (this.debug) {
            console.log('MenuManager: Initializing...');
        }
        
        // Add event listeners
        this.addEventListeners();
        
        // Create background elements
        this.createBackgroundElements();
        
        // Add smooth transitions to ajax content
        const ajaxContent = document.getElementById('ajax-content');
        if (ajaxContent) {
            ajaxContent.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
        }
        
        if (this.debug) {
            console.log('MenuManager: Initialization complete');
        }
    }

    addEventListeners() {
        // Listen for clicks outside of menus to close them
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.menu-card')) {
                this.closeAllSubmenus();
            }
        });
    }

    // Toggle submenu function
    toggleSubmenu(submenuId) {
        if (this.debug) {
            console.log(`MenuManager: Toggling submenu ${submenuId}`);
        }
        
        const submenu = document.getElementById(submenuId);
        if (!submenu) {
            console.warn(`MenuManager: Submenu ${submenuId} not found`);
            return;
        }
        
        const isExpanded = submenu.classList.contains('open');
        const parentCard = submenu.closest('.menu-card');
        
        // Close all other submenus
        this.closeAllSubmenus(submenuId);
        
        // Toggle current submenu
        if (isExpanded) {
            submenu.classList.remove('open');
            if (parentCard) {
                parentCard.classList.remove('open');
            }
        } else {
            submenu.classList.add('open');
            if (parentCard) {
                parentCard.classList.add('open');
            }
        }
    }

    // Close all submenus except the specified one
    closeAllSubmenus(exceptId = null) {
        document.querySelectorAll('.submenu-container').forEach(menu => {
            if (menu.id !== exceptId) {
                menu.classList.remove('open');
                const parentCard = menu.closest('.menu-card');
                if (parentCard) {
                    parentCard.classList.remove('open');
                }
            }
        });
    }

    // AJAX Content Loading
    async loadContent(page) {
        if (this.debug) {
            console.log(`MenuManager: Loading content for ${page}`);
        }

        // Play click sound
        if (window.audioManager) {
            window.audioManager.playSound('click');
        }

        this.showLoadingSpinner();

        try {
            // Handle character pages - direct navigation for now
            if (page.startsWith('character-')) {
                if (this.debug) {
                    console.log(`MenuManager: Navigating to character page: ${page}`);
                }
                window.location.href = `${page}.php`;
                return;
            }

            const response = await fetch(`${page}.php`);

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const html = await response.text();

            // Extract content from the response
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            const newContent = doc.querySelector('.content-container') || doc.querySelector('main') || doc.querySelector('body');

            if (newContent) {
                const ajaxContent = document.getElementById('ajax-content');
                if (!ajaxContent) {
                    // If no ajax-content container, navigate to the page
                    window.location.href = `${page}.php`;
                    return;
                }

                ajaxContent.style.opacity = '0';
                ajaxContent.style.transform = 'translateY(20px)';

                setTimeout(() => {
                    ajaxContent.innerHTML = newContent.innerHTML;
                    ajaxContent.style.opacity = '1';
                    ajaxContent.style.transform = 'translateY(0)';

                    // Add back button if not main menu
                    if (page !== 'main-menu') {
                        this.addBackButton();
                    }

                    // Initialize page-specific functionality
                    this.initializePageFeatures(page);

                    // Update page title
                    const pageTitle = doc.querySelector('title');
                    if (pageTitle) {
                        document.title = pageTitle.textContent;
                    }

                    // Update URL without page reload
                    if (history.pushState) {
                        history.pushState({page: page}, '', `${page}.php`);
                    }

                    this.hideLoadingSpinner();
                }, 300);
            } else {
                throw new Error('Content not found in response');
            }
        } catch (error) {
            console.error('MenuManager: Error loading content:', error);
            this.hideLoadingSpinner();
            this.showNotification('İçerik yüklenirken hata oluştu!');

            // Fallback to direct navigation
            window.location.href = `${page}.php`;
        }
    }

    addBackButton() {
        const content = document.getElementById('ajax-content');
        if (!content.querySelector('.ajax-back-button')) {
            const backButton = document.createElement('div');
            backButton.className = 'ajax-back-button';
            backButton.innerHTML = `
                <button onclick="menuManager.loadMainMenu()" class="btn">
                    <span class="back-icon">←</span>
                    <span>Ana Menü</span>
                </button>
            `;
            content.insertBefore(backButton, content.firstChild);
        }
    }

    loadMainMenu() {
        if (this.debug) {
            console.log('MenuManager: Loading main menu');
        }
        
        const ajaxContent = document.getElementById('ajax-content');
        
        ajaxContent.style.opacity = '0';
        ajaxContent.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            // Reload the entire page to ensure all data is fresh
            location.reload();
        }, 300);
    }

    initializePageFeatures(page) {
        if (this.debug) {
            console.log(`MenuManager: Initializing features for ${page}`);
        }
        
        switch(page) {
            case 'characters':
                this.initializeCharacterCards();
                break;
            case 'collection':
                this.initializeCollectionCards();
                break;
            case 'story-mode':
                this.initializeStoryMode();
                // Set up periodic updates for countdown timers
                this.setupStoryModeUpdates();
                break;
            case 'settings':
                this.initializeSettings();
                break;
        }
    }

    initializeCharacterCards() {
        document.querySelectorAll('.character-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-8px) scale(1.02)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0) scale(1)';
            });
        });
    }

    initializeCollectionCards() {
        document.querySelectorAll('.glass-card, .event-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-5px) scale(1.02)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0) scale(1)';
            });
        });
    }

    initializeStoryMode() {
        // Story mode specific initialization
        if (this.debug) {
            console.log('MenuManager: Story mode initialized');
        }
        
        // Add any story mode specific functionality here
        this.initializeStoryModeCountdown();
    }
    
    initializeStoryModeCountdown() {
        // Update countdown timers periodically
        setInterval(() => {
            const countdownElements = document.querySelectorAll('.countdown');
            countdownElements.forEach(element => {
                // In a real implementation, this would update the countdown
                // For now, we'll just leave it as is
            });
        }, 60000); // Update every minute
    }
    
    setupStoryModeUpdates() {
        // Set up periodic updates for story mode
        if (this.storyModeInterval) {
            clearInterval(this.storyModeInterval);
        }
        
        this.storyModeInterval = setInterval(() => {
            // Update countdowns
            this.updateStoryModeCountdowns();
        }, 60000); // Update every minute
    }
    
    updateStoryModeCountdowns() {
        // In a real implementation, this would fetch updated countdown data from the server
        // For now, we'll just log to console if in debug mode
        if (this.debug) {
            console.log('MenuManager: Updating story mode countdowns');
        }
    }

    initializeSettings() {
        this.showNotification('Ayarlar sayfası yakında hazır olacak!');
    }
    
    showCharacterDetails(characterId) {
        // Map character IDs to character names
        const characterMap = {
            1: 'leo',
            2: 'chloe',
            3: 'felix',
            4: 'elara'
        };
        
        const characterName = characterMap[characterId];
        if (characterName) {
            // Navigate directly to the character page instead of using AJAX
            window.location.href = 'character-' + characterName + '.php';
        } else {
            this.showNotification('Karakter bulunamadı!');
        }
    }
    
    playChapter(chapterId) {
        // Navigate to chapter play page
        window.location.href = 'chapter-play.php?chapter=' + chapterId;
    }

    showLoadingSpinner() {
        if (document.getElementById('loading-spinner')) return;
        
        const spinner = document.createElement('div');
        spinner.id = 'loading-spinner';
        spinner.innerHTML = `
            <div class="loading-container">
                <div class="loading-spinner"></div>
                <p>Yükleniyor...</p>
            </div>
        `;
        document.body.appendChild(spinner);
    }

    hideLoadingSpinner() {
        const spinner = document.getElementById('loading-spinner');
        if (spinner) {
            document.body.removeChild(spinner);
        }
    }

    // Create floating particles
    createFloatingParticles() {
        const container = document.querySelector('.floating-particles');
        if (!container) return;
        
        const particleCount = 20;
        
        for (let i = 0; i < particleCount; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            particle.style.left = Math.random() * 100 + '%';
            particle.style.animationDelay = Math.random() * 10 + 's';
            particle.style.animationDuration = (Math.random() * 20 + 10) + 's';
            container.appendChild(particle);
        }
    }

    // Create starfield
    createStarfield() {
        const starfield = document.querySelector('.starfield');
        if (!starfield) return;
        
        const starCount = 100;
        
        for (let i = 0; i < starCount; i++) {
            const star = document.createElement('div');
            star.className = 'star';
            star.style.left = Math.random() * 100 + '%';
            star.style.top = Math.random() * 100 + '%';
            star.style.animationDelay = Math.random() * 3 + 's';
            starfield.appendChild(star);
        }
    }

    createBackgroundElements() {
        this.createFloatingParticles();
        this.createStarfield();
    }

    showNotification(message) {
        // Remove any existing notifications
        const existing = document.querySelector('.notification');
        if (existing) {
            existing.remove();
        }
        
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.innerHTML = `
            <div class="notification-content">
                <div class="notification-icon">✨</div>
                <span>${message}</span>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }

    handleLogout() {
        const confirmation = document.createElement('div');
        confirmation.className = 'confirmation-modal';
        confirmation.innerHTML = `
            <div class="confirmation-content">
                <h3>Çıkış Yapmak İstiyor Musun?</h3>
                <p>Oyundaki ilerleme kaydedilecek</p>
                <div class="confirmation-buttons">
                    <button class="btn-secondary" onclick="menuManager.closeConfirmation()">İptal</button>
                    <button class="btn" onclick="window.location.href='../index.php'">Çıkış Yap</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(confirmation);
        setTimeout(() => confirmation.classList.add('show'), 100);
    }

    closeConfirmation() {
        const confirmation = document.querySelector('.confirmation-modal');
        if (confirmation) {
            confirmation.classList.remove('show');
            setTimeout(() => {
                if (confirmation.parentNode) {
                    confirmation.parentNode.removeChild(confirmation);
                }
            }, 300);
        }
    }
}

// Initialize MenuManager when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.menuManager = new MenuManager();
});