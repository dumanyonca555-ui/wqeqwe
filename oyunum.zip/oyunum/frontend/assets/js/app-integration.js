// ===== APPLICATION INTEGRATION SYSTEM =====

class AppIntegration {
    constructor() {
        this.systems = {
            loadingManager: null,
            settingsManager: null,
            audioManager: null,
            dataManager: null,
            navigationManager: null,
            parallaxCursor: null
        };
        
        this.initializationOrder = [
            'loadingManager',
            'dataManager', 
            'settingsManager',
            'audioManager',
            'navigationManager',
            'parallaxCursor'
        ];
        
        this.initialized = false;
        this.initPromise = null;
        
        this.init();
    }

    async init() {
        if (this.initPromise) return this.initPromise;
        
        this.initPromise = this.performInitialization();
        return this.initPromise;
    }

    async performInitialization() {
        console.log('🚀 App Integration Starting...');
        
        try {
            // Wait for DOM to be ready
            await this.waitForDOM();
            
            // Initialize systems in order
            await this.initializeSystems();
            
            // Setup cross-system integrations
            this.setupIntegrations();
            
            // Setup global error handling
            this.setupErrorHandling();
            
            // Setup performance monitoring
            this.setupPerformanceMonitoring();
            
            // Mark as initialized
            this.initialized = true;
            
            console.log('✅ App Integration Complete!');
            
            // Trigger ready event
            this.triggerEvent('appReady', {
                systems: Object.keys(this.systems),
                initTime: performance.now()
            });
            
        } catch (error) {
            console.error('❌ App Integration Failed:', error);
            this.handleInitializationError(error);
        }
    }

    async waitForDOM() {
        if (document.readyState === 'loading') {
            return new Promise(resolve => {
                document.addEventListener('DOMContentLoaded', resolve, { once: true });
            });
        }
    }

    async initializeSystems() {
        for (const systemName of this.initializationOrder) {
            try {
                await this.initializeSystem(systemName);
            } catch (error) {
                console.error(`Failed to initialize ${systemName}:`, error);
                // Continue with other systems
            }
        }
    }

    async initializeSystem(systemName) {
        console.log(`🔧 Initializing ${systemName}...`);
        
        // Wait for system to be available
        await this.waitForSystem(systemName);
        
        // Get system instance
        this.systems[systemName] = window[systemName];
        
        // System-specific initialization
        switch (systemName) {
            case 'loadingManager':
                // Loading manager initializes immediately
                break;
                
            case 'dataManager':
                // Ensure data is loaded
                if (this.systems.dataManager && this.systems.dataManager.loadAllData) {
                    this.systems.dataManager.loadAllData();
                }
                break;
                
            case 'settingsManager':
                // Apply settings after data manager is ready
                if (this.systems.settingsManager && this.systems.settingsManager.applySettings) {
                    this.systems.settingsManager.applySettings();
                }
                break;
                
            case 'audioManager':
                // Start background music if enabled
                if (this.systems.audioManager && this.systems.settingsManager) {
                    const audioSettings = this.systems.settingsManager.get('audio');
                    if (audioSettings.backgroundMusicEnabled) {
                        setTimeout(() => {
                            this.systems.audioManager.playMusic();
                        }, 1000);
                    }
                }
                break;
                
            case 'navigationManager':
                // Navigation manager handles its own initialization
                break;
                
            case 'parallaxCursor':
                // Enable/disable based on settings
                if (this.systems.parallaxCursor && this.systems.settingsManager) {
                    const displaySettings = this.systems.settingsManager.get('display');
                    if (!displaySettings.cursorEffectsEnabled) {
                        this.systems.parallaxCursor.disable();
                    }
                }
                break;
        }
        
        console.log(`✅ ${systemName} initialized`);
    }

    async waitForSystem(systemName, timeout = 5000) {
        const startTime = Date.now();
        
        while (!window[systemName] && (Date.now() - startTime) < timeout) {
            await new Promise(resolve => setTimeout(resolve, 100));
        }
        
        if (!window[systemName]) {
            throw new Error(`System ${systemName} not available after ${timeout}ms`);
        }
    }

    setupIntegrations() {
        console.log('🔗 Setting up system integrations...');
        
        // Settings <-> Audio integration
        this.setupSettingsAudioIntegration();
        
        // Data <-> UI integration
        this.setupDataUIIntegration();
        
        // Navigation <-> Audio integration
        this.setupNavigationAudioIntegration();
        
        // Performance <-> Settings integration
        this.setupPerformanceSettingsIntegration();
        
        // Global event listeners
        this.setupGlobalEventListeners();
    }

    setupSettingsAudioIntegration() {
        if (!this.systems.settingsManager || !this.systems.audioManager) return;
        
        // Listen for audio setting changes
        this.systems.settingsManager.on('settingChanged', (data) => {
            if (data.category === 'audio') {
                switch (data.key) {
                    case 'masterVolume':
                        this.systems.audioManager.setMasterVolume(data.value);
                        break;
                    case 'musicVolume':
                        this.systems.audioManager.setMusicVolume(data.value);
                        break;
                    case 'sfxVolume':
                        this.systems.audioManager.setSfxVolume(data.value);
                        break;
                    case 'muted':
                        if (data.value !== this.systems.audioManager.isMuted()) {
                            this.systems.audioManager.toggleMute();
                        }
                        break;
                }
            }
        });
    }

    setupDataUIIntegration() {
        if (!this.systems.dataManager) return;
        
        // Update UI when resources change
        document.addEventListener('resourcesUpdated', (e) => {
            this.updateResourceDisplays(e.detail);
        });
        
        // Update UI when character data changes
        document.addEventListener('affinityUpdated', (e) => {
            this.updateCharacterDisplays(e.detail);
        });
        
        // Save data when important events occur
        document.addEventListener('characterUnlocked', () => {
            this.systems.dataManager.forceSave();
        });
        
        document.addEventListener('achievementUnlocked', () => {
            this.systems.dataManager.forceSave();
        });
    }

    setupNavigationAudioIntegration() {
        if (!this.systems.navigationManager || !this.systems.audioManager) return;
        
        // Play sounds on navigation
        document.addEventListener('pageChanged', (e) => {
            this.systems.audioManager.playSound('click');
            
            // Page-specific audio
            switch (e.detail.newPage) {
                case 'enhanced-store':
                    // Could play store-specific sound
                    break;
                case 'enhanced-gallery':
                    // Could play gallery-specific sound
                    break;
            }
        });
    }

    setupPerformanceSettingsIntegration() {
        if (!this.systems.settingsManager) return;
        
        // Apply performance settings
        const displaySettings = this.systems.settingsManager.get('display');
        
        if (displaySettings.reducedMotion) {
            document.documentElement.style.setProperty('--transition-fast', '0s');
            document.documentElement.style.setProperty('--transition-smooth', '0s');
        }
        
        // Monitor performance and adjust settings if needed
        if (this.systems.loadingManager) {
            const metrics = this.systems.loadingManager.getPerformanceMetrics();
            if (metrics.resourcesLoaded < metrics.totalResources * 0.8) {
                console.warn('⚠️ Poor loading performance detected');
                // Could automatically disable some visual effects
            }
        }
    }

    setupGlobalEventListeners() {
        // Handle visibility changes
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                this.onAppHidden();
            } else {
                this.onAppVisible();
            }
        });
        
        // Handle online/offline status
        window.addEventListener('online', () => {
            this.onAppOnline();
        });
        
        window.addEventListener('offline', () => {
            this.onAppOffline();
        });
        
        // Handle errors
        window.addEventListener('error', (e) => {
            this.handleGlobalError(e);
        });
        
        window.addEventListener('unhandledrejection', (e) => {
            this.handleGlobalError(e);
        });
    }

    setupErrorHandling() {
        // Global error handler
        window.onerror = (message, source, lineno, colno, error) => {
            console.error('Global Error:', { message, source, lineno, colno, error });
            this.reportError('javascript', { message, source, lineno, colno, error });
            return false;
        };
        
        // Promise rejection handler
        window.addEventListener('unhandledrejection', (event) => {
            console.error('Unhandled Promise Rejection:', event.reason);
            this.reportError('promise', event.reason);
        });
    }

    setupPerformanceMonitoring() {
        // Monitor frame rate
        let frameCount = 0;
        let lastTime = performance.now();
        
        const monitorFPS = () => {
            frameCount++;
            const currentTime = performance.now();
            
            if (currentTime - lastTime >= 1000) {
                const fps = Math.round((frameCount * 1000) / (currentTime - lastTime));
                
                if (fps < 30) {
                    console.warn(`⚠️ Low FPS detected: ${fps}`);
                    this.handleLowPerformance();
                }
                
                frameCount = 0;
                lastTime = currentTime;
            }
            
            requestAnimationFrame(monitorFPS);
        };
        
        requestAnimationFrame(monitorFPS);
    }

    // Event handlers
    onAppHidden() {
        console.log('📱 App hidden');
        
        // Pause audio
        if (this.systems.audioManager) {
            this.systems.audioManager.pauseMusic();
        }
        
        // Save data
        if (this.systems.dataManager) {
            this.systems.dataManager.forceSave();
        }
    }

    onAppVisible() {
        console.log('📱 App visible');
        
        // Resume audio
        if (this.systems.audioManager) {
            this.systems.audioManager.resumeMusic();
        }
    }

    onAppOnline() {
        console.log('🌐 App online');
        this.showNotification('İnternet bağlantısı yeniden kuruldu', 'success');
    }

    onAppOffline() {
        console.log('📴 App offline');
        this.showNotification('İnternet bağlantısı kesildi. Oyun çevrimdışı modda devam ediyor.', 'warning');
    }

    handleLowPerformance() {
        console.log('🐌 Handling low performance');
        
        // Automatically reduce visual effects
        if (this.systems.settingsManager) {
            this.systems.settingsManager.set('display', 'animationsEnabled', false);
            this.systems.settingsManager.set('display', 'particleEffectsEnabled', false);
        }
        
        // Disable parallax cursor
        if (this.systems.parallaxCursor) {
            this.systems.parallaxCursor.disable();
        }
        
        this.showNotification('Performans optimizasyonu uygulandı', 'info');
    }

    handleGlobalError(error) {
        console.error('Handling global error:', error);
        
        // Show user-friendly error message
        this.showNotification('Bir hata oluştu. Sayfa yeniden yüklenecek.', 'error');
        
        // Auto-reload after delay
        setTimeout(() => {
            window.location.reload();
        }, 3000);
    }

    handleInitializationError(error) {
        console.error('Initialization error:', error);
        
        // Show fallback UI
        document.body.innerHTML = `
            <div style="
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                height: 100vh;
                background: var(--accent-grad);
                color: var(--c5);
                text-align: center;
                padding: 20px;
            ">
                <h1>Celestial Tale</h1>
                <p>Oyun yüklenirken bir hata oluştu.</p>
                <button onclick="window.location.reload()" style="
                    background: var(--glass-bg);
                    border: 1px solid var(--glass-border);
                    color: var(--c5);
                    padding: 12px 24px;
                    border-radius: 24px;
                    cursor: pointer;
                    margin-top: 20px;
                ">Yeniden Yükle</button>
            </div>
        `;
    }

    // Utility methods
    updateResourceDisplays(resources) {
        // Update resource displays across the app
        const displays = {
            'neural-fragments': resources.neuralFragments || resources.neural,
            'memory-shards': resources.memoryShards || resources.memory,
            'data-points': resources.dataPoints || resources.data
        };
        
        Object.entries(displays).forEach(([id, value]) => {
            const element = document.getElementById(id);
            if (element && value !== undefined) {
                element.textContent = value;
                
                // Add update animation
                element.style.transform = 'scale(1.1)';
                element.style.color = 'var(--c3)';
                setTimeout(() => {
                    element.style.transform = '';
                    element.style.color = '';
                }, 200);
            }
        });
    }

    updateCharacterDisplays(data) {
        // Update character affinity displays
        const affinityElements = document.querySelectorAll(`[data-character="${data.characterId}"] .affinity-progress`);
        affinityElements.forEach(element => {
            element.style.width = `${data.affinity}%`;
        });
    }

    showNotification(message, type = 'info') {
        // Use existing notification system or create simple one
        if (window.novelApp && window.novelApp.showNotification) {
            window.novelApp.showNotification(message, type);
        } else {
            console.log(`${type.toUpperCase()}: ${message}`);
        }
    }

    reportError(type, error) {
        // Report error to analytics (if enabled)
        if (this.systems.settingsManager) {
            const privacySettings = this.systems.settingsManager.get('privacy');
            if (privacySettings.crashReporting) {
                console.log('📊 Error reported:', { type, error });
                // Could send to analytics service
            }
        }
    }

    triggerEvent(eventName, data) {
        const event = new CustomEvent(eventName, { detail: data });
        document.dispatchEvent(event);
    }

    // Public API
    isInitialized() {
        return this.initialized;
    }

    getSystem(name) {
        return this.systems[name];
    }

    getAllSystems() {
        return { ...this.systems };
    }

    async waitForInitialization() {
        if (this.initialized) return true;
        return this.initPromise;
    }
}

// Initialize App Integration
const appIntegration = new AppIntegration();
window.appIntegration = appIntegration;

// Export for use in other scripts
window.waitForApp = () => appIntegration.waitForInitialization();
