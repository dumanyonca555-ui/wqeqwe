// ===== CHARACTER SYSTEM SCRIPT =====

class CharacterSystem {
    constructor() {
        this.characters = {};
        this.affinityAnimations = new Map();
        this.unlockCosts = {
            felix: 100,
            elara: 150
        };
        
        this.init();
    }

    init() {
        console.log('👥 Character System Initializing...');
        
        this.loadCharacterData();
        this.setupEventListeners();
        this.startAffinityAnimations();
        
        console.log('✅ Character System Ready!');
    }

    loadCharacterData() {
        // Load character data from main app or API
        if (window.novelApp && window.novelApp.characters) {
            this.characters = window.novelApp.characters;
        } else {
            // Fallback character data
            this.characters = {
                leo: {
                    id: 'leo',
                    name: 'Leo',
                    title: 'The Strategist',
                    affinity: 75,
                    status: 'online',
                    unlocked: true,
                    premium: false,
                    lastInteraction: new Date(Date.now() - 300000) // 5 minutes ago
                },
                chloe: {
                    id: 'chloe',
                    name: 'Chloe',
                    title: 'The Hacker',
                    affinity: 60,
                    status: 'away',
                    unlocked: true,
                    premium: false,
                    lastInteraction: new Date(Date.now() - 600000) // 10 minutes ago
                },
                felix: {
                    id: 'felix',
                    name: 'Felix',
                    title: 'The Heart',
                    affinity: 90,
                    status: 'offline',
                    unlocked: false,
                    premium: true,
                    lastInteraction: new Date(Date.now() - 3600000) // 1 hour ago
                },
                elara: {
                    id: 'elara',
                    name: 'Elara',
                    title: 'The Mentor',
                    affinity: 45,
                    status: 'offline',
                    unlocked: false,
                    premium: true,
                    lastInteraction: new Date(Date.now() - 7200000) // 2 hours ago
                }
            };
        }
    }

    setupEventListeners() {
        // Character card interactions
        document.addEventListener('click', (e) => {
            const characterCard = e.target.closest('.character-card');
            if (characterCard) {
                const characterId = characterCard.dataset.characterId;
                if (characterId) {
                    this.handleCharacterCardClick(characterId, e);
                }
            }
        });

        // Affinity bar interactions
        document.addEventListener('click', (e) => {
            if (e.target.closest('.affinity-bar')) {
                const characterCard = e.target.closest('.character-card');
                if (characterCard) {
                    const characterId = characterCard.dataset.characterId;
                    this.showAffinityDetails(characterId);
                }
            }
        });

        // Character action buttons
        document.addEventListener('click', (e) => {
            if (e.target.matches('[onclick*="openCharacterProfile"]')) {
                e.preventDefault();
                const match = e.target.getAttribute('onclick').match(/'([^']+)'/);
                if (match) {
                    this.openCharacterProfile(match[1]);
                }
            }
            
            if (e.target.matches('[onclick*="startPrivateChat"]')) {
                e.preventDefault();
                const match = e.target.getAttribute('onclick').match(/'([^']+)'/);
                if (match) {
                    this.startPrivateChat(match[1]);
                }
            }
        });
    }

    handleCharacterCardClick(characterId, event) {
        const character = this.characters[characterId];
        if (!character) return;
        
        // Prevent default if clicking on buttons
        if (event.target.closest('button')) return;
        
        console.log(`👤 Character card clicked: ${characterId}`);
        
        // Add click animation
        const card = event.currentTarget;
        card.style.transform = 'scale(0.98)';
        setTimeout(() => {
            card.style.transform = '';
        }, 150);
        
        // Show character quick info
        this.showCharacterQuickInfo(characterId);
    }

    showCharacterQuickInfo(characterId) {
        const character = this.characters[characterId];
        if (!character) return;
        
        const statusEmoji = {
            online: '🟢',
            away: '🟡',
            offline: '⚫'
        };
        
        const message = `${statusEmoji[character.status]} ${character.name} - ${character.title}\n` +
                       `Affinity: ${character.affinity}/100\n` +
                       `Status: ${character.status}\n` +
                       `Last seen: ${this.formatLastSeen(character.lastInteraction)}`;
        
        if (window.novelApp) {
            window.novelApp.showNotification(message, 'info');
        }
    }

    openCharacterProfile(characterId) {
        console.log(`👤 Opening profile for: ${characterId}`);
        
        const character = this.characters[characterId];
        if (!character) return;
        
        // Navigate to character page
        window.location.href = `character-${characterId}.php`;
    }

    startPrivateChat(characterId) {
        const character = this.characters[characterId];
        if (!character) return;
        
        console.log(`💬 Starting private chat with: ${characterId}`);
        
        if (character.premium && !character.unlocked) {
            this.showUnlockModal(characterId);
        } else {
            // Switch to private chat
            if (window.novelApp) {
                window.novelApp.switchChat(characterId);
                window.novelApp.navigateToPage('chat');
            }
        }
    }

    showUnlockModal(characterId) {
        const character = this.characters[characterId];
        const cost = this.unlockCosts[characterId] || 100;
        
        const modalHTML = `
            <div class="modal">
                <div class="modal-header">
                    <h2>Unlock Private Chat</h2>
                    <p>Start an intimate conversation with ${character.name}</p>
                </div>
                <div class="modal-content">
                    <div class="unlock-preview">
                        <div class="character-portrait">
                            <img src="assets/images/characters/${characterId}-portrait.png" 
                                 alt="${character.name}"
                                 onerror="this.src='assets/images/characters/leo-portrait.png'">
                        </div>
                        <h3>${character.name}</h3>
                        <p>${character.title}</p>
                        <div class="unlock-cost">
                            <span class="cost-icon">🧠</span>
                            <span class="cost-amount">${cost}</span>
                            <span class="cost-label">Neural Fragments</span>
                        </div>
                        <div class="unlock-benefits">
                            <h4>Unlock Benefits:</h4>
                            <ul>
                                <li>💬 Private chat access</li>
                                <li>📞 Voice call simulation</li>
                                <li>💕 Exclusive story content</li>
                                <li>🎁 Special interactions</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="modal-actions">
                    <button class="modal-btn" onclick="characterSystem.closeModal()">Cancel</button>
                    <button class="modal-btn primary" onclick="characterSystem.unlockCharacter('${characterId}')">
                        Unlock for ${cost} 🧠
                    </button>
                </div>
            </div>
        `;
        
        this.showModal(modalHTML);
    }

    unlockCharacter(characterId) {
        const character = this.characters[characterId];
        const cost = this.unlockCosts[characterId] || 100;
        
        // Check if user has enough resources
        if (window.novelApp && window.novelApp.resources.neuralFragments >= cost) {
            // Deduct cost
            window.novelApp.resources.neuralFragments -= cost;
            
            // Unlock character
            character.unlocked = true;
            
            // Update UI
            this.updateCharacterCard(characterId);
            this.updateResourceDisplay();
            
            // Close modal
            this.closeModal();
            
            // Show success notification
            if (window.novelApp) {
                window.novelApp.showNotification(
                    `🎉 ${character.name} unlocked! Private chat is now available.`,
                    'success'
                );
            }
            
            // Start private chat
            setTimeout(() => {
                this.startPrivateChat(characterId);
            }, 1000);
            
        } else {
            // Not enough resources
            if (window.novelApp) {
                window.novelApp.showNotification(
                    `❌ Not enough Neural Fragments! You need ${cost} but only have ${window.novelApp.resources.neuralFragments}.`,
                    'error'
                );
            }
        }
    }

    updateCharacterCard(characterId) {
        const card = document.querySelector(`[data-character-id="${characterId}"]`);
        if (!card) return;
        
        const character = this.characters[characterId];
        
        // Update premium button
        const chatBtn = card.querySelector('.character-btn:last-child');
        if (chatBtn) {
            if (character.unlocked) {
                chatBtn.textContent = '💬 Chat';
                chatBtn.classList.remove('premium');
                chatBtn.setAttribute('onclick', `novelApp.startPrivateChat('${characterId}')`);
            }
        }
        
        // Remove premium badge from name
        const nameElement = card.querySelector('.character-name');
        if (nameElement && character.unlocked) {
            nameElement.textContent = character.name;
        }
    }

    updateResourceDisplay() {
        if (window.novelApp) {
            const neuralFragmentsEl = document.getElementById('neural-fragments');
            if (neuralFragmentsEl) {
                window.novelApp.animateCounterUpdate(
                    neuralFragmentsEl, 
                    window.novelApp.resources.neuralFragments
                );
            }
        }
    }

    showAffinityDetails(characterId) {
        const character = this.characters[characterId];
        if (!character) return;
        
        const affinityLevel = this.getAffinityLevel(character.affinity);
        const nextMilestone = this.getNextMilestone(character.affinity);
        
        let message = `💕 ${character.name} Affinity: ${character.affinity}/100\n`;
        message += `Level: ${affinityLevel}\n`;
        
        if (nextMilestone) {
            message += `Next milestone: ${nextMilestone.level} (${nextMilestone.threshold}/100)`;
        }
        
        if (window.novelApp) {
            window.novelApp.showNotification(message, 'info');
        }
    }

    getAffinityLevel(affinity) {
        if (affinity >= 90) return 'Soulmate 💖';
        if (affinity >= 75) return 'Beloved 💕';
        if (affinity >= 60) return 'Close Friend 💙';
        if (affinity >= 40) return 'Friend 💚';
        if (affinity >= 20) return 'Acquaintance 💛';
        return 'Stranger 🤍';
    }

    getNextMilestone(affinity) {
        const milestones = [
            { threshold: 20, level: 'Acquaintance' },
            { threshold: 40, level: 'Friend' },
            { threshold: 60, level: 'Close Friend' },
            { threshold: 75, level: 'Beloved' },
            { threshold: 90, level: 'Soulmate' }
        ];
        
        return milestones.find(m => m.threshold > affinity);
    }

    startAffinityAnimations() {
        // Animate affinity bars on page load
        setTimeout(() => {
            document.querySelectorAll('.affinity-progress').forEach(bar => {
                const width = bar.style.width || '0%';
                bar.style.width = '0%';
                
                setTimeout(() => {
                    bar.style.width = width;
                }, 100);
            });
        }, 500);
    }

    increaseAffinity(characterId, amount = 1) {
        const character = this.characters[characterId];
        if (!character) return;
        
        const oldAffinity = character.affinity;
        character.affinity = Math.min(100, character.affinity + amount);
        
        // Update UI
        const card = document.querySelector(`[data-character-id="${characterId}"]`);
        if (card) {
            const progressBar = card.querySelector('.affinity-progress');
            const affinityLabel = card.querySelector('.affinity-label span:last-child');
            
            if (progressBar) {
                progressBar.style.width = `${character.affinity}%`;
            }
            
            if (affinityLabel) {
                affinityLabel.textContent = `${character.affinity}/100`;
            }
        }
        
        // Show notification for significant increases
        if (character.affinity - oldAffinity >= 5) {
            if (window.novelApp) {
                window.novelApp.showNotification(
                    `💕 ${character.name} affinity increased to ${character.affinity}!`,
                    'success'
                );
            }
        }
        
        console.log(`💕 ${character.name} affinity: ${oldAffinity} → ${character.affinity}`);
    }

    showModal(content) {
        const overlay = document.getElementById('modal-overlay');
        if (overlay) {
            overlay.innerHTML = content;
            overlay.classList.add('active');
        }
    }

    closeModal() {
        const overlay = document.getElementById('modal-overlay');
        if (overlay) {
            overlay.classList.remove('active');
            setTimeout(() => {
                overlay.innerHTML = '';
            }, 300);
        }
    }

    formatLastSeen(timestamp) {
        const now = new Date();
        const diff = now - timestamp;
        
        if (diff < 60000) return 'Just now';
        if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
        if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
        return `${Math.floor(diff / 86400000)}d ago`;
    }

    // Public API methods
    getCharacter(characterId) {
        return this.characters[characterId];
    }

    getAllCharacters() {
        return this.characters;
    }

    isCharacterUnlocked(characterId) {
        const character = this.characters[characterId];
        return character && (!character.premium || character.unlocked);
    }
}

// Initialize character system
let characterSystem;

document.addEventListener('DOMContentLoaded', () => {
    characterSystem = new CharacterSystem();
    window.characterSystem = characterSystem;
});
