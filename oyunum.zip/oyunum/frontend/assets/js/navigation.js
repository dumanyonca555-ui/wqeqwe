// ===== NAVIGATION SYSTEM =====

class NavigationManager {
    constructor() {
        this.currentPage = this.getCurrentPageFromURL();
        this.history = [];
        this.breadcrumbs = [];
        
        this.init();
    }

    init() {
        console.log('🧭 Navigation Manager Initializing...');

        this.setupEventListeners();
        // this.setupBreadcrumbs(); // Disabled - no breadcrumbs needed
        this.removeBreadcrumbs(); // Remove any existing breadcrumbs
        this.setupBackButton();
        this.setupKeyboardShortcuts();

        console.log('✅ Navigation Manager Ready!');
    }

    getCurrentPageFromURL() {
        const path = window.location.pathname;
        const filename = path.split('/').pop().replace('.php', '');
        return filename || 'main-menu';
    }

    setupEventListeners() {
        // Handle all navigation links
        document.addEventListener('click', (e) => {
            const link = e.target.closest('a[href]');
            if (link && this.isInternalLink(link.href)) {
                this.handleNavigation(e, link);
            }
        });

        // Handle browser back/forward
        window.addEventListener('popstate', (e) => {
            if (e.state && e.state.page) {
                this.navigateToPage(e.state.page, false);
            }
        });

        // Handle page visibility changes
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                this.onPageHidden();
            } else {
                this.onPageVisible();
            }
        });
    }

    isInternalLink(href) {
        try {
            const url = new URL(href, window.location.origin);
            return url.origin === window.location.origin && url.pathname.endsWith('.php');
        } catch {
            return false;
        }
    }

    handleNavigation(event, link) {
        // Don't intercept if it's a special link
        if (link.target === '_blank' || link.download || event.ctrlKey || event.metaKey) {
            return;
        }

        event.preventDefault();
        
        const href = link.href;
        const pageName = this.getPageNameFromURL(href);
        
        // Add to history
        this.addToHistory(this.currentPage);
        
        // Navigate
        this.navigateToPage(pageName, true);
        
        // Play navigation sound
        if (window.audioManager) {
            window.audioManager.playSound('click');
        }
    }

    getPageNameFromURL(url) {
        try {
            const urlObj = new URL(url);
            return urlObj.pathname.split('/').pop().replace('.php', '');
        } catch {
            return 'main-menu';
        }
    }

    navigateToPage(pageName, addToHistory = true) {
        console.log(`🧭 Navigating to: ${pageName}`);
        
        // Update current page
        const oldPage = this.currentPage;
        this.currentPage = pageName;
        
        // Update URL if needed
        if (addToHistory) {
            const newURL = `${pageName}.php`;
            history.pushState({ page: pageName }, '', newURL);
        }
        
        // Update breadcrumbs - Disabled
        // this.updateBreadcrumbs(pageName);
        
        // Trigger page change event
        this.triggerPageChangeEvent(oldPage, pageName);
        
        // Handle page-specific logic
        this.handlePageSpecificLogic(pageName);
    }

    addToHistory(pageName) {
        if (pageName && pageName !== this.history[this.history.length - 1]) {
            this.history.push(pageName);
            
            // Keep history reasonable size
            if (this.history.length > 10) {
                this.history.shift();
            }
        }
    }

    setupBreadcrumbs() {
        // Create breadcrumb container if it doesn't exist
        let breadcrumbContainer = document.getElementById('breadcrumbs');
        if (!breadcrumbContainer) {
            breadcrumbContainer = document.createElement('nav');
            breadcrumbContainer.id = 'breadcrumbs';
            breadcrumbContainer.className = 'breadcrumbs';
            breadcrumbContainer.style.cssText = `
                padding: 12px 20px;
                background: var(--glass-bg);
                backdrop-filter: var(--blur-glass);
                border-bottom: 1px solid var(--glass-border);
                font-size: 0.9rem;
                color: var(--c4);
            `;
            
            // Insert at top of body or main container
            const mainContainer = document.querySelector('.app-container, .settings-container, .gallery-container, .store-container, main');
            if (mainContainer) {
                mainContainer.insertBefore(breadcrumbContainer, mainContainer.firstChild);
            }
        }
        
        this.updateBreadcrumbs(this.currentPage);
    }

    updateBreadcrumbs(currentPage) {
        const breadcrumbContainer = document.getElementById('breadcrumbs');
        if (!breadcrumbContainer) return;
        
        const breadcrumbs = this.generateBreadcrumbs(currentPage);
        
        breadcrumbContainer.innerHTML = breadcrumbs.map((crumb, index) => {
            if (index === breadcrumbs.length - 1) {
                // Current page - not clickable
                return `<span class="breadcrumb-current">${crumb.title}</span>`;
            } else {
                // Previous pages - clickable
                return `<a href="${crumb.url}" class="breadcrumb-link">${crumb.title}</a>`;
            }
        }).join(' <span class="breadcrumb-separator">›</span> ');
        
        // Add breadcrumb styles
        const style = document.createElement('style');
        style.textContent = `
            .breadcrumb-link {
                color: var(--c3);
                text-decoration: none;
                transition: color var(--transition-fast);
            }
            .breadcrumb-link:hover {
                color: var(--c5);
            }
            .breadcrumb-current {
                color: var(--c5);
                font-weight: 500;
            }
            .breadcrumb-separator {
                margin: 0 8px;
                opacity: 0.6;
            }
        `;
        
        if (!document.getElementById('breadcrumb-styles')) {
            style.id = 'breadcrumb-styles';
            document.head.appendChild(style);
        }
    }

    generateBreadcrumbs(currentPage) {
        const pageMap = {
            'main-menu': { title: '🏠 Ana Menü', url: 'main-menu.php' },
            'settings': { title: '⚙️ Ayarlar', url: 'settings.php' },
            'enhanced-gallery': { title: '🎨 Galeri', url: 'enhanced-gallery.php' },
            'enhanced-store': { title: '💎 Mağaza', url: 'enhanced-store.php' },
            'interactive-novel': { title: '💬 Sohbet', url: 'interactive-novel.php' },
            'character-leo': { title: '👤 Leo', url: 'character-leo.php' },
            'character-chloe': { title: '👤 Chloe', url: 'character-chloe.php' },
            'character-felix': { title: '👤 Felix', url: 'character-felix.php' },
            'character-elara': { title: '👤 Elara', url: 'character-elara.php' },
            'collection': { title: '📚 Koleksiyon', url: 'collection.php' },
            'gallery': { title: '🖼️ Galeri', url: 'gallery.php' }
        };
        
        const breadcrumbs = [];
        
        // Always start with home
        if (currentPage !== 'main-menu') {
            breadcrumbs.push(pageMap['main-menu']);
        }
        
        // Add current page
        if (pageMap[currentPage]) {
            breadcrumbs.push(pageMap[currentPage]);
        }
        
        return breadcrumbs;
    }

    removeBreadcrumbs() {
        // Remove any existing breadcrumb elements
        const breadcrumbElements = document.querySelectorAll('#breadcrumbs, .breadcrumbs, nav[class*="breadcrumb"]');
        breadcrumbElements.forEach(element => {
            console.log('🗑️ Removing breadcrumb element:', element);
            element.remove();
        });

        // Remove breadcrumb styles
        const breadcrumbStyles = document.getElementById('breadcrumb-styles');
        if (breadcrumbStyles) {
            breadcrumbStyles.remove();
        }

        console.log('✅ Breadcrumbs removed successfully');
    }

    setupBackButton() {
        // Create floating back button
        const backButton = document.createElement('button');
        backButton.id = 'floating-back-btn';
        backButton.innerHTML = '🏠';
        backButton.title = 'Ana Menüye Dön';
        backButton.style.cssText = `
            position: fixed;
            bottom: 20px;
            left: 20px;
            width: 60px;
            height: 60px;
            background: var(--gradient-secondary);
            border: 1px solid var(--glass-border);
            border-radius: 50%;
            color: var(--color5);
            font-size: 1.5rem;
            cursor: pointer;
            z-index: 1000;
            box-shadow: var(--shadow-glow);
            transition: all var(--transition-normal);
            opacity: 1;
            transform: scale(1);
            pointer-events: all;
            backdrop-filter: blur(var(--blur-md));
            font-family: 'Montserrat', sans-serif;
        `;

        backButton.addEventListener('click', () => {
            window.location.href = 'main-menu.php';
        });

        backButton.addEventListener('mouseenter', () => {
            backButton.style.transform = 'scale(1.1)';
            backButton.style.boxShadow = 'var(--shadow-glow), 0 0 20px rgba(123, 159, 255, 0.4)';
        });

        backButton.addEventListener('mouseleave', () => {
            backButton.style.transform = 'scale(1)';
            backButton.style.boxShadow = 'var(--shadow-glow)';
        });

        document.body.appendChild(backButton);

        // Always show on non-main-menu pages
        this.updateBackButtonVisibility();
    }

    updateBackButtonVisibility() {
        const backButton = document.getElementById('floating-back-btn');
        if (!backButton) return;

        // Show on all pages except main-menu
        if (this.currentPage !== 'main-menu') {
            backButton.style.opacity = '1';
            backButton.style.transform = 'scale(1)';
            backButton.style.pointerEvents = 'all';
        } else {
            backButton.style.opacity = '0';
            backButton.style.transform = 'scale(0.8)';
            backButton.style.pointerEvents = 'none';
        }
    }

    goBack() {
        if (this.history.length > 0) {
            const previousPage = this.history.pop();
            this.navigateToPage(previousPage, true);
            this.updateBackButtonVisibility();
            
            if (window.audioManager) {
                window.audioManager.playSound('click');
            }
        }
    }

    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // Alt + Left Arrow = Go back
            if (e.altKey && e.key === 'ArrowLeft') {
                e.preventDefault();
                this.goBack();
            }
            
            // Alt + H = Go home
            if (e.altKey && e.key === 'h') {
                e.preventDefault();
                this.navigateToPage('main-menu', true);
            }
            
            // Alt + S = Settings
            if (e.altKey && e.key === 's') {
                e.preventDefault();
                this.navigateToPage('settings', true);
            }
            
            // Alt + G = Gallery
            if (e.altKey && e.key === 'g') {
                e.preventDefault();
                this.navigateToPage('enhanced-gallery', true);
            }
            
            // Alt + M = Store (Market)
            if (e.altKey && e.key === 'm') {
                e.preventDefault();
                this.navigateToPage('enhanced-store', true);
            }
        });
    }

    handlePageSpecificLogic(pageName) {
        // Page-specific initialization logic
        switch (pageName) {
            case 'settings':
                // Settings page specific logic
                break;
            case 'enhanced-gallery':
                // Gallery page specific logic
                break;
            case 'enhanced-store':
                // Store page specific logic
                break;
            case 'interactive-novel':
                // Chat page specific logic
                break;
        }
    }

    triggerPageChangeEvent(oldPage, newPage) {
        const event = new CustomEvent('pageChanged', {
            detail: { oldPage, newPage }
        });
        document.dispatchEvent(event);
    }

    onPageHidden() {
        // Pause audio when page is hidden
        if (window.audioManager) {
            window.audioManager.pauseMusic();
        }
    }

    onPageVisible() {
        // Resume audio when page is visible
        if (window.audioManager) {
            window.audioManager.resumeMusic();
        }
    }

    // Public API methods
    getCurrentPage() {
        return this.currentPage;
    }

    getHistory() {
        return [...this.history];
    }

    canGoBack() {
        return this.history.length > 0;
    }

    // Quick navigation methods
    goHome() {
        this.navigateToPage('main-menu', true);
    }

    goToSettings() {
        this.navigateToPage('settings', true);
    }

    goToGallery() {
        this.navigateToPage('enhanced-gallery', true);
    }

    goToStore() {
        this.navigateToPage('enhanced-store', true);
    }

    goToChat() {
        this.navigateToPage('interactive-novel', true);
    }
}

// Initialize Navigation Manager
let navigationManager;

document.addEventListener('DOMContentLoaded', () => {
    navigationManager = new NavigationManager();
    window.navigationManager = navigationManager;
    
    // Listen for page changes to update back button
    document.addEventListener('pageChanged', () => {
        navigationManager.updateBackButtonVisibility();
    });
});
