// Mobile and Android WebView Optimizations

document.addEventListener('DOMContentLoaded', function() {
    // Initialize mobile optimizations
    initMobileOptimizations();
    
    // Initialize viewport height handling
    initViewportHeight();
    
    // Initialize touch optimizations
    initTouchOptimizations();
    
    // Initialize keyboard handling
    initKeyboardHandling();
    
    // Initialize performance optimizations
    initPerformanceOptimizations();
});

function initMobileOptimizations() {
    // Detect mobile device
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    const isAndroid = /Android/i.test(navigator.userAgent);
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
    
    if (isMobile) {
        document.body.classList.add('mobile');
        
        if (isAndroid) {
            document.body.classList.add('android');
        }
        
        if (isIOS) {
            document.body.classList.add('ios');
        }
        
        // Add mobile-specific CSS
        const mobileCSS = document.createElement('link');
        mobileCSS.rel = 'stylesheet';
        mobileCSS.href = '/assets/css/mobile.css';
        document.head.appendChild(mobileCSS);
        
        // Add CSS to prevent double-tap zoom
        const preventZoomCSS = document.createElement('style');
        preventZoomCSS.textContent = `
            * {
                touch-action: manipulation;
            }
            input, textarea, select {
                touch-action: manipulation;
            }
        `;
        document.head.appendChild(preventZoomCSS);
    }
    
    // Prevent zoom on double tap - use passive listener to avoid intervention warnings
    let lastTouchEnd = 0;
    document.addEventListener('touchend', function(event) {
        const now = (new Date()).getTime();
        if (now - lastTouchEnd <= 300) {
            // Use a more gentle approach to prevent double-tap zoom
            // Instead of preventing the event, we'll handle it differently
            event.stopPropagation();
        }
        lastTouchEnd = now;
    }, { passive: true });
    
    // Prevent pull-to-refresh
    document.addEventListener('touchstart', function(e) {
        if (e.touches.length > 1 && e.cancelable && !e.defaultPrevented) {
            try {
                e.preventDefault();
            } catch (error) {
                console.debug('Could not prevent default touchstart event');
            }
        }
    }, { passive: false });
    
    document.addEventListener('touchmove', function(e) {
        if (e.touches.length > 1 && e.cancelable && !e.defaultPrevented) {
            try {
                e.preventDefault();
            } catch (error) {
                console.debug('Could not prevent default touchmove event');
            }
        }
    }, { passive: false });
}

function initViewportHeight() {
    // Set CSS custom property for viewport height
    function setViewportHeight() {
        const vh = window.innerHeight * 0.01;
        document.documentElement.style.setProperty('--vh', `${vh}px`);
    }
    
    // Set initial viewport height
    setViewportHeight();
    
    // Update on resize
    window.addEventListener('resize', debounce(setViewportHeight, 100));
    
    // Update on orientation change
    window.addEventListener('orientationchange', function() {
        setTimeout(setViewportHeight, 100);
    });
}

function initTouchOptimizations() {
    // Add touch feedback to interactive elements
    const touchElements = document.querySelectorAll('button, .menu-btn, .social-btn, .submit-btn, .back-btn');
    
    touchElements.forEach(element => {
        element.addEventListener('touchstart', function() {
            this.style.transform = 'scale(0.95)';
            this.style.transition = 'transform 0.1s ease';
        });
        
        element.addEventListener('touchend', function() {
            this.style.transform = 'scale(1)';
        });
        
        element.addEventListener('touchcancel', function() {
            this.style.transform = 'scale(1)';
        });
    });
    
    // Improve touch scrolling
    const scrollableElements = document.querySelectorAll('.chat-messages, .main-container');
    
    scrollableElements.forEach(element => {
        element.style.webkitOverflowScrolling = 'touch';
        element.style.overflowScrolling = 'touch';
    });
}

function initKeyboardHandling() {
    const messageInput = document.getElementById('message-input');
    const chatroomContainer = document.querySelector('.chatroom-container');
    
    if (messageInput && chatroomContainer) {
        let keyboardOpen = false;
        
        // Detect keyboard open/close
        const initialViewportHeight = window.innerHeight;
        
        function handleResize() {
            const currentHeight = window.innerHeight;
            const heightDifference = initialViewportHeight - currentHeight;
            
            if (heightDifference > 150) {
                // Keyboard is likely open
                if (!keyboardOpen) {
                    keyboardOpen = true;
                    document.body.classList.add('keyboard-open');
                    adjustChatroomForKeyboard(true);
                }
            } else {
                // Keyboard is likely closed
                if (keyboardOpen) {
                    keyboardOpen = false;
                    document.body.classList.remove('keyboard-open');
                    adjustChatroomForKeyboard(false);
                }
            }
        }
        
        window.addEventListener('resize', debounce(handleResize, 100));
        
        // Focus handling
        messageInput.addEventListener('focus', function() {
            // Prevent zoom on iOS
            if (/iPad|iPhone|iPod/.test(navigator.userAgent)) {
                this.style.fontSize = '16px';
            }
            
            // Scroll to input after a short delay
            setTimeout(() => {
                this.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }, 300);
        });
        
        messageInput.addEventListener('blur', function() {
            // Reset font size
            this.style.fontSize = '';
        });
    }
}

function adjustChatroomForKeyboard(keyboardOpen) {
    const chatroomContainer = document.querySelector('.chatroom-container');
    const chatMessages = document.querySelector('.chat-messages');
    
    if (keyboardOpen) {
        if (chatroomContainer) {
            chatroomContainer.style.height = 'calc(100vh - 300px)';
        }
        if (chatMessages) {
            chatMessages.style.maxHeight = 'calc(100vh - 400px)';
        }
    } else {
        if (chatroomContainer) {
            chatroomContainer.style.height = '';
        }
        if (chatMessages) {
            chatMessages.style.maxHeight = '';
        }
    }
}

function initPerformanceOptimizations() {
    // Reduce animation complexity on mobile
    if (window.innerWidth < 768) {
        // Disable complex animations
        const style = document.createElement('style');
        style.textContent = `
            .star { animation-duration: 4s; }
            .cloud { animation-duration: 20s; }
            .shooting-star { animation-duration: 6s; }
            .character-glow { animation-duration: 10s; }
        `;
        document.head.appendChild(style);
    }
    
    // Optimize scroll performance
    let ticking = false;
    
    function updateScrollPosition() {
        // Update scroll position for smooth scrolling
        ticking = false;
    }
    
    function requestScrollUpdate() {
        if (!ticking) {
            requestAnimationFrame(updateScrollPosition);
            ticking = true;
        }
    }
    
    const chatMessages = document.querySelector('.chat-messages');
    if (chatMessages) {
        chatMessages.addEventListener('scroll', requestScrollUpdate, { passive: true });
    }
    
    // Lazy load images
    const images = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                observer.unobserve(img);
            }
        });
    });
    
    images.forEach(img => imageObserver.observe(img));
}

// Mobile-specific utility functions
function isMobile() {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}

function isAndroid() {
    return /Android/i.test(navigator.userAgent);
}

function isIOS() {
    return /iPad|iPhone|iPod/.test(navigator.userAgent);
}

function vibrate(pattern = 50) {
    if ('vibrate' in navigator) {
        navigator.vibrate(pattern);
    }
}

function showToast(message, duration = 3000) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    toast.style.cssText = `
        position: fixed;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
        background: rgba(0, 0, 0, 0.8);
        color: white;
        padding: 12px 20px;
        border-radius: 25px;
        font-size: 14px;
        z-index: 1000;
        animation: fadeInUp 0.3s ease;
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'fadeOutDown 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

// Add toast animations
const toastStyles = document.createElement('style');
toastStyles.textContent = `
    @keyframes fadeInUp {
        from { opacity: 0; transform: translateX(-50%) translateY(20px); }
        to { opacity: 1; transform: translateX(-50%) translateY(0); }
    }
    
    @keyframes fadeOutDown {
        from { opacity: 1; transform: translateX(-50%) translateY(0); }
        to { opacity: 0; transform: translateX(-50%) translateY(20px); }
    }
`;
document.head.appendChild(toastStyles);

// Handle app state changes
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        // App is in background
        console.log('App backgrounded');
    } else {
        // App is in foreground
        console.log('App foregrounded');
        
        // Refresh viewport height
        const vh = window.innerHeight * 0.01;
        document.documentElement.style.setProperty('--vh', `${vh}px`);
    }
});

// Handle page load
window.addEventListener('load', function() {
    // Hide loading spinner if exists
    const loader = document.querySelector('.loader');
    if (loader) {
        loader.style.opacity = '0';
        setTimeout(() => loader.remove(), 300);
    }
    
    // Initialize mobile features
    if (isMobile()) {
        // Add mobile-specific event listeners
        document.addEventListener('touchstart', function() {}, { passive: true });
        document.addEventListener('touchmove', function() {}, { passive: true });
    }
});

// Export mobile utilities
window.MobileUtils = {
    isMobile,
    isAndroid,
    isIOS,
    vibrate,
    showToast,
    debounce
};
