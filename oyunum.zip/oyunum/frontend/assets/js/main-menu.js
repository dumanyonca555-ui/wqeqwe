// Main Menu Application
class MainMenuApp {
    constructor() {
        this.debug = new URLSearchParams(window.location.search).get('debug') === 'true';
        this.initTime = performance.now();
        
        if (this.debug) {
            console.log('MainMenuApp: Initializing...');
        }
        
        this.init();
    }

    init() {
        // Initialize components
        this.initComponents();
        
        // Add global event handlers
        this.addGlobalEventHandlers();
        
        if (this.debug) {
            const loadTime = performance.now() - this.initTime;
            console.log(`MainMenuApp: Initialization complete in ${loadTime.toFixed(2)}ms`);
        }
    }

    initComponents() {
        // Components are initialized separately
        // MenuManager is initialized in menu-manager.js
        // AudioManager is initialized in audio-manager.js
    }

    addGlobalEventHandlers() {
        // Global click handler for menu items
        document.addEventListener('click', (e) => {
            // Handle settings context menu (right-click)
            if (e.target.closest('[onclick*="loadContent(\'settings\')"]') && e.button === 2) {
                e.preventDefault();
                if (window.menuManager) {
                    window.menuManager.handleLogout();
                }
            }
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            // ESC key to close modals
            if (e.key === 'Escape') {
                if (window.menuManager) {
                    window.menuManager.closeConfirmation();
                }
            }
            
            // Debug toggle
            if (e.ctrlKey && e.key === 'd') {
                e.preventDefault();
                this.toggleDebug();
            }
        });
    }

    toggleDebug() {
        this.debug = !this.debug;
        if (this.debug) {
            console.log('MainMenuApp: Debug mode enabled');
        } else {
            console.log('MainMenuApp: Debug mode disabled');
        }
    }

    // Global function to show notifications
    showNotification(message) {
        if (window.menuManager) {
            window.menuManager.showNotification(message);
        } else {
            // Fallback to alert if menuManager is not available
            alert(message);
        }
    }

    // Global function to load content
    loadContent(page) {
        if (window.menuManager) {
            window.menuManager.loadContent(page);
        } else {
            console.error('MenuManager not available');
        }
    }

    // Global function to toggle submenus
    toggleSubmenu(submenuId) {
        if (window.menuManager) {
            window.menuManager.toggleSubmenu(submenuId);
        } else {
            console.error('MenuManager not available');
        }
    }

    // Global function to show character details
    showCharacterDetails(characterId) {
        if (window.menuManager) {
            window.menuManager.showCharacterDetails(characterId);
        } else {
            console.error('MenuManager not available');
        }
    }

    // Global function to handle logout
    handleLogout() {
        if (window.menuManager) {
            window.menuManager.handleLogout();
        } else {
            // Fallback to direct redirect if menuManager is not available
            window.location.href = '../index.php';
        }
    }
}

// Initialize the main application when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.mainMenuApp = new MainMenuApp();
    
    // Expose global functions for inline onclick handlers
    window.showNotification = function(message) {
        if (window.mainMenuApp) {
            window.mainMenuApp.showNotification(message);
        }
    };
    
    window.loadContent = function(page) {
        if (window.mainMenuApp) {
            window.mainMenuApp.loadContent(page);
        }
    };
    
    window.toggleSubmenu = function(submenuId) {
        if (window.mainMenuApp) {
            window.mainMenuApp.toggleSubmenu(submenuId);
        }
    };
    
    window.showCharacterDetails = function(characterId) {
        if (window.mainMenuApp) {
            window.mainMenuApp.showCharacterDetails(characterId);
        }
    };
    
    window.handleLogout = function() {
        if (window.mainMenuApp) {
            window.mainMenuApp.handleLogout();
        }
    };
});