// ===== COMPREHENSIVE SETTINGS MANAGER =====

class SettingsManager {
    constructor() {
        this.settings = this.getDefaultSettings();
        this.listeners = {};
        this.storageKey = 'celestial_tale_settings';
        
        this.init();
    }

    init() {
        console.log('⚙️ Settings Manager Initializing...');
        
        this.loadSettings();
        this.setupEventListeners();
        this.applySettings();
        
        console.log('✅ Settings Manager Ready!');
    }

    getDefaultSettings() {
        return {
            audio: {
                masterVolume: 1.0,
                musicVolume: 0.5,
                sfxVolume: 0.7,
                muted: false,
                musicMuted: false,
                sfxMuted: false,
                backgroundMusicEnabled: true,
                notificationSoundsEnabled: true
            },
            display: {
                theme: 'dark',
                textSpeed: 50, // Characters per second
                fontSize: 'medium', // small, medium, large
                animationsEnabled: true,
                particleEffectsEnabled: true,
                cursorEffectsEnabled: true,
                reducedMotion: false
            },
            notifications: {
                desktopNotifications: false,
                inGameNotifications: true,
                messageNotifications: true,
                eventNotifications: true,
                vibrationEnabled: true,
                notificationTiming: 'immediate' // immediate, delayed, off
            },
            account: {
                username: 'Player',
                email: '',
                profilePicture: 'default',
                language: 'tr',
                autoSave: true,
                dataCollection: false
            },
            gameplay: {
                autoAdvance: false,
                skipRead: false,
                confirmChoices: true,
                showHints: true,
                difficulty: 'normal'
            },
            privacy: {
                analytics: false,
                crashReporting: true,
                personalizedContent: true
            }
        };
    }

    loadSettings() {
        try {
            const savedSettings = localStorage.getItem(this.storageKey);
            if (savedSettings) {
                const parsed = JSON.parse(savedSettings);
                this.settings = this.mergeSettings(this.getDefaultSettings(), parsed);
                console.log('⚙️ Settings loaded from localStorage');
            } else {
                console.log('⚙️ Using default settings');
            }
        } catch (error) {
            console.warn('⚙️ Failed to load settings, using defaults:', error);
            this.settings = this.getDefaultSettings();
        }
    }

    saveSettings() {
        try {
            localStorage.setItem(this.storageKey, JSON.stringify(this.settings));
            console.log('⚙️ Settings saved to localStorage');
            
            // Trigger save event
            this.trigger('settingsSaved', this.settings);
        } catch (error) {
            console.error('⚙️ Failed to save settings:', error);
        }
    }

    mergeSettings(defaults, saved) {
        const merged = { ...defaults };
        
        for (const category in saved) {
            if (merged[category]) {
                merged[category] = { ...merged[category], ...saved[category] };
            }
        }
        
        return merged;
    }

    setupEventListeners() {
        // Listen for settings changes from UI
        document.addEventListener('settingChanged', (e) => {
            const { category, key, value } = e.detail;
            this.set(category, key, value);
        });

        // Listen for reset settings
        document.addEventListener('resetSettings', () => {
            this.resetToDefaults();
        });

        // Listen for export/import
        document.addEventListener('exportSettings', () => {
            this.exportSettings();
        });

        document.addEventListener('importSettings', (e) => {
            this.importSettings(e.detail.data);
        });
    }

    applySettings() {
        // Apply audio settings
        if (window.audioManager) {
            const audio = this.settings.audio;
            window.audioManager.setMasterVolume(audio.masterVolume);
            window.audioManager.setMusicVolume(audio.musicVolume);
            window.audioManager.setSfxVolume(audio.sfxVolume);
            
            if (audio.muted) window.audioManager.toggleMute();
            if (audio.musicMuted) window.audioManager.toggleMusicMute();
            if (audio.sfxMuted) window.audioManager.toggleSfxMute();
        }

        // Apply display settings
        this.applyDisplaySettings();

        // Apply notification settings
        this.applyNotificationSettings();

        // Apply account settings
        this.applyAccountSettings();
    }

    applyDisplaySettings() {
        const display = this.settings.display;
        const root = document.documentElement;

        // Apply theme
        root.setAttribute('data-theme', display.theme);

        // Apply font size
        root.setAttribute('data-font-size', display.fontSize);

        // Apply animations
        if (!display.animationsEnabled) {
            root.style.setProperty('--transition-fast', '0s');
            root.style.setProperty('--transition-smooth', '0s');
        }

        // Apply reduced motion
        if (display.reducedMotion) {
            root.style.setProperty('--transition-fast', '0s');
            root.style.setProperty('--transition-smooth', '0s');
        }

        // Apply cursor effects
        if (window.parallaxCursor) {
            if (display.cursorEffectsEnabled) {
                window.parallaxCursor.enable();
            } else {
                window.parallaxCursor.disable();
            }
        }

        // Apply particle effects
        const particleElements = document.querySelectorAll('.particle-effect');
        particleElements.forEach(el => {
            el.style.display = display.particleEffectsEnabled ? 'block' : 'none';
        });
    }

    applyNotificationSettings() {
        const notifications = this.settings.notifications;

        // Request desktop notification permission if enabled
        if (notifications.desktopNotifications && 'Notification' in window) {
            if (Notification.permission === 'default') {
                Notification.requestPermission();
            }
        }

        // Apply vibration settings for mobile
        if (!notifications.vibrationEnabled && 'vibrate' in navigator) {
            // Disable vibration
            navigator.vibrate = () => {};
        }
    }

    applyAccountSettings() {
        const account = this.settings.account;

        // Update username display
        const usernameElements = document.querySelectorAll('.username-display');
        usernameElements.forEach(el => {
            el.textContent = account.username;
        });

        // Apply language (if implemented)
        if (account.language !== 'tr') {
            console.log(`⚙️ Language setting: ${account.language} (not implemented yet)`);
        }
    }

    // Get setting value
    get(category, key = null) {
        if (key === null) {
            return this.settings[category] || {};
        }
        return this.settings[category] ? this.settings[category][key] : undefined;
    }

    // Set setting value
    set(category, key, value) {
        if (!this.settings[category]) {
            this.settings[category] = {};
        }

        const oldValue = this.settings[category][key];
        this.settings[category][key] = value;

        // Apply setting immediately
        this.applySingleSetting(category, key, value);

        // Save settings
        this.saveSettings();

        // Trigger change event
        this.trigger('settingChanged', { category, key, value, oldValue });

        console.log(`⚙️ Setting changed: ${category}.${key} = ${value}`);
    }

    applySingleSetting(category, key, value) {
        switch (category) {
            case 'audio':
                this.applyAudioSetting(key, value);
                break;
            case 'display':
                this.applyDisplaySetting(key, value);
                break;
            case 'notifications':
                this.applyNotificationSetting(key, value);
                break;
            case 'account':
                this.applyAccountSetting(key, value);
                break;
        }
    }

    applyAudioSetting(key, value) {
        if (!window.audioManager) return;

        switch (key) {
            case 'masterVolume':
                window.audioManager.setMasterVolume(value);
                break;
            case 'musicVolume':
                window.audioManager.setMusicVolume(value);
                break;
            case 'sfxVolume':
                window.audioManager.setSfxVolume(value);
                break;
            case 'muted':
                if (value !== window.audioManager.isMuted()) {
                    window.audioManager.toggleMute();
                }
                break;
            case 'musicMuted':
                if (value !== window.audioManager.musicMuted) {
                    window.audioManager.toggleMusicMute();
                }
                break;
            case 'sfxMuted':
                if (value !== window.audioManager.sfxMuted) {
                    window.audioManager.toggleSfxMute();
                }
                break;
        }
    }

    applyDisplaySetting(key, value) {
        const root = document.documentElement;

        switch (key) {
            case 'theme':
                root.setAttribute('data-theme', value);
                break;
            case 'fontSize':
                root.setAttribute('data-font-size', value);
                break;
            case 'animationsEnabled':
                if (!value) {
                    root.style.setProperty('--transition-fast', '0s');
                    root.style.setProperty('--transition-smooth', '0s');
                } else {
                    root.style.removeProperty('--transition-fast');
                    root.style.removeProperty('--transition-smooth');
                }
                break;
            case 'cursorEffectsEnabled':
                if (window.parallaxCursor) {
                    value ? window.parallaxCursor.enable() : window.parallaxCursor.disable();
                }
                break;
        }
    }

    applyNotificationSetting(key, value) {
        switch (key) {
            case 'desktopNotifications':
                if (value && 'Notification' in window && Notification.permission === 'default') {
                    Notification.requestPermission();
                }
                break;
        }
    }

    applyAccountSetting(key, value) {
        switch (key) {
            case 'username':
                const usernameElements = document.querySelectorAll('.username-display');
                usernameElements.forEach(el => {
                    el.textContent = value;
                });
                break;
        }
    }

    // Reset to default settings
    resetToDefaults() {
        this.settings = this.getDefaultSettings();
        this.saveSettings();
        this.applySettings();
        this.trigger('settingsReset', this.settings);
        console.log('⚙️ Settings reset to defaults');
    }

    // Export settings
    exportSettings() {
        const dataStr = JSON.stringify(this.settings, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(dataBlob);
        
        const link = document.createElement('a');
        link.href = url;
        link.download = 'celestial-tale-settings.json';
        link.click();
        
        URL.revokeObjectURL(url);
        console.log('⚙️ Settings exported');
    }

    // Import settings
    importSettings(data) {
        try {
            const imported = typeof data === 'string' ? JSON.parse(data) : data;
            this.settings = this.mergeSettings(this.getDefaultSettings(), imported);
            this.saveSettings();
            this.applySettings();
            this.trigger('settingsImported', this.settings);
            console.log('⚙️ Settings imported successfully');
            return true;
        } catch (error) {
            console.error('⚙️ Failed to import settings:', error);
            return false;
        }
    }

    // Event system
    on(event, callback) {
        if (!this.listeners[event]) {
            this.listeners[event] = [];
        }
        this.listeners[event].push(callback);
    }

    off(event, callback) {
        if (this.listeners[event]) {
            this.listeners[event] = this.listeners[event].filter(cb => cb !== callback);
        }
    }

    trigger(event, data) {
        if (this.listeners[event]) {
            this.listeners[event].forEach(callback => callback(data));
        }
    }

    // Get all settings
    getAll() {
        return { ...this.settings };
    }

    // Validate settings
    validateSettings(settings) {
        // Add validation logic here
        return true;
    }
}

// Initialize Settings Manager
let settingsManager;

document.addEventListener('DOMContentLoaded', () => {
    settingsManager = new SettingsManager();
    window.settingsManager = settingsManager;
});
