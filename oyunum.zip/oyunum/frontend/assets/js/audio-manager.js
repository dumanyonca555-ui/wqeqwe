// Enhanced Audio Manager Class with Web Audio API and Advanced Features
class AudioManager {
    constructor() {
        this.audioContext = null;
        this.sounds = {};
        this.music = null;
        this.currentTrack = null;
        this.nextTrack = null;
        this.sfxVolume = 0.7;
        this.musicVolume = 0.5;
        this.masterVolume = 1.0;
        this.muted = false;
        this.musicMuted = false;
        this.sfxMuted = false;
        this.debug = new URLSearchParams(window.location.search).get('debug') === 'true';
        this.isInitialized = false;
        this.fadeInProgress = false;
        this.preloadedTracks = {};
        this.characterSounds = {};

        // Settings integration
        this.settings = null;

        // Audio file paths
        this.audioFiles = {
            background: {
                main: 'assets/audio/background-music.mp3',
                menu: 'assets/audio/background-music.mp3', // Can be different
                character: 'assets/audio/background-music.mp3' // Can be different
            },
            sfx: {
                hover: 'assets/audio/sfx/hover_subtle.wav',
                click: 'assets/audio/sfx/click_soft.wav',
                notification: 'assets/audio/sfx/notification_general.wav',
                success: 'assets/audio/sfx/notification_general.wav',
                error: 'assets/audio/sfx/notification_general.wav',
                message: 'assets/audio/sfx/notification_general.wav'
            },
            characters: {
                leo: 'assets/audio/sfx/click_soft.wav',
                chloe: 'assets/audio/sfx/hover_subtle.wav',
                felix: 'assets/audio/sfx/notification_general.wav',
                elara: 'assets/audio/sfx/click_soft.wav'
            }
        };

        this.init();
    }

    async init() {
        if (this.debug) {
            console.log('AudioManager: Initializing enhanced audio system...');
        }

        // Initialize Web Audio API
        await this.initializeWebAudio();

        // Load settings
        this.loadSettings();

        // Load actual sound files
        await this.loadSoundFiles();

        // Load background music
        await this.loadBackgroundMusic();

        // Preload character sounds
        await this.loadCharacterSounds();

        // Add event listeners for user interaction
        this.addInteractionListeners();

        // Start background music if enabled
        this.startBackgroundMusic();

        if (this.debug) {
            console.log('AudioManager: Enhanced initialization complete');
        }
    }

    async initializeWebAudio() {
        try {
            // Create AudioContext for better control
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();

            if (this.debug) {
                console.log('AudioManager: Web Audio API initialized');
            }
        } catch (error) {
            console.warn('AudioManager: Web Audio API not supported, falling back to HTML5 Audio');
            this.audioContext = null;
        }
    }

    loadSettings() {
        // Load settings from localStorage or settings manager
        if (window.settingsManager) {
            this.settings = window.settingsManager;
            const audioSettings = this.settings.get('audio');

            this.masterVolume = audioSettings.masterVolume || 1.0;
            this.musicVolume = audioSettings.musicVolume || 0.5;
            this.sfxVolume = audioSettings.sfxVolume || 0.7;
            this.muted = audioSettings.muted || false;
            this.musicMuted = audioSettings.musicMuted || false;
            this.sfxMuted = audioSettings.sfxMuted || false;
        } else {
            // Fallback to localStorage
            const savedSettings = localStorage.getItem('celestial_audio_settings');
            if (savedSettings) {
                const settings = JSON.parse(savedSettings);
                this.masterVolume = settings.masterVolume || 1.0;
                this.musicVolume = settings.musicVolume || 0.5;
                this.sfxVolume = settings.sfxVolume || 0.7;
                this.muted = settings.muted || false;
                this.musicMuted = settings.musicMuted || false;
                this.sfxMuted = settings.sfxMuted || false;
            }
        }

        if (this.debug) {
            console.log('AudioManager: Settings loaded', {
                masterVolume: this.masterVolume,
                musicVolume: this.musicVolume,
                sfxVolume: this.sfxVolume,
                muted: this.muted
            });
        }
    }

    async loadSoundFiles() {
        const loadPromises = [];

        // Load SFX files
        for (const [name, path] of Object.entries(this.audioFiles.sfx)) {
            const audio = new Audio(path);
            audio.preload = 'auto';
            audio.volume = this.sfxVolume * this.masterVolume;
            this.sounds[name] = audio;

            // Create promise for loading
            loadPromises.push(new Promise((resolve) => {
                audio.addEventListener('canplaythrough', resolve, { once: true });
                audio.addEventListener('error', () => {
                    console.warn(`AudioManager: Failed to load SFX: ${name}`);
                    resolve();
                }, { once: true });
            }));
        }

        try {
            await Promise.all(loadPromises);
            if (this.debug) {
                console.log('AudioManager: All SFX files loaded successfully');
            }
        } catch (error) {
            console.warn('AudioManager: Some SFX files failed to load', error);
        }
    }

    async loadCharacterSounds() {
        const loadPromises = [];

        // Load character-specific sounds
        for (const [character, path] of Object.entries(this.audioFiles.characters)) {
            const audio = new Audio(path);
            audio.preload = 'auto';
            audio.volume = this.sfxVolume * this.masterVolume;
            this.characterSounds[character] = audio;

            loadPromises.push(new Promise((resolve) => {
                audio.addEventListener('canplaythrough', resolve, { once: true });
                audio.addEventListener('error', () => {
                    console.warn(`AudioManager: Failed to load character sound: ${character}`);
                    resolve();
                }, { once: true });
            }));
        }

        try {
            await Promise.all(loadPromises);
            if (this.debug) {
                console.log('AudioManager: Character sounds loaded successfully');
            }
        } catch (error) {
            console.warn('AudioManager: Some character sounds failed to load', error);
        }
    }

    async loadBackgroundMusic() {
        try {
            // Load main background music
            this.music = new Audio(this.audioFiles.background.main);
            this.music.loop = true;
            this.music.volume = this.musicVolume * this.masterVolume;
            this.music.preload = 'auto';
            this.currentTrack = 'main';

            // Preload other tracks
            for (const [name, path] of Object.entries(this.audioFiles.background)) {
                if (name !== 'main') {
                    const audio = new Audio(path);
                    audio.preload = 'auto';
                    audio.loop = true;
                    this.preloadedTracks[name] = audio;
                }
            }

            // Wait for main track to be ready
            await new Promise((resolve) => {
                this.music.addEventListener('canplaythrough', resolve, { once: true });
                this.music.addEventListener('error', () => {
                    console.warn('AudioManager: Failed to load main background music');
                    resolve();
                }, { once: true });
            });

            if (this.debug) {
                console.log('AudioManager: Background music loaded and ready');
            }
        } catch (error) {
            console.warn('AudioManager: Error loading background music', error);
        }
    }

    startBackgroundMusic() {
        if (!this.muted && !this.musicMuted && this.music) {
            // Handle autoplay policy
            this.playMusic();
        }
    }

    addInteractionListeners() {
        // Add click listener to start audio context on first user interaction
        const startAudio = () => {
            if (!this.isInitialized) {
                this.resumeAudioContext();
                this.isInitialized = true;
                document.removeEventListener('click', startAudio);
                document.removeEventListener('touchstart', startAudio);
            }
        };

        document.addEventListener('click', startAudio);
        document.addEventListener('touchstart', startAudio);
    }

    resumeAudioContext() {
        if (this.audioContext && this.audioContext.state === 'suspended') {
            this.audioContext.resume();
        }
    }

    // Play a sound effect with enhanced features
    playSound(soundName, options = {}) {
        if (this.muted || this.sfxMuted || !this.sounds[soundName]) return;

        try {
            const sound = this.sounds[soundName];
            sound.currentTime = 0; // Reset to beginning

            // Apply volume with master volume
            const volume = (options.volume || this.sfxVolume) * this.masterVolume;
            sound.volume = Math.max(0, Math.min(1, volume));

            const playPromise = sound.play();
            if (playPromise !== undefined) {
                playPromise.catch(error => {
                    if (this.debug) {
                        console.warn(`AudioManager: Could not play sound ${soundName}:`, error);
                    }
                });
            }

            if (this.debug) {
                console.log(`AudioManager: Playing sound ${soundName} at volume ${sound.volume}`);
            }
        } catch (error) {
            if (this.debug) {
                console.warn(`AudioManager: Error playing sound ${soundName}:`, error);
            }
        }
    }

    // Play character-specific sound
    playCharacterSound(characterName, options = {}) {
        if (this.muted || this.sfxMuted || !this.characterSounds[characterName]) {
            // Fallback to regular click sound
            this.playSound('click', options);
            return;
        }

        try {
            const sound = this.characterSounds[characterName];
            sound.currentTime = 0;

            const volume = (options.volume || this.sfxVolume) * this.masterVolume;
            sound.volume = Math.max(0, Math.min(1, volume));

            const playPromise = sound.play();
            if (playPromise !== undefined) {
                playPromise.catch(error => {
                    if (this.debug) {
                        console.warn(`AudioManager: Could not play character sound ${characterName}:`, error);
                    }
                    // Fallback to regular click sound
                    this.playSound('click', options);
                });
            }

            if (this.debug) {
                console.log(`AudioManager: Playing character sound for ${characterName}`);
            }
        } catch (error) {
            if (this.debug) {
                console.warn(`AudioManager: Error playing character sound ${characterName}:`, error);
            }
            this.playSound('click', options);
        }
    }

    // Play background music with fade in
    async playMusic(fadeInDuration = 1000) {
        if (this.muted || this.musicMuted || !this.music) return;

        try {
            // Set initial volume to 0 for fade in
            this.music.volume = 0;

            const playPromise = this.music.play();
            if (playPromise !== undefined) {
                await playPromise.catch(error => {
                    if (this.debug) {
                        console.warn('AudioManager: Could not play background music:', error);
                    }
                    throw error;
                });
            }

            // Fade in
            await this.fadeIn(this.music, this.musicVolume * this.masterVolume, fadeInDuration);

            if (this.debug) {
                console.log('AudioManager: Background music playing with fade in');
            }
        } catch (error) {
            if (this.debug) {
                console.warn('AudioManager: Error playing background music:', error);
            }
        }
    }

    // Switch background music track with crossfade
    async switchTrack(trackName, crossfadeDuration = 2000) {
        if (!this.preloadedTracks[trackName]) {
            console.warn(`AudioManager: Track ${trackName} not found`);
            return;
        }

        if (this.fadeInProgress) {
            console.warn('AudioManager: Fade already in progress');
            return;
        }

        this.fadeInProgress = true;
        const newTrack = this.preloadedTracks[trackName];
        newTrack.volume = 0;
        newTrack.loop = true;

        try {
            // Start new track
            await newTrack.play();

            // Crossfade
            await Promise.all([
                this.fadeOut(this.music, crossfadeDuration / 2),
                this.fadeIn(newTrack, this.musicVolume * this.masterVolume, crossfadeDuration)
            ]);

            // Stop old track
            this.music.pause();
            this.music.currentTime = 0;

            // Switch references
            this.preloadedTracks[this.currentTrack] = this.music;
            this.music = newTrack;
            this.currentTrack = trackName;

            if (this.debug) {
                console.log(`AudioManager: Switched to track ${trackName}`);
            }
        } catch (error) {
            console.warn('AudioManager: Error switching tracks:', error);
        } finally {
            this.fadeInProgress = false;
        }
    }

    // Fade in audio element
    async fadeIn(audioElement, targetVolume, duration = 1000) {
        return new Promise((resolve) => {
            const startVolume = 0;
            const volumeStep = targetVolume / (duration / 50);
            let currentVolume = startVolume;

            audioElement.volume = currentVolume;

            const fadeInterval = setInterval(() => {
                currentVolume += volumeStep;

                if (currentVolume >= targetVolume) {
                    currentVolume = targetVolume;
                    clearInterval(fadeInterval);
                    resolve();
                }

                audioElement.volume = Math.max(0, Math.min(1, currentVolume));
            }, 50);
        });
    }

    // Fade out audio element
    async fadeOut(audioElement, duration = 1000) {
        return new Promise((resolve) => {
            const startVolume = audioElement.volume;
            const volumeStep = startVolume / (duration / 50);
            let currentVolume = startVolume;

            const fadeInterval = setInterval(() => {
                currentVolume -= volumeStep;

                if (currentVolume <= 0) {
                    currentVolume = 0;
                    clearInterval(fadeInterval);
                    resolve();
                }

                audioElement.volume = Math.max(0, currentVolume);
            }, 50);
        });
    }

    // Stop background music
    stopMusic() {
        if (this.debug) {
            console.log('AudioManager: Stopping music');
        }

        if (this.music) {
            this.music.pause();
            this.music.currentTime = 0;
        }
    }

    // Pause background music
    pauseMusic() {
        if (this.music && !this.music.paused) {
            this.music.pause();
            if (this.debug) {
                console.log('AudioManager: Music paused');
            }
        }
    }

    // Resume background music
    resumeMusic() {
        if (this.music && this.music.paused && !this.muted) {
            this.playMusic();
        }
    }

    // Set sound effects volume
    setSfxVolume(volume) {
        this.sfxVolume = Math.max(0, Math.min(1, volume));

        // Update volume for all loaded sounds
        Object.values(this.sounds).forEach(audio => {
            if (audio) {
                audio.volume = this.sfxVolume * this.masterVolume;
            }
        });

        // Update character sounds
        Object.values(this.characterSounds).forEach(audio => {
            if (audio) {
                audio.volume = this.sfxVolume * this.masterVolume;
            }
        });

        this.saveSettings();

        if (this.debug) {
            console.log(`AudioManager: SFX volume set to ${this.sfxVolume}`);
        }
    }

    // Set music volume
    setMusicVolume(volume) {
        this.musicVolume = Math.max(0, Math.min(1, volume));

        if (this.music) {
            this.music.volume = this.musicVolume * this.masterVolume;
        }

        // Update preloaded tracks
        Object.values(this.preloadedTracks).forEach(audio => {
            if (audio) {
                audio.volume = this.musicVolume * this.masterVolume;
            }
        });

        this.saveSettings();

        if (this.debug) {
            console.log(`AudioManager: Music volume set to ${this.musicVolume}`);
        }
    }

    // Set master volume
    setMasterVolume(volume) {
        this.masterVolume = Math.max(0, Math.min(1, volume));

        // Update all audio volumes
        this.setSfxVolume(this.sfxVolume);
        this.setMusicVolume(this.musicVolume);

        this.saveSettings();

        if (this.debug) {
            console.log(`AudioManager: Master volume set to ${this.masterVolume}`);
        }
    }

    // Save settings to localStorage
    saveSettings() {
        const settings = {
            masterVolume: this.masterVolume,
            musicVolume: this.musicVolume,
            sfxVolume: this.sfxVolume,
            muted: this.muted,
            musicMuted: this.musicMuted,
            sfxMuted: this.sfxMuted
        };

        localStorage.setItem('celestial_audio_settings', JSON.stringify(settings));

        // Also update settings manager if available
        if (window.settingsManager) {
            window.settingsManager.set('audio', settings);
        }
    }

    // Toggle mute
    toggleMute() {
        this.muted = !this.muted;

        if (this.muted) {
            this.pauseMusic();
        } else {
            this.resumeMusic();
        }

        this.saveSettings();

        if (this.debug) {
            console.log(`AudioManager: Muted set to ${this.muted}`);
        }

        return this.muted;
    }

    // Toggle music mute
    toggleMusicMute() {
        this.musicMuted = !this.musicMuted;

        if (this.musicMuted) {
            this.pauseMusic();
        } else if (!this.muted) {
            this.resumeMusic();
        }

        this.saveSettings();

        if (this.debug) {
            console.log(`AudioManager: Music muted set to ${this.musicMuted}`);
        }

        return this.musicMuted;
    }

    // Toggle SFX mute
    toggleSfxMute() {
        this.sfxMuted = !this.sfxMuted;
        this.saveSettings();

        if (this.debug) {
            console.log(`AudioManager: SFX muted set to ${this.sfxMuted}`);
        }

        return this.sfxMuted;
    }

    // Add hover and click listeners to elements
    addSoundEffectsToElements() {
        // Add hover effects to interactive elements
        const hoverElements = document.querySelectorAll(`
            .menu-card, .submenu-item, .profile-avatar, .profile-stats,
            .action-button, .btn, .character-card, .event-card,
            .glass-card, .menu-button, .back-button
        `);

        hoverElements.forEach(element => {
            element.addEventListener('mouseenter', () => {
                this.playSound('hover');
            });
        });

        // Add click effects to clickable elements
        const clickElements = document.querySelectorAll(`
            .menu-card, .submenu-item, .profile-avatar, .profile-stats,
            .action-button, .btn, .character-card, .event-card,
            .glass-card, .menu-button, .back-button, button, a[href]
        `);

        clickElements.forEach(element => {
            element.addEventListener('click', () => {
                this.playSound('click');
            });
        });

        if (this.debug) {
            console.log('AudioManager: Sound effects added to elements');
        }
    }

    // Check if audio is supported
    isSupported() {
        return !!this.audioContext;
    }

    // Get current mute status
    isMuted() {
        return this.muted;
    }
}

// Initialize Enhanced AudioManager when DOM is loaded
document.addEventListener('DOMContentLoaded', async function() {
    try {
        window.audioManager = new AudioManager();

        // Wait for initialization to complete
        await window.audioManager.init();

        // Add sound effects to elements after initialization
        setTimeout(() => {
            window.audioManager.addSoundEffectsToElements();
        }, 1000);

        console.log('✅ Enhanced AudioManager initialized successfully');
    } catch (error) {
        console.error('❌ Failed to initialize AudioManager:', error);

        // Create fallback audio manager
        window.audioManager = {
            playSound: () => {},
            playCharacterSound: () => {},
            playMusic: () => {},
            stopMusic: () => {},
            pauseMusic: () => {},
            resumeMusic: () => {},
            setSfxVolume: () => {},
            setMusicVolume: () => {},
            setMasterVolume: () => {},
            toggleMute: () => false,
            toggleMusicMute: () => false,
            toggleSfxMute: () => false,
            isMuted: () => false,
            addSoundEffectsToElements: () => {}
        };
    }
});