// ===== DATA PERSISTENCE MANAGER =====

class DataManager {
    constructor() {
        this.storagePrefix = 'celestial_tale_';
        this.version = '1.0.0';
        this.data = this.getDefaultData();
        this.autoSaveInterval = null;
        this.lastSaveTime = null;
        
        this.init();
    }

    init() {
        console.log('💾 Data Manager Initializing...');
        
        this.loadAllData();
        this.setupAutoSave();
        this.setupEventListeners();
        this.migrateOldData();
        
        console.log('✅ Data Manager Ready!');
    }

    getDefaultData() {
        return {
            version: this.version,
            user: {
                username: 'Player',
                level: 1,
                experience: 0,
                joinDate: new Date().toISOString(),
                lastLogin: new Date().toISOString(),
                playTime: 0, // in seconds
                preferences: {
                    theme: 'dark',
                    language: 'tr'
                }
            },
            resources: {
                neuralFragments: 150,
                memoryShards: 75,
                dataPoints: 300
            },
            characters: {
                leo: {
                    affinity: 75,
                    unlocked: true,
                    lastInteraction: null,
                    conversationCount: 0,
                    favoriteMessages: []
                },
                chloe: {
                    affinity: 60,
                    unlocked: true,
                    lastInteraction: null,
                    conversationCount: 0,
                    favoriteMessages: []
                },
                felix: {
                    affinity: 90,
                    unlocked: false,
                    lastInteraction: null,
                    conversationCount: 0,
                    favoriteMessages: []
                },
                elara: {
                    affinity: 45,
                    unlocked: false,
                    lastInteraction: null,
                    conversationCount: 0,
                    favoriteMessages: []
                }
            },
            progress: {
                mainStory: {
                    currentChapter: 1,
                    completedChapters: [],
                    choices: {}
                },
                characterStories: {
                    leo: { progress: 0, unlocked: [] },
                    chloe: { progress: 0, unlocked: [] },
                    felix: { progress: 0, unlocked: [] },
                    elara: { progress: 0, unlocked: [] }
                },
                achievements: [],
                unlockedContent: {
                    gallery: [],
                    audio: [],
                    extras: []
                }
            },
            statistics: {
                totalPlayTime: 0,
                messagesSent: 0,
                charactersUnlocked: 2,
                achievementsUnlocked: 0,
                galleryItemsUnlocked: 0,
                choicesMade: 0,
                sessionsPlayed: 0
            },
            settings: {
                // Will be managed by SettingsManager
            },
            gameState: {
                currentPage: 'main-menu',
                lastSaveTime: new Date().toISOString(),
                sessionStartTime: new Date().toISOString()
            }
        };
    }

    loadAllData() {
        try {
            const savedData = localStorage.getItem(this.storagePrefix + 'gamedata');
            if (savedData) {
                const parsed = JSON.parse(savedData);
                this.data = this.mergeData(this.getDefaultData(), parsed);
                
                // Update last login
                this.data.user.lastLogin = new Date().toISOString();
                this.data.gameState.sessionStartTime = new Date().toISOString();
                this.data.statistics.sessionsPlayed++;
                
                console.log('💾 Game data loaded successfully');
            } else {
                console.log('💾 No saved data found, using defaults');
            }
        } catch (error) {
            console.error('💾 Failed to load game data:', error);
            this.data = this.getDefaultData();
        }
    }

    mergeData(defaults, saved) {
        const merged = JSON.parse(JSON.stringify(defaults)); // Deep clone
        
        function deepMerge(target, source) {
            for (const key in source) {
                if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])) {
                    if (!target[key]) target[key] = {};
                    deepMerge(target[key], source[key]);
                } else {
                    target[key] = source[key];
                }
            }
        }
        
        deepMerge(merged, saved);
        return merged;
    }

    saveAllData() {
        try {
            this.data.gameState.lastSaveTime = new Date().toISOString();
            this.lastSaveTime = Date.now();
            
            const dataToSave = JSON.stringify(this.data);
            localStorage.setItem(this.storagePrefix + 'gamedata', dataToSave);
            
            // Also save a backup
            localStorage.setItem(this.storagePrefix + 'gamedata_backup', dataToSave);
            
            console.log('💾 Game data saved successfully');
            this.triggerEvent('dataSaved', this.data);
            
            return true;
        } catch (error) {
            console.error('💾 Failed to save game data:', error);
            this.triggerEvent('saveError', error);
            return false;
        }
    }

    setupAutoSave() {
        // Auto-save every 30 seconds
        this.autoSaveInterval = setInterval(() => {
            this.saveAllData();
        }, 30000);
        
        // Save on page unload
        window.addEventListener('beforeunload', () => {
            this.saveAllData();
        });
        
        // Save on visibility change (mobile/tab switching)
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                this.saveAllData();
            }
        });
    }

    setupEventListeners() {
        // Listen for game events to update data
        document.addEventListener('messagesSent', (e) => {
            this.data.statistics.messagesSent++;
            this.updateCharacterInteraction(e.detail.characterId);
        });
        
        document.addEventListener('characterUnlocked', (e) => {
            this.unlockCharacter(e.detail.characterId);
        });
        
        document.addEventListener('achievementUnlocked', (e) => {
            this.unlockAchievement(e.detail.achievementId);
        });
        
        document.addEventListener('galleryItemUnlocked', (e) => {
            this.unlockGalleryItem(e.detail.itemId);
        });
        
        document.addEventListener('choiceMade', (e) => {
            this.recordChoice(e.detail.choiceId, e.detail.value);
        });
        
        document.addEventListener('resourcesChanged', (e) => {
            this.updateResources(e.detail.resources);
        });
    }

    migrateOldData() {
        // Check for old data format and migrate if necessary
        const oldVersion = this.data.version;
        if (oldVersion !== this.version) {
            console.log(`💾 Migrating data from version ${oldVersion} to ${this.version}`);
            // Add migration logic here if needed
            this.data.version = this.version;
        }
    }

    // Data access methods
    get(path) {
        const keys = path.split('.');
        let current = this.data;
        
        for (const key of keys) {
            if (current && typeof current === 'object' && key in current) {
                current = current[key];
            } else {
                return undefined;
            }
        }
        
        return current;
    }

    set(path, value) {
        const keys = path.split('.');
        let current = this.data;
        
        for (let i = 0; i < keys.length - 1; i++) {
            const key = keys[i];
            if (!current[key] || typeof current[key] !== 'object') {
                current[key] = {};
            }
            current = current[key];
        }
        
        current[keys[keys.length - 1]] = value;
        this.triggerEvent('dataChanged', { path, value });
    }

    // Specific data management methods
    updateResources(resources) {
        Object.assign(this.data.resources, resources);
        this.triggerEvent('resourcesUpdated', this.data.resources);
    }

    addResources(type, amount) {
        if (this.data.resources[type] !== undefined) {
            this.data.resources[type] += amount;
            this.triggerEvent('resourcesUpdated', this.data.resources);
        }
    }

    spendResources(type, amount) {
        if (this.data.resources[type] !== undefined && this.data.resources[type] >= amount) {
            this.data.resources[type] -= amount;
            this.triggerEvent('resourcesUpdated', this.data.resources);
            return true;
        }
        return false;
    }

    updateCharacterAffinity(characterId, newAffinity) {
        if (this.data.characters[characterId]) {
            this.data.characters[characterId].affinity = Math.max(0, Math.min(100, newAffinity));
            this.triggerEvent('affinityUpdated', { characterId, affinity: newAffinity });
        }
    }

    updateCharacterInteraction(characterId) {
        if (this.data.characters[characterId]) {
            this.data.characters[characterId].lastInteraction = new Date().toISOString();
            this.data.characters[characterId].conversationCount++;
        }
    }

    unlockCharacter(characterId) {
        if (this.data.characters[characterId] && !this.data.characters[characterId].unlocked) {
            this.data.characters[characterId].unlocked = true;
            this.data.statistics.charactersUnlocked++;
            this.triggerEvent('characterUnlocked', { characterId });
        }
    }

    unlockAchievement(achievementId) {
        if (!this.data.progress.achievements.includes(achievementId)) {
            this.data.progress.achievements.push(achievementId);
            this.data.statistics.achievementsUnlocked++;
            this.triggerEvent('achievementUnlocked', { achievementId });
        }
    }

    unlockGalleryItem(itemId) {
        if (!this.data.progress.unlockedContent.gallery.includes(itemId)) {
            this.data.progress.unlockedContent.gallery.push(itemId);
            this.data.statistics.galleryItemsUnlocked++;
            this.triggerEvent('galleryItemUnlocked', { itemId });
        }
    }

    recordChoice(choiceId, value) {
        this.data.progress.mainStory.choices[choiceId] = value;
        this.data.statistics.choicesMade++;
        this.triggerEvent('choiceMade', { choiceId, value });
    }

    updatePlayTime() {
        const now = Date.now();
        const sessionStart = new Date(this.data.gameState.sessionStartTime).getTime();
        const sessionTime = Math.floor((now - sessionStart) / 1000);
        
        this.data.statistics.totalPlayTime += sessionTime;
        this.data.gameState.sessionStartTime = new Date().toISOString();
    }

    // Export/Import functionality
    exportData() {
        try {
            this.updatePlayTime();
            const exportData = {
                ...this.data,
                exportDate: new Date().toISOString(),
                exportVersion: this.version
            };
            
            const dataStr = JSON.stringify(exportData, null, 2);
            const dataBlob = new Blob([dataStr], { type: 'application/json' });
            const url = URL.createObjectURL(dataBlob);
            
            const link = document.createElement('a');
            link.href = url;
            link.download = `celestial-tale-save-${new Date().toISOString().split('T')[0]}.json`;
            link.click();
            
            URL.revokeObjectURL(url);
            
            console.log('💾 Game data exported successfully');
            return true;
        } catch (error) {
            console.error('💾 Failed to export game data:', error);
            return false;
        }
    }

    importData(jsonData) {
        try {
            const importedData = typeof jsonData === 'string' ? JSON.parse(jsonData) : jsonData;
            
            // Validate imported data
            if (!this.validateImportedData(importedData)) {
                throw new Error('Invalid save data format');
            }
            
            // Merge with current data
            this.data = this.mergeData(this.getDefaultData(), importedData);
            
            // Save immediately
            this.saveAllData();
            
            console.log('💾 Game data imported successfully');
            this.triggerEvent('dataImported', this.data);
            
            return true;
        } catch (error) {
            console.error('💾 Failed to import game data:', error);
            return false;
        }
    }

    validateImportedData(data) {
        // Basic validation
        return data && 
               typeof data === 'object' && 
               data.user && 
               data.resources && 
               data.characters;
    }

    // Reset functionality
    resetAllData() {
        if (confirm('Tüm oyun verilerini sıfırlamak istediğinizden emin misiniz? Bu işlem geri alınamaz!')) {
            this.data = this.getDefaultData();
            this.saveAllData();
            this.triggerEvent('dataReset', this.data);
            
            // Reload page to apply changes
            window.location.reload();
            
            return true;
        }
        return false;
    }

    // Statistics and analytics
    getPlayTimeFormatted() {
        const totalSeconds = this.data.statistics.totalPlayTime;
        const hours = Math.floor(totalSeconds / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        
        if (hours > 0) {
            return `${hours}s ${minutes}d`;
        } else {
            return `${minutes}d`;
        }
    }

    getCompletionPercentage() {
        const totalContent = 100; // Adjust based on actual content
        const unlockedContent = this.data.statistics.galleryItemsUnlocked + 
                               this.data.statistics.achievementsUnlocked + 
                               this.data.statistics.charactersUnlocked;
        
        return Math.min(100, Math.round((unlockedContent / totalContent) * 100));
    }

    // Event system
    triggerEvent(eventName, data) {
        const event = new CustomEvent(eventName, { detail: data });
        document.dispatchEvent(event);
    }

    // Public API
    getAllData() {
        return JSON.parse(JSON.stringify(this.data)); // Return deep copy
    }

    getLastSaveTime() {
        return this.lastSaveTime;
    }

    forceSave() {
        return this.saveAllData();
    }

    // Cleanup
    destroy() {
        if (this.autoSaveInterval) {
            clearInterval(this.autoSaveInterval);
        }
        this.saveAllData();
    }
}

// Initialize Data Manager
let dataManager;

document.addEventListener('DOMContentLoaded', () => {
    dataManager = new DataManager();
    window.dataManager = dataManager;
    
    // Update play time every minute
    setInterval(() => {
        dataManager.updatePlayTime();
    }, 60000);
});
