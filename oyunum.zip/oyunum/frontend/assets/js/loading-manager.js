// ===== LOADING & PERFORMANCE MANAGER =====

class LoadingManager {
    constructor() {
        this.loadingStates = new Map();
        this.loadingOverlay = null;
        this.progressBar = null;
        this.loadingText = null;
        this.imageCache = new Map();
        this.lazyImages = [];
        this.performanceMetrics = {
            loadStartTime: performance.now(),
            resourcesLoaded: 0,
            totalResources: 0
        };
        
        this.init();
    }

    init() {
        console.log('⏳ Loading Manager Initializing...');
        
        this.createLoadingOverlay();
        this.setupLazyLoading();
        this.setupPerformanceMonitoring();
        this.preloadCriticalResources();
        
        console.log('✅ Loading Manager Ready!');
    }

    createLoadingOverlay() {
        // Create loading overlay
        this.loadingOverlay = document.createElement('div');
        this.loadingOverlay.id = 'loading-overlay';
        this.loadingOverlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: var(--accent-grad);
            z-index: 9999;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            opacity: 1;
            transition: opacity 0.5s ease;
        `;

        // Create loading content
        const loadingContent = document.createElement('div');
        loadingContent.style.cssText = `
            text-align: center;
            color: var(--c5);
        `;

        // Logo/Title
        const title = document.createElement('h1');
        title.textContent = 'Celestial Tale';
        title.style.cssText = `
            font-size: 3rem;
            margin-bottom: 2rem;
            background: linear-gradient(45deg, var(--c5), var(--c4));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            animation: pulse 2s infinite;
        `;

        // Loading spinner
        const spinner = document.createElement('div');
        spinner.style.cssText = `
            width: 60px;
            height: 60px;
            border: 4px solid rgba(255,255,255,0.3);
            border-top: 4px solid var(--c5);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 2rem;
        `;

        // Progress bar
        this.progressBar = document.createElement('div');
        this.progressBar.style.cssText = `
            width: 300px;
            height: 6px;
            background: rgba(255,255,255,0.2);
            border-radius: 3px;
            overflow: hidden;
            margin-bottom: 1rem;
        `;

        const progressFill = document.createElement('div');
        progressFill.id = 'progress-fill';
        progressFill.style.cssText = `
            width: 0%;
            height: 100%;
            background: var(--c5);
            border-radius: 3px;
            transition: width 0.3s ease;
        `;
        this.progressBar.appendChild(progressFill);

        // Loading text
        this.loadingText = document.createElement('p');
        this.loadingText.textContent = 'Yükleniyor...';
        this.loadingText.style.cssText = `
            font-size: 1.1rem;
            opacity: 0.8;
            margin-bottom: 1rem;
        `;

        // Tips
        const tips = [
            '💡 İpucu: Karakterlerle sohbet ederek affinity puanınızı artırabilirsiniz',
            '💡 İpucu: Ayarlar menüsünden ses seviyelerini ayarlayabilirsiniz',
            '💡 İpucu: Galeri bölümünde topladığınız anıları görüntüleyebilirsiniz',
            '💡 İpucu: Alt+H tuşu ile ana menüye hızlıca dönebilirsiniz',
            '💡 İpucu: Mağazadan Neural Fragment satın alarak yeni içerikleri açabilirsiniz'
        ];

        const tipElement = document.createElement('p');
        tipElement.textContent = tips[Math.floor(Math.random() * tips.length)];
        tipElement.style.cssText = `
            font-size: 0.9rem;
            opacity: 0.7;
            max-width: 400px;
            line-height: 1.4;
        `;

        // Assemble loading content
        loadingContent.appendChild(title);
        loadingContent.appendChild(spinner);
        loadingContent.appendChild(this.progressBar);
        loadingContent.appendChild(this.loadingText);
        loadingContent.appendChild(tipElement);

        this.loadingOverlay.appendChild(loadingContent);

        // Add CSS animations
        const style = document.createElement('style');
        style.textContent = `
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
            @keyframes pulse {
                0%, 100% { opacity: 1; }
                50% { opacity: 0.7; }
            }
        `;
        document.head.appendChild(style);

        document.body.appendChild(this.loadingOverlay);
    }

    showLoading(text = 'Yükleniyor...', showProgress = true) {
        if (this.loadingText) {
            this.loadingText.textContent = text;
        }
        
        if (this.progressBar) {
            this.progressBar.style.display = showProgress ? 'block' : 'none';
        }
        
        if (this.loadingOverlay) {
            this.loadingOverlay.style.display = 'flex';
            this.loadingOverlay.style.opacity = '1';
        }
    }

    hideLoading() {
        if (this.loadingOverlay) {
            this.loadingOverlay.style.opacity = '0';
            setTimeout(() => {
                this.loadingOverlay.style.display = 'none';
            }, 500);
        }
    }

    updateProgress(percentage, text = null) {
        const progressFill = document.getElementById('progress-fill');
        if (progressFill) {
            progressFill.style.width = `${Math.min(100, Math.max(0, percentage))}%`;
        }
        
        if (text && this.loadingText) {
            this.loadingText.textContent = text;
        }
    }

    async preloadCriticalResources() {
        const criticalResources = [
            'assets/css/theme.css',
            'assets/css/interactive-novel.css',
            'assets/js/settings-manager.js',
            'assets/js/audio-manager.js',
            'assets/images/characters/leo-portrait.png',
            'assets/images/characters/chloe-portrait.png',
            'assets/audio/background-music.mp3',
            'assets/audio/sfx/click_soft.wav',
            'assets/audio/sfx/hover_subtle.wav'
        ];

        this.performanceMetrics.totalResources = criticalResources.length;
        let loadedCount = 0;

        const loadPromises = criticalResources.map(async (resource) => {
            try {
                await this.preloadResource(resource);
                loadedCount++;
                this.performanceMetrics.resourcesLoaded = loadedCount;
                
                const progress = (loadedCount / criticalResources.length) * 100;
                this.updateProgress(progress, `Yükleniyor... ${loadedCount}/${criticalResources.length}`);
                
                return true;
            } catch (error) {
                console.warn(`Failed to preload resource: ${resource}`, error);
                loadedCount++;
                return false;
            }
        });

        await Promise.all(loadPromises);
        
        // Add small delay for smooth UX
        await new Promise(resolve => setTimeout(resolve, 500));
        
        this.hideLoading();
        
        console.log(`⏳ Preloaded ${this.performanceMetrics.resourcesLoaded}/${this.performanceMetrics.totalResources} critical resources`);
    }

    async preloadResource(url) {
        return new Promise((resolve, reject) => {
            const extension = url.split('.').pop().toLowerCase();
            
            if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(extension)) {
                // Preload image
                const img = new Image();
                img.onload = () => {
                    this.imageCache.set(url, img);
                    resolve(img);
                };
                img.onerror = reject;
                img.src = url;
            } else if (['mp3', 'wav', 'ogg'].includes(extension)) {
                // Preload audio
                const audio = new Audio();
                audio.addEventListener('canplaythrough', () => resolve(audio), { once: true });
                audio.addEventListener('error', reject, { once: true });
                audio.preload = 'auto';
                audio.src = url;
            } else {
                // Preload other resources (CSS, JS)
                fetch(url)
                    .then(response => response.ok ? resolve(response) : reject(response))
                    .catch(reject);
            }
        });
    }

    setupLazyLoading() {
        // Intersection Observer for lazy loading
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        this.loadImage(img);
                        observer.unobserve(img);
                    }
                });
            }, {
                rootMargin: '50px'
            });

            // Observe all images with data-src
            this.observeLazyImages(imageObserver);
            
            // Re-observe when new content is added
            const contentObserver = new MutationObserver(() => {
                this.observeLazyImages(imageObserver);
            });
            
            contentObserver.observe(document.body, {
                childList: true,
                subtree: true
            });
        } else {
            // Fallback for older browsers
            this.loadAllImages();
        }
    }

    observeLazyImages(observer) {
        const lazyImages = document.querySelectorAll('img[data-src]:not([data-observed])');
        lazyImages.forEach(img => {
            img.setAttribute('data-observed', 'true');
            observer.observe(img);
        });
    }

    loadImage(img) {
        const src = img.getAttribute('data-src');
        if (src) {
            // Show loading placeholder
            img.style.filter = 'blur(5px)';
            img.style.transition = 'filter 0.3s ease';
            
            // Load image
            const newImg = new Image();
            newImg.onload = () => {
                img.src = src;
                img.removeAttribute('data-src');
                img.style.filter = 'none';
                this.imageCache.set(src, newImg);
            };
            newImg.onerror = () => {
                img.src = 'assets/images/characters/leo-portrait.png'; // Fallback
                img.style.filter = 'none';
            };
            newImg.src = src;
        }
    }

    loadAllImages() {
        const lazyImages = document.querySelectorAll('img[data-src]');
        lazyImages.forEach(img => this.loadImage(img));
    }

    setupPerformanceMonitoring() {
        // Monitor page load performance
        window.addEventListener('load', () => {
            const loadTime = performance.now() - this.performanceMetrics.loadStartTime;
            console.log(`⏳ Page loaded in ${Math.round(loadTime)}ms`);
            
            // Report performance metrics
            if ('performance' in window && 'getEntriesByType' in performance) {
                const navigation = performance.getEntriesByType('navigation')[0];
                if (navigation) {
                    console.log('⏳ Performance Metrics:', {
                        domContentLoaded: Math.round(navigation.domContentLoadedEventEnd - navigation.domContentLoadedEventStart),
                        loadComplete: Math.round(navigation.loadEventEnd - navigation.loadEventStart),
                        totalTime: Math.round(navigation.loadEventEnd - navigation.fetchStart)
                    });
                }
            }
        });

        // Monitor memory usage (if available)
        if ('memory' in performance) {
            setInterval(() => {
                const memory = performance.memory;
                if (memory.usedJSHeapSize > memory.jsHeapSizeLimit * 0.9) {
                    console.warn('⚠️ High memory usage detected');
                    this.optimizeMemory();
                }
            }, 30000);
        }
    }

    optimizeMemory() {
        // Clear old cached images
        if (this.imageCache.size > 50) {
            const entries = Array.from(this.imageCache.entries());
            const toRemove = entries.slice(0, entries.length - 30);
            toRemove.forEach(([key]) => {
                this.imageCache.delete(key);
            });
            console.log('🧹 Cleared old image cache entries');
        }

        // Suggest garbage collection (if available)
        if ('gc' in window) {
            window.gc();
        }
    }

    // Loading state management
    setLoadingState(key, isLoading, text = null) {
        if (isLoading) {
            this.loadingStates.set(key, { loading: true, text });
        } else {
            this.loadingStates.delete(key);
        }

        // Show/hide global loading based on active states
        const hasActiveLoading = this.loadingStates.size > 0;
        if (hasActiveLoading) {
            const activeState = Array.from(this.loadingStates.values())[0];
            this.showLoading(activeState.text || 'Yükleniyor...', false);
        } else {
            this.hideLoading();
        }
    }

    // Utility methods
    async loadWithProgress(promises, texts = []) {
        const total = promises.length;
        let completed = 0;

        this.showLoading('Başlatılıyor...', true);
        this.updateProgress(0);

        const results = await Promise.allSettled(promises.map(async (promise, index) => {
            try {
                const result = await promise;
                completed++;
                const progress = (completed / total) * 100;
                const text = texts[index] || `Yükleniyor... ${completed}/${total}`;
                this.updateProgress(progress, text);
                return result;
            } catch (error) {
                completed++;
                const progress = (completed / total) * 100;
                this.updateProgress(progress, `Hata: ${texts[index] || 'Bilinmeyen'}`);
                throw error;
            }
        }));

        this.hideLoading();
        return results;
    }

    // Public API
    getCachedImage(url) {
        return this.imageCache.get(url);
    }

    getPerformanceMetrics() {
        return { ...this.performanceMetrics };
    }

    clearCache() {
        this.imageCache.clear();
        console.log('🧹 Image cache cleared');
    }
}

// Initialize Loading Manager
let loadingManager;

document.addEventListener('DOMContentLoaded', () => {
    loadingManager = new LoadingManager();
    window.loadingManager = loadingManager;
});
