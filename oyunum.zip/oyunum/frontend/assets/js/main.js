// Celestial Tale - Main JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tab switching
    initAuthTabs();
    
    // Initialize form handling
    initFormHandling();
    
    // Initialize animations
    initAnimations();
    
    // Initialize mobile optimizations
    initMobileOptimizations();
});

// Auth tab switching
function initAuthTabs() {
    const tabs = document.querySelectorAll('.auth-tab');
    const forms = document.querySelectorAll('.auth-form');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const targetTab = this.getAttribute('data-tab');
            
            // Update tab states
            tabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            // Update form states
            forms.forEach(form => {
                form.classList.remove('active');
                if (form.id === targetTab + '-form') {
                    form.classList.add('active');
                }
            });
            
            // Clear messages when switching tabs
            clearMessages();
        });
    });
}

// Form handling
function initFormHandling() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const submitBtn = this.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.textContent = 'Processing...';
                
                // Re-enable button after 3 seconds as fallback
                setTimeout(() => {
                    submitBtn.disabled = false;
                    submitBtn.textContent = submitBtn.getAttribute('data-original-text') || 'Submit';
                }, 3000);
            }
        });
    });
}

// Animation initialization
function initAnimations() {
    // Initialize scroll animations
    initScrollAnimations();
    
    // Initialize hover effects
    initHoverEffects();
}


    createCloud(background, 'cloud-2', 'bg-purple-400/15', 'top-1/2 -right-32', '45s');
    createCloud(background, 'cloud-3', 'bg-teal-400/10', 'bottom-0 -left-10', '40s');
    
    // Create shooting stars
    createShootingStar(background, '1s', '12s');
    createShootingStar(background, '5s', '18s', '20vh');
    
    // Create moons
    createMoon(background, 'moon-yellow', 'top-[10%] right-[10%]', 'w-20 h-20 md:w-28 md:h-28', 'border-yellow-200', 'yellow');
    createMoon(background, 'moon-teal', 'bottom-[15%] left-[5%]', 'w-16 h-16', 'border-teal-300', 'teal');
    
    // Create character glows
    const characters = [
        { name: 'Leo', left: '5%', delay: '0s' },
        { name: 'Elara', left: '25%', delay: '3s' },
        { name: 'Felix', left: '50%', delay: '6s' },
        { name: 'Chloe', right: '25%', delay: '9s' },
        { name: 'Viktor', right: '5%', delay: '12s' }
    ];
    
    characters.forEach(char => {
        const glow = document.createElement('div');
        glow.className = 'character-glow';
        glow.style.cssText = `
            ${char.left ? `left: ${char.left}` : ''};
            ${char.right ? `right: ${char.right}` : ''};
            ${char.left === '50%' ? 'transform: translateX(-50%)' : ''};
            animation-delay: ${char.delay};
        `;
        background.appendChild(glow);
    });

function createCloud(container, id, bgClass, position, duration) {
    const cloud = document.createElement('div');
    cloud.className = `cloud ${bgClass} ${position}`;
    cloud.id = id;
    cloud.style.animationDuration = duration;
    container.appendChild(cloud);
}

// Helper function to create shooting stars
function createShootingStar(container, delay, duration, top = '0') {
    const star = document.createElement('div');
    star.className = 'shooting-star';
    star.style.cssText = `
        animation-delay: ${delay};
        animation-duration: ${duration};
        top: ${top};
    `;
    container.appendChild(star);
}

// Helper function to create moons
function createMoon(container, id, position, size, borderClass, color) {
    const moon = document.createElement('div');
    moon.className = `moon ${size} ${borderClass} ${position}`;
    moon.id = id;
    moon.style.cssText = `
        position: absolute;
        border: ${color === 'yellow' ? '6px' : '4px'} solid;
        transform: rotate(${color === 'yellow' ? '-30deg' : '20deg'});
    `;
    container.appendChild(moon);
    
    // Add shadow for crescent effect
    const shadow = document.createElement('div');
    shadow.className = `${size} rounded-full bg-gradient-to-b from-[#0f0326] to-[#2d1a55]`;
    shadow.style.cssText = `
        position: absolute;
        ${color === 'yellow' ? 'transform: translateX(-12px) translateY(4px) rotate(-30deg)' : 'transform: translateX(10px) translateY(-2px) rotate(20deg)'};
    `;
    moon.appendChild(shadow);
}

// Scroll animations
function initScrollAnimations() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    });
    
    document.querySelectorAll('.message, .character-card, .menu-btn').forEach(el => {
        observer.observe(el);
    });
}

// Hover effects
function initHoverEffects() {
    // Add hover effects to buttons
    document.querySelectorAll('.submit-btn, .menu-btn, .social-btn').forEach(btn => {
        btn.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.02)';
        });
        
        btn.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
        });
    });
    
    // Add hover effects to character cards
    document.querySelectorAll('.character-card').forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px)';
            this.style.boxShadow = '0 5px 15px rgba(168, 85, 247, 0.3)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = 'none';
        });
    });
}

// Mobile optimizations
function initMobileOptimizations() {
    // Prevent zoom on input focus (iOS)
    document.querySelectorAll('input, textarea').forEach(input => {
        input.addEventListener('focus', function() {
            if (window.innerWidth < 768) {
                this.style.fontSize = '16px';
            }
        });
    });
    
    // Handle viewport height on mobile
    function setViewportHeight() {
        const vh = window.innerHeight * 0.01;
        document.documentElement.style.setProperty('--vh', `${vh}px`);
    }
    
    setViewportHeight();
    window.addEventListener('resize', setViewportHeight);
    
    // Add touch feedback
    document.querySelectorAll('button, .menu-btn, .social-btn').forEach(btn => {
        btn.addEventListener('touchstart', function() {
            this.style.transform = 'scale(0.95)';
        });
        
        btn.addEventListener('touchend', function() {
            this.style.transform = 'scale(1)';
        });
    });
}

// Utility functions
function clearMessages() {
    document.querySelectorAll('.message').forEach(msg => {
        msg.remove();
    });
}

function showMessage(text, type = 'info') {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}`;
    messageDiv.textContent = text;
    
    const container = document.querySelector('.auth-container, .main-menu-container, .profile-creation-container');
    if (container) {
        container.appendChild(messageDiv);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            messageDiv.remove();
        }, 5000);
    }
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// API helper functions
async function apiCall(endpoint, data = null, method = 'GET') {
    const options = {
        method: method,
        headers: {
            'Content-Type': 'application/json',
        }
    };
    
    if (data) {
        options.body = JSON.stringify(data);
    }
    
    try {
        const response = await fetch(endpoint, options);
        const result = await response.json();
        
        if (!response.ok) {
            throw new Error(result.error || 'API call failed');
        }
        
        return result;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

// Form validation
function validateForm(form) {
    const inputs = form.querySelectorAll('input[required], textarea[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        if (!input.value.trim()) {
            input.style.borderColor = '#ef4444';
            isValid = false;
        } else {
            input.style.borderColor = '';
        }
    });
    
    return isValid;
}

// Export functions for use in other scripts
window.CelestialTale = {
    showMessage,
    clearMessages,
    apiCall,
    validateForm,
    debounce
};
