<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Premium Hikayeler - Celestial Tale</title>
    <link rel="stylesheet" href="assets/css/theme.css">
    <link rel="stylesheet" href="assets/css/animations.css">
    <link rel="stylesheet" href="assets/css/mobile.css">
    <link rel="stylesheet" href="assets/css/main-menu.css">
    <link rel="stylesheet" href="assets/css/enhanced-features.css">
    <style>
        /* Ensure Montserrat font usage */
        * {
            font-family: 'Montserrat', sans-serif !important;
        }

        .stories-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: var(--spacing-lg);
        }

        .stories-header {
            text-align: center;
            margin-bottom: var(--spacing-xl);
        }

        .stories-title {
            color: var(--color5);
            font-size: 2.2rem;
            font-weight: 800;
            margin-bottom: var(--spacing-sm);
            background: var(--gradient-secondary);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            font-family: 'Montserrat', sans-serif;
        }

        .stories-subtitle {
            color: var(--color4);
            font-size: 1rem;
            font-family: 'Montserrat', sans-serif;
        }

        /* Stories Grid - Mobile First */
        .stories-grid {
            display: grid;
            grid-template-columns: 1fr; /* Mobile: 1 column */
            gap: var(--spacing-lg);
            margin-bottom: var(--spacing-xl);
        }

        /* Tablet: 2 columns */
        @media (min-width: 768px) {
            .stories-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        /* Desktop: 3 columns */
        @media (min-width: 1024px) {
            .stories-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: var(--spacing-xl);
        }

        .story-card {
            background: var(--glass-bg);
            backdrop-filter: blur(var(--blur-md));
            border: 1px solid var(--glass-border);
            border-radius: var(--radius-xl);
            padding: var(--spacing-lg);
            transition: var(--transition-normal);
            cursor: pointer;
            position: relative;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            min-height: 280px;
        }

        .story-card:hover {
            border: 1px solid var(--glass-border-strong);
            box-shadow: var(--shadow-glow);
            transform: translateY(-4px);
        }

        .story-card.locked {
            opacity: 0.7;
            background: linear-gradient(135deg, 
                rgba(239, 68, 68, 0.05) 0%, 
                rgba(220, 38, 38, 0.05) 100%);
        }

        .story-card-header {
            display: flex;
            align-items: flex-start;
            gap: var(--spacing-md);
            margin-bottom: var(--spacing-md);
        }

        .story-card-icon {
            width: 60px;
            height: 60px;
            border-radius: var(--radius-md);
            background: var(--gradient-secondary);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            flex-shrink: 0;
            transition: var(--transition-normal);
        }

        .story-card:hover .story-card-icon {
            transform: scale(1.1);
        }

        .story-card-info {
            flex: 1;
        }

        .story-card-title {
            color: var(--color5);
            font-size: 1.2rem;
            font-weight: 700;
            margin-bottom: var(--spacing-xs);
            font-family: 'Montserrat', sans-serif;
            line-height: 1.3;
        }

        .story-card-author {
            color: var(--color4);
            font-size: 0.8rem;
            font-family: 'Montserrat', sans-serif;
            opacity: 0.8;
        }

        .story-card-description {
            color: var(--color4);
            font-size: 0.9rem;
            line-height: 1.5;
            margin-bottom: var(--spacing-md);
            font-family: 'Montserrat', sans-serif;
            flex: 1;
        }

        .story-card-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-top: auto;
        }

        .story-card-status {
            display: flex;
            align-items: center;
            gap: var(--spacing-xs);
            padding: var(--spacing-xs) var(--spacing-sm);
            border-radius: var(--radius-md);
            font-size: 0.75rem;
            font-weight: 600;
            font-family: 'Montserrat', sans-serif;
        }

        .story-card-status.unlocked {
            background: rgba(16, 185, 129, 0.1);
            color: #10b981;
            border: 1px solid rgba(16, 185, 129, 0.3);
        }

        .story-card-status.locked {
            background: rgba(239, 68, 68, 0.1);
            color: #ef4444;
            border: 1px solid rgba(239, 68, 68, 0.3);
        }

        .story-card-status.completed {
            background: rgba(123, 159, 255, 0.1);
            color: var(--color3);
            border: 1px solid rgba(123, 159, 255, 0.3);
        }

        .story-card-progress {
            font-size: 0.75rem;
            color: var(--color4);
            font-family: 'Montserrat', sans-serif;
        }

        .story-card-badge {
            position: absolute;
            top: var(--spacing-sm);
            right: var(--spacing-sm);
            background: var(--gradient-secondary);
            color: var(--color5);
            padding: var(--spacing-xs) var(--spacing-sm);
            border-radius: var(--radius-md);
            font-size: 0.7rem;
            font-weight: 700;
            font-family: 'Montserrat', sans-serif;
        }

        .story-card-badge.new {
            background: linear-gradient(135deg, #10b981, #059669);
        }

        .story-card-badge.exclusive {
            background: linear-gradient(135deg, #f59e0b, #d97706);
        }

        /* Back Button */
        .back-section {
            margin-bottom: var(--spacing-lg);
        }

        .back-button {
            background: var(--glass-bg);
            backdrop-filter: blur(var(--blur-md));
            border: 1px solid var(--glass-border);
            border-radius: var(--radius-xl);
            padding: var(--spacing-md) var(--spacing-lg);
            color: var(--color5);
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: var(--spacing-sm);
            transition: var(--transition-normal);
            font-family: 'Montserrat', sans-serif;
            font-weight: 600;
        }

        .back-button:hover {
            border-color: var(--glass-border-strong);
            transform: translateY(-2px);
            box-shadow: var(--shadow-glow);
        }

        /* Loading State */
        .loading {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: var(--spacing-xl);
            color: var(--color4);
            font-family: 'Montserrat', sans-serif;
        }
    </style>
</head>
<body>
    <div class="starfield"></div>
    <div class="nebula"></div>
    
    <main class="main-container">
        <div id="ajax-content" class="content-container">
            <div class="stories-container">
                <!-- Back Button -->
                <div class="back-section">
                    <a href="premium.php" class="back-button">
                        ← Premium'a Dön
                    </a>
                </div>

                <!-- Page Header -->
                <div class="stories-header">
                    <h1 class="stories-title">📚 Premium Hikayeler</h1>
                    <p class="stories-subtitle">Sadece premium üyeler için özel hikaye içerikleri</p>
                </div>

                <!-- Stories Grid -->
                <div class="stories-grid" id="stories-grid">
                    <!-- Stories will be loaded here -->
                </div>
            </div>
        </div>
        
        <div class="floating-particles"></div>
    </main>
    
    <script src="assets/js/navigation.js"></script>
    <script>
        // Premium Stories Controller
        class PremiumStoriesController {
            constructor() {
                this.stories = [
                    {
                        id: 1,
                        icon: '⚔️',
                        title: 'Leo\'nun Gizli Geçmişi',
                        author: 'Neural Network Archives',
                        description: 'Stratejist Leo\'nun bilinmeyen geçmişi ve Neural Network\'e katılma hikayesi. Karanlık sırlar ve kayıp anılar...',
                        status: 'unlocked',
                        progress: '0/5 bölüm',
                        badge: 'Yeni',
                        badgeType: 'new'
                    },
                    {
                        id: 2,
                        icon: '💻',
                        title: 'Chloe\'nin İlk Hack\'i',
                        author: 'Digital Chronicles',
                        description: 'Genç hacker Chloe\'nin sisteme ilk sızışı ve keşfettiği büyük komplo. Teknoloji ve dostluk hikayesi.',
                        status: 'completed',
                        progress: '3/3 bölüm',
                        badge: 'Tamamlandı',
                        badgeType: 'completed'
                    },
                    {
                        id: 3,
                        icon: '😊',
                        title: 'Felix\'in Kayıp Tarifi',
                        author: 'Memory Fragments',
                        description: 'Felix\'in çocukluk anılarından kayıp yemek tarifi ve ailesinin sırrı. Duygusal bir yolculuk.',
                        status: 'unlocked',
                        progress: '1/4 bölüm',
                        badge: 'Exclusive',
                        badgeType: 'exclusive'
                    },
                    {
                        id: 4,
                        icon: '🌟',
                        title: 'Elara\'nın Kehaneti',
                        author: 'Ancient Wisdom',
                        description: 'Mentor Elara\'nın geleceği görme yetisi ve Neural Network\'ün kaderini değiştirecek kehanetin sırrı.',
                        status: 'locked',
                        progress: '0/6 bölüm',
                        badge: 'Kilitli',
                        badgeType: 'locked'
                    },
                    {
                        id: 5,
                        icon: '🔮',
                        title: 'Neural Ağın Doğuşu',
                        author: 'Origin Stories',
                        description: 'Neural Network\'ün kuruluş hikayesi ve ilk kullanıcıların maceraları. Sistemin gizli tarihi.',
                        status: 'locked',
                        progress: '0/8 bölüm',
                        badge: 'Epic',
                        badgeType: 'exclusive'
                    },
                    {
                        id: 6,
                        icon: '💕',
                        title: 'Karakterler Arası Özel Anlar',
                        author: 'Relationship Chronicles',
                        description: 'Karakterlerin birbirleriyle olan özel anları ve gelişen ilişkilerin derinlemesine hikayesi.',
                        status: 'unlocked',
                        progress: '2/7 bölüm',
                        badge: 'Romantik',
                        badgeType: 'exclusive'
                    }
                ];
                this.init();
            }

            init() {
                console.log('📚 Premium Stories Controller Initializing...');
                this.createStarfield();
                this.loadStories();
                console.log('✅ Premium Stories Controller Ready!');
            }

            createStarfield() {
                const starfield = document.querySelector('.starfield');
                if (!starfield) return;
                
                const starCount = 50;
                for (let i = 0; i < starCount; i++) {
                    const star = document.createElement('div');
                    star.className = 'star';
                    star.style.left = Math.random() * 100 + '%';
                    star.style.top = Math.random() * 100 + '%';
                    star.style.animationDelay = Math.random() * 3 + 's';
                    starfield.appendChild(star);
                }
            }

            loadStories() {
                const grid = document.getElementById('stories-grid');
                grid.innerHTML = '<div class="loading">Hikayeler yükleniyor...</div>';

                // Simulate AJAX loading
                setTimeout(() => {
                    this.renderStories();
                }, 800);
            }

            renderStories() {
                const grid = document.getElementById('stories-grid');
                
                grid.innerHTML = this.stories.map(story => `
                    <div class="story-card ${story.status}" data-story-id="${story.id}" onclick="storiesController.openStory(${story.id})">
                        <div class="story-card-badge ${story.badgeType}">${story.badge}</div>
                        <div class="story-card-header">
                            <div class="story-card-icon">${story.icon}</div>
                            <div class="story-card-info">
                                <h3 class="story-card-title">${story.title}</h3>
                                <p class="story-card-author">${story.author}</p>
                            </div>
                        </div>
                        <p class="story-card-description">${story.description}</p>
                        <div class="story-card-footer">
                            <div class="story-card-status ${story.status}">
                                ${this.getStatusText(story.status)}
                            </div>
                            <div class="story-card-progress">${story.progress}</div>
                        </div>
                    </div>
                `).join('');

                // Add hover effects
                this.setupHoverEffects();
            }

            getStatusText(status) {
                switch(status) {
                    case 'unlocked': return '📖 Okunabilir';
                    case 'locked': return '🔒 Kilitli';
                    case 'completed': return '✅ Tamamlandı';
                    default: return '❓ Bilinmiyor';
                }
            }

            setupHoverEffects() {
                const cards = document.querySelectorAll('.story-card');
                cards.forEach(card => {
                    card.addEventListener('mouseenter', () => {
                        this.playHoverSound();
                    });
                });
            }

            openStory(storyId) {
                this.playClickSound();
                const story = this.stories.find(s => s.id === storyId);
                
                if (story) {
                    if (story.status === 'unlocked' || story.status === 'completed') {
                        this.showNotification(`${story.title} hikayesi açılıyor...`);
                        // Simulate AJAX navigation to story detail
                        setTimeout(() => {
                            this.showNotification('Hikaye detayı yakında!');
                        }, 1000);
                    } else if (story.status === 'locked') {
                        this.showNotification('Bu hikaye henüz kilitli! Premium üyeliğinizi yükseltin.');
                    }
                }
            }

            playHoverSound() {
                if (window.audioManager) {
                    window.audioManager.playSound('hover');
                }
            }

            playClickSound() {
                if (window.audioManager) {
                    window.audioManager.playSound('click');
                }
            }

            showNotification(message) {
                const notification = document.createElement('div');
                notification.style.cssText = `
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background: var(--glass-bg);
                    backdrop-filter: blur(var(--blur-md));
                    border: 1px solid var(--glass-border);
                    border-radius: 12px;
                    padding: 16px 20px;
                    color: var(--color5);
                    z-index: 1000;
                    opacity: 0;
                    transform: translateX(100px);
                    transition: all 0.3s ease;
                    font-family: 'Montserrat', sans-serif;
                    font-size: 0.9rem;
                `;
                notification.textContent = message;
                document.body.appendChild(notification);

                setTimeout(() => {
                    notification.style.opacity = '1';
                    notification.style.transform = 'translateX(0)';
                }, 10);

                setTimeout(() => {
                    notification.style.opacity = '0';
                    notification.style.transform = 'translateX(100px)';
                    setTimeout(() => {
                        if (notification.parentNode) {
                            document.body.removeChild(notification);
                        }
                    }, 300);
                }, 3000);
            }
        }

        // Initialize
        let storiesController;
        document.addEventListener('DOMContentLoaded', function() {
            storiesController = new PremiumStoriesController();
        });
    </script>
</body>
</html>
