<?php
require_once '../backend/config/config.php';
require_once '../backend/config/database.php';
require_once '../backend/includes/functions.php';

// Check if user is logged in
if (!is_logged_in()) {
    echo "User not logged in<br>";
    exit();
}

$user_id = $_SESSION['user_id'];
$chapter_id = 1;

echo "<h1>Chapter 1 Flow Test</h1>";

// Reset user progress for testing
$stmt = $pdo->prepare("UPDATE user_story_progress SET current_dialogue_id = NULL WHERE user_id = ? AND chapter_id = ?");
$stmt->execute([$user_id, $chapter_id]);

// Get the first dialogue
$stmt = $pdo->prepare("SELECT id FROM story_dialogues WHERE chapter_id = ? ORDER BY order_sequence ASC LIMIT 1");
$stmt->execute([$chapter_id]);
$first_dialogue = $stmt->fetch();
$dialogue_id = $first_dialogue ? $first_dialogue['id'] : null;

echo "<h2>Starting dialogue: " . $dialogue_id . "</h2>";

// Function to get dialogue and choices
function getDialogueAndChoices($pdo, $dialogue_id) {
    if (!$dialogue_id) return null;
    
    $stmt = $pdo->prepare("SELECT * FROM story_dialogues WHERE id = ?");
    $stmt->execute([$dialogue_id]);
    $dialogue = $stmt->fetch();
    
    if (!$dialogue) return null;
    
    $choices = [];
    if ($dialogue['is_choice_point']) {
        $stmt = $pdo->prepare("SELECT * FROM story_choices WHERE dialogue_id = ?");
        $stmt->execute([$dialogue_id]);
        $choices = $stmt->fetchAll();
    }
    
    return [
        'dialogue' => $dialogue,
        'choices' => $choices
    ];
}

// Function to process choice
function processChoice($pdo, $user_id, $chapter_id, $choice_id) {
    $stmt = $pdo->prepare("SELECT * FROM story_choices WHERE id = ?");
    $stmt->execute([$choice_id]);
    $choice = $stmt->fetch();
    
    if (!$choice) return null;
    
    // Apply affinity changes
    $affinity_changes = json_decode($choice['affinity_change'], true);
    echo "<p>Affinity changes: " . print_r($affinity_changes, true) . "</p>";
    
    // Update user progress
    $next_dialogue_id = $choice['leads_to_dialogue_id'];
    if ($next_dialogue_id) {
        $stmt = $pdo->prepare("UPDATE user_story_progress SET current_dialogue_id = ? WHERE user_id = ? AND chapter_id = ?");
        $stmt->execute([$next_dialogue_id, $user_id, $chapter_id]);
        echo "<p>Updated user progress to dialogue ID: " . $next_dialogue_id . "</p>";
    }
    
    return $next_dialogue_id;
}

// Display initial dialogue
$result = getDialogueAndChoices($pdo, $dialogue_id);
if ($result) {
    echo "<h3>Dialogue: " . htmlspecialchars($result['dialogue']['character_name']) . "</h3>";
    echo "<p>" . htmlspecialchars($result['dialogue']['dialogue_text']) . "</p>";
    
    if (!empty($result['choices'])) {
        echo "<h4>Choices:</h4>";
        echo "<ul>";
        foreach ($result['choices'] as $choice) {
            echo "<li><a href='?choice=" . $choice['id'] . "'>" . htmlspecialchars($choice['choice_text']) . "</a></li>";
        }
        echo "</ul>";
    }
}

// Process choice if selected
if (isset($_GET['choice'])) {
    $choice_id = (int)$_GET['choice'];
    echo "<h3>Processing choice ID: " . $choice_id . "</h3>";
    
    $next_dialogue_id = processChoice($pdo, $user_id, $chapter_id, $choice_id);
    
    if ($next_dialogue_id) {
        // Display next dialogue
        $result = getDialogueAndChoices($pdo, $next_dialogue_id);
        if ($result) {
            echo "<h3>Next Dialogue: " . htmlspecialchars($result['dialogue']['character_name']) . "</h3>";
            echo "<p>" . htmlspecialchars($result['dialogue']['dialogue_text']) . "</p>";
            
            if (!empty($result['choices'])) {
                echo "<h4>Choices:</h4>";
                echo "<ul>";
                foreach ($result['choices'] as $choice) {
                    echo "<li><a href='?choice=" . $choice['id'] . "'>" . htmlspecialchars($choice['choice_text']) . "</a></li>";
                }
                echo "</ul>";
            }
        }
    }
}
?>