<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Premium - Celestial Tale</title>
    <link rel="stylesheet" href="assets/css/theme.css">
    <link rel="stylesheet" href="assets/css/animations.css">
    <link rel="stylesheet" href="assets/css/mobile.css">
    <link rel="stylesheet" href="assets/css/main-menu.css">
    <link rel="stylesheet" href="assets/css/enhanced-features.css">
    <style>
        /* Ensure Montserrat font usage */
        * {
            font-family: 'Montserrat', sans-serif !important;
        }

        .premium-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: var(--spacing-lg);
        }

        .premium-header {
            text-align: center;
            margin-bottom: var(--spacing-xl);
        }

        .premium-title {
            color: var(--color5);
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: var(--spacing-sm);
            background: var(--gradient-secondary);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            font-family: 'Montserrat', sans-serif;
        }

        .premium-subtitle {
            color: var(--color4);
            font-size: 1.1rem;
            font-family: 'Montserrat', sans-serif;
        }

        /* Premium Grid - Mobile First */
        .premium-grid {
            display: grid;
            grid-template-columns: 1fr; /* Mobile: 1 column */
            gap: var(--spacing-lg);
            margin-bottom: var(--spacing-xl);
        }

        /* Tablet: 2 columns */
        @media (min-width: 768px) {
            .premium-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        /* Desktop: 3 columns */
        @media (min-width: 1024px) {
            .premium-grid {
                grid-template-columns: repeat(3, 1fr);
            }
        }

        .premium-card {
            background: var(--glass-bg);
            backdrop-filter: blur(var(--blur-md));
            border: 1px solid var(--glass-border);
            border-radius: var(--radius-xl);
            padding: var(--spacing-lg);
            transition: var(--transition-normal);
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }

        .premium-card:hover {
            border: 1px solid var(--glass-border-strong);
            box-shadow: var(--shadow-glow);
            transform: translateY(-4px);
        }

        .premium-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: var(--gradient-secondary);
            opacity: 0;
            transition: var(--transition-normal);
            z-index: -1;
        }

        .premium-card:hover::before {
            opacity: 0.05;
        }

        .premium-card-icon {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: var(--gradient-secondary);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.5rem;
            margin: 0 auto var(--spacing-lg);
            transition: var(--transition-normal);
        }

        .premium-card:hover .premium-card-icon {
            transform: scale(1.1);
        }

        .premium-card-title {
            color: var(--color5);
            font-size: 1.3rem;
            font-weight: 700;
            text-align: center;
            margin-bottom: var(--spacing-sm);
            font-family: 'Montserrat', sans-serif;
        }

        .premium-card-description {
            color: var(--color4);
            font-size: 0.9rem;
            text-align: center;
            line-height: 1.5;
            margin-bottom: var(--spacing-lg);
            font-family: 'Montserrat', sans-serif;
        }

        .premium-card-badge {
            position: absolute;
            top: var(--spacing-md);
            right: var(--spacing-md);
            background: var(--gradient-secondary);
            color: var(--color5);
            padding: var(--spacing-xs) var(--spacing-sm);
            border-radius: var(--radius-md);
            font-size: 0.7rem;
            font-weight: 700;
            font-family: 'Montserrat', sans-serif;
        }

        .premium-card-action {
            background: var(--gradient-secondary);
            color: var(--color5);
            border: none;
            border-radius: var(--radius-md);
            padding: var(--spacing-sm) var(--spacing-lg);
            font-size: 0.9rem;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition-normal);
            width: 100%;
            font-family: 'Montserrat', sans-serif;
        }

        .premium-card-action:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-glow);
        }

        /* Loading State */
        .loading {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: var(--spacing-xl);
            color: var(--color4);
            font-family: 'Montserrat', sans-serif;
        }

        .loading::after {
            content: '';
            width: 20px;
            height: 20px;
            border: 2px solid var(--color4);
            border-top: 2px solid var(--color3);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-left: var(--spacing-sm);
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Special VIP Card */
        .premium-card.vip {
            border: 2px solid var(--color3);
            background: linear-gradient(135deg, 
                rgba(123, 159, 255, 0.1) 0%, 
                rgba(132, 21, 103, 0.1) 50%, 
                rgba(36, 15, 72, 0.1) 100%);
        }

        .premium-card.vip .premium-card-icon {
            background: linear-gradient(135deg, var(--color3), var(--color2));
            box-shadow: 0 0 20px rgba(123, 159, 255, 0.3);
        }
    </style>
</head>
<body>
    <div class="starfield"></div>
    <div class="nebula"></div>
    
    <main class="main-container">
        <div id="ajax-content" class="content-container">
            <div class="premium-container">
                <!-- Page Header -->
                <div class="premium-header">
                    <h1 class="premium-title">👑 Premium</h1>
                    <p class="premium-subtitle">Özel içerikler ve premium özellikler</p>
                </div>

                <!-- Premium Grid -->
                <div class="premium-grid" id="premium-grid">
                    <!-- VIP Packages -->
                    <div class="premium-card vip" data-action="vip-packages" onclick="loadPremiumContent('vip-packages')">
                        <div class="premium-card-badge">Popüler</div>
                        <div class="premium-card-icon">💎</div>
                        <h3 class="premium-card-title">VIP Paketler</h3>
                        <p class="premium-card-description">Neural Fragment paketleri ve özel içerik erişimi</p>
                        <button class="premium-card-action">Paketleri Görüntüle</button>
                    </div>

                    <!-- Premium Stories -->
                    <div class="premium-card" data-action="premium-stories" onclick="loadPremiumContent('premium-stories')">
                        <div class="premium-card-badge">8 Hikaye</div>
                        <div class="premium-card-icon">📚</div>
                        <h3 class="premium-card-title">Özel Hikayeler</h3>
                        <p class="premium-card-description">Sadece premium üyeler için özel hikaye içerikleri</p>
                        <button class="premium-card-action">Hikayeleri Keşfet</button>
                    </div>

                    <!-- Premium Rewards -->
                    <div class="premium-card" data-action="premium-rewards" onclick="loadPremiumContent('premium-rewards')">
                        <div class="premium-card-badge">Yeni</div>
                        <div class="premium-card-icon">🎁</div>
                        <h3 class="premium-card-title">Premium Ödüller</h3>
                        <p class="premium-card-description">Özel rozetler ve exclusive içerikler</p>
                        <button class="premium-card-action">Ödülleri İncele</button>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="floating-particles"></div>
    </main>
    
    <script src="assets/js/navigation.js"></script>
    <script>
        // Premium Page Controller
        class PremiumController {
            constructor() {
                this.init();
            }

            init() {
                console.log('👑 Premium Controller Initializing...');
                this.createStarfield();
                this.setupHoverEffects();
                console.log('✅ Premium Controller Ready!');
            }

            createStarfield() {
                const starfield = document.querySelector('.starfield');
                if (!starfield) return;
                
                const starCount = 50;
                for (let i = 0; i < starCount; i++) {
                    const star = document.createElement('div');
                    star.className = 'star';
                    star.style.left = Math.random() * 100 + '%';
                    star.style.top = Math.random() * 100 + '%';
                    star.style.animationDelay = Math.random() * 3 + 's';
                    starfield.appendChild(star);
                }
            }

            setupHoverEffects() {
                const cards = document.querySelectorAll('.premium-card');
                cards.forEach(card => {
                    card.addEventListener('mouseenter', () => {
                        this.playHoverSound();
                    });
                    
                    card.addEventListener('click', () => {
                        this.playClickSound();
                    });
                });
            }

            playHoverSound() {
                // Hover sound effect
                if (window.audioManager) {
                    window.audioManager.playSound('hover');
                }
            }

            playClickSound() {
                // Click sound effect
                if (window.audioManager) {
                    window.audioManager.playSound('click');
                }
            }

            showNotification(message) {
                const notification = document.createElement('div');
                notification.style.cssText = `
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background: var(--glass-bg);
                    backdrop-filter: blur(var(--blur-md));
                    border: 1px solid var(--glass-border);
                    border-radius: 12px;
                    padding: 16px 20px;
                    color: var(--color5);
                    z-index: 1000;
                    opacity: 0;
                    transform: translateX(100px);
                    transition: all 0.3s ease;
                    font-family: 'Montserrat', sans-serif;
                    font-size: 0.9rem;
                `;
                notification.textContent = message;
                document.body.appendChild(notification);

                setTimeout(() => {
                    notification.style.opacity = '1';
                    notification.style.transform = 'translateX(0)';
                }, 10);

                setTimeout(() => {
                    notification.style.opacity = '0';
                    notification.style.transform = 'translateX(100px)';
                    setTimeout(() => {
                        if (notification.parentNode) {
                            document.body.removeChild(notification);
                        }
                    }, 300);
                }, 3000);
            }
        }

        // AJAX Content Loading Function
        async function loadPremiumContent(contentType) {
            const grid = document.getElementById('premium-grid');
            grid.innerHTML = '<div class="loading">İçerik yükleniyor...</div>';
            
            try {
                // Simulate AJAX call
                await new Promise(resolve => setTimeout(resolve, 1000));
                
                // Redirect to specific page
                window.location.href = `${contentType}.php`;
            } catch (error) {
                premiumController.showNotification('İçerik yüklenirken hata oluştu!');
                console.error('Error loading premium content:', error);
            }
        }

        // Initialize
        let premiumController;
        document.addEventListener('DOMContentLoaded', function() {
            premiumController = new PremiumController();
        });
    </script>
</body>
</html>
